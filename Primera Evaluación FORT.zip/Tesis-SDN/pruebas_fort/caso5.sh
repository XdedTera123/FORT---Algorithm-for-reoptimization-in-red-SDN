#!/usr/bin/env bash
# Caso 5: segunda caida (s4-s7) mientras FORT optimiza tras la caida de s1-s2, carga de 60 %.
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 5 caso5
