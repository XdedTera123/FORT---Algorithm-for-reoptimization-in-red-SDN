#!/usr/bin/env bash
# Configuracion comun de las pruebas de FORT. Todos los scripts casoN.sh la leen.
# Modifica aqui los valores; no hace falta tocar los scripts de cada caso.

# Escala del experimento: capacidad de cada enlace troncal (Mbps) y factor de las tasas.
# Deben cambiar en la misma proporcion (100 y 1.0, 25 y 0.25, 20 y 0.2): asi los
# niveles de 30, 60 y 90 % de utilizacion se mantienen y la maquina virtual trabaja liviana.
CAPACIDAD=50
FACTOR=0.5

TAMANO=1200
MTU=0
REPETICIONES=5          # corridas por caso; cada una reinicia topologia, FORT y trafico
ESPERA_TRAFICO=20       # segundos de trafico estable antes de bajar el enlace
EVALUACIONES=5          # evaluaciones continuas tras instalar el Target
INTERVALO_EVALUACION=10 # segundos entre evaluaciones continuas
PAUSA=15                # segundos de reposo entre corridas

# Tipo de trafico: se elige al ejecutar cada script, por ejemplo  sudo ./caso1.sh iperf3
#   constante  generador_udp.py: tasa fija, sin rafagas (predeterminado)
#   iperf3     iperf3 UDP tal cual: varia y compensa atrasos con rafagas
TRAFICO="${1:-constante}"
case "$TRAFICO" in constante|iperf3) ;; *) echo "Trafico no valido: $TRAFICO (usa constante o iperf3)" >&2; exit 1 ;; esac

SCRIPTS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROYECTO="$(dirname "$SCRIPTS")"   # los scripts van en una subcarpeta del proyecto (pruebas_fort/)

if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta con sudo, por ejemplo: sudo ./caso1.sh" >&2
    exit 1
fi

ejecutar() {   # ejecutar <casos separados por comas> <etiqueta> [repeticiones]
    /usr/bin/python3 "$SCRIPTS/ejecutar_pruebas.py" \
        --proyecto "$PROYECTO" --casos "$1" --etiqueta "${2}_${TRAFICO}" --trafico "$TRAFICO" \
        --repeticiones "${3:-$REPETICIONES}" \
        --capacidad "$CAPACIDAD" --factor "$FACTOR" \
        --espera-trafico "$ESPERA_TRAFICO" --evaluaciones "$EVALUACIONES" \
        --intervalo-evaluacion "$INTERVALO_EVALUACION" --pausa "$PAUSA" --tamano "$TAMANO" --mtu "$MTU" --sin-offload
}
