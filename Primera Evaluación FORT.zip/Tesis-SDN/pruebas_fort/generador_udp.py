#!/usr/bin/env python3
"""Generador UDP de tasa constante para las pruebas de FORT.

A diferencia de iperf3, el emisor NO recupera lo que no pudo enviar: si la maquina virtual
lo pausa, descarta los envios atrasados y continua a su tasa. Asi la demanda de cada flujo
se mantiene constante y no aparecen rafagas por encima de la tasa configurada.

Uso:
    generador_udp.py receptor --puerto 5301 --log receptor.log
    generador_udp.py emisor --destino 10.0.0.2 --puerto 5301 --tasa 9.18 --log emisor.log

El receptor escribe una linea por segundo con el formato de intervalos de iperf3
("0.00-1.00 sec ... perdidos/esperados (x%)"), que ejecutar_pruebas.py ya interpreta.
"""
import argparse
import signal
import socket
import struct
import sys
import time

CABECERA = struct.Struct('!Q')      # numero de secuencia
BUFFER = 4 * 1024 * 1024            # buffer de socket amplio: la congestion descarta, no bloquea
ATRASO_MAXIMO = 0.02                # mas de 20 ms de atraso = pausa: se omite, no se recupera


def linea(inicio, fin, nbytes, extra):
    mbytes = nbytes / 1e6
    mbps = 8 * nbytes / max(fin - inicio, 1e-9) / 1e6
    return f'[  5] {inicio:6.2f}-{fin:<6.2f} sec  {mbytes:6.2f} MBytes  {mbps:6.2f} Mbits/sec  {extra}\n'


def emisor(a):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, BUFFER)
    relleno = b'\0' * (a.tamano - CABECERA.size)
    intervalo = a.tamano * 8 / (a.tasa * 1e6)
    log = open(a.log, 'w', buffering=1)
    log.write(f'Emisor UDP de tasa constante -> {a.destino}:{a.puerto} | {a.tasa:g} Mbps | {a.tamano} B\n')
    seq = 0
    t0 = time.perf_counter()
    siguiente = t0
    corte, nbytes, paquetes, omitidos = 1.0, 0, 0, 0
    while True:
        ahora = time.perf_counter()
        if ahora < siguiente:
            time.sleep(siguiente - ahora)
            ahora = time.perf_counter()
        if ahora - siguiente > ATRASO_MAXIMO:
            omitidos += int((ahora - siguiente) / intervalo)   # no se envian ni se numeran
            siguiente = ahora
        try:
            s.sendto(CABECERA.pack(seq) + relleno, (a.destino, a.puerto))
            nbytes += a.tamano
            paquetes += 1
        except (BlockingIOError, OSError):
            pass
        seq += 1
        siguiente += intervalo
        if ahora - t0 >= corte:
            log.write(linea(corte - 1, corte, nbytes, f'{paquetes}  omitidos {omitidos}'))
            corte += 1.0
            nbytes, paquetes, omitidos = 0, 0, 0


def receptor(a):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUFFER)
    s.bind(('0.0.0.0', a.puerto))
    s.settimeout(0.2)
    log = open(a.log, 'w', buffering=1)
    log.write(f'Receptor UDP en el puerto {a.puerto}\n')
    t0 = None
    corte = 1.0
    nbytes = recibidos = 0
    maximo = previo = -1
    while True:
        try:
            datos, _ = s.recvfrom(65535)
            if t0 is None:
                t0 = time.time()
                log.write(f'inicio {t0:.6f}\n')
            nbytes += len(datos)
            recibidos += 1
            maximo = max(maximo, CABECERA.unpack_from(datos)[0])
        except socket.timeout:
            pass
        if t0 is None:
            continue
        while time.time() - t0 >= corte:
            esperados = max(maximo - previo, 0)
            perdidos = max(esperados - recibidos, 0)
            pct = 100.0 * perdidos / esperados if esperados else 0.0
            log.write(linea(corte - 1, corte, nbytes, f'0.000 ms  {perdidos}/{esperados} ({pct:.2g}%)'))
            previo = maximo
            corte += 1.0
            nbytes = recibidos = 0


def main():
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='modo', required=True)
    e = sub.add_parser('emisor')
    e.add_argument('--destino', required=True)
    e.add_argument('--puerto', type=int, required=True)
    e.add_argument('--tasa', type=float, required=True, help='Mbps de carga util')
    e.add_argument('--tamano', type=int, default=1200)
    e.add_argument('--log', default='/dev/null')
    r = sub.add_parser('receptor')
    r.add_argument('--puerto', type=int, required=True)
    r.add_argument('--log', default='/dev/null')
    a = p.parse_args()
    try:
        emisor(a) if a.modo == 'emisor' else receptor(a)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
