#!/usr/bin/env python3
"""Calculo manual de la utilizacion y la MLU a partir de un ultimo_ciclo.json de FORT.

Desarrolla la formula enlace por enlace con los datos medidos y la compara con
los valores que reporto FORT, para la captura (seleccion del Target) y para la
evaluacion (despues de instalar).

    U(e) = ( fondo(e) + suma de d(i) de las comunicaciones i que cruzan e ) / C(e) x 100
    MLU  = maximo de U(e) sobre todos los enlaces

Uso: python3 calculo_manual.py ruta/ultimo_ciclo.json [ruta/salida.txt]
"""
import json
import sys


def nombre(hosts, clave):
    o, d = clave.split('>')
    return f"{hosts.get(o, {}).get('nombre', o)} -> {hosts.get(d, {}).get('nombre', d)}"


def calcular(arcos, capacidades, fondo, demandas, rutas):
    """Devuelve, por enlace, (lista de terminos, carga, utilizacion)."""
    detalle = []
    for j, enlace in enumerate(arcos):
        terminos = [(k, demandas[k]) for k in sorted(rutas) if enlace in rutas[k] and demandas[k] > 0.005]
        carga = fondo[j] + sum(v for _, v in terminos)
        detalle.append((enlace, terminos, fondo[j], carga, 100.0 * carga / capacidades[j]))
    return detalle


def bloque(lineas, titulo, hosts, arcos, capacidades, fondo, demandas, rutas_ff, rutas_fort, observada=None):
    ff = calcular(arcos, capacidades, fondo, demandas, rutas_ff)
    fort = calcular(arcos, capacidades, fondo, demandas, rutas_fort)
    lineas.append(titulo)
    lineas.append('  Paso 1. Demanda de cada comunicacion con trafico (d, Mbps)')
    for k in sorted(demandas, key=lambda k: nombre(hosts, k)):
        if demandas[k] > 0.005:
            lineas.append(f'    d({nombre(hosts, k)}) = {demandas[k]:.2f}')
    lineas.append('  Paso 2. Carga y utilizacion de cada enlace con trafico (C = capacidad)')
    for (enlace, t_ff, f, c_ff, u_ff), (_, t_fo, _, c_fo, u_fo), cap in zip(ff, fort, capacidades):
        if c_ff < 0.01 and c_fo < 0.01:
            continue
        lineas.append(f'    {enlace} (C = {cap:g} Mbps)')
        for etiqueta, terminos, carga, u in (('FF  ', t_ff, c_ff, u_ff), ('FORT', t_fo, c_fo, u_fo)):
            partes = [f'{v:.2f}' for _, v in terminos] + ([f'{f:.2f} (fondo)'] if f > 0.005 else [])
            suma = ' + '.join(partes) if partes else '0'
            quienes = ', '.join(nombre(hosts, k) for k, _ in terminos) or 'sin comunicaciones'
            lineas.append(f'      {etiqueta}: {suma} = {carga:.2f} Mbps -> {carga:.2f} / {cap:g} = {u:.2f} %'
                          f'   [{quienes}]')
    mlu_ff = max(ff, key=lambda x: x[4])
    mlu_fo = max(fort, key=lambda x: x[4])
    lineas.append('  Paso 3. MLU = utilizacion del enlace mas cargado')
    lineas.append(f'    MLU FF   = {mlu_ff[4]:.2f} % en {mlu_ff[0]}')
    lineas.append(f'    MLU FORT = {mlu_fo[4]:.2f} % en {mlu_fo[0]}')
    if observada is not None:
        lineas.append(f'    MLU FORT medida por la red = {observada:.2f} %')
    return mlu_ff[4], mlu_fo[4]


def generar(ruta_json):
    r = json.load(open(ruta_json, encoding='utf-8'))
    hosts = r.get('hosts', {})
    res, cap = r.get('resultado') or {}, r.get('captura') or {}
    lineas = [f"CALCULO MANUAL | FORT {r.get('fort')} | ciclo {r.get('ciclo')} | modo {r.get('modo')} | "
              f"{r.get('escrito')}",
              'Formula: U(e) = (fondo(e) + suma de d(i) que cruzan e) / C(e) x 100 ; MLU = maximo de U(e)',
              'd(i) incluye los 4 bytes de la etiqueta VLAN de los respaldos; por eso es algo mayor que el ingreso.',
              '']
    if not cap:
        return '\n'.join(lineas + ['El registro no contiene una captura.'])
    arcos_c = cap['arcos']
    capac_c = [e['capacidad'] for e in cap['modelo']['enlaces']]
    fondo_c = cap['modelo']['fondo']
    flujos_c = cap['modelo']['flujos']
    rutas_ff = {f['id']: [arcos_c[i] for i in f['ruta']] for f in flujos_c}
    rutas_fort = ({k: [arcos_c[i] for i in v] for k, v in res['rutas'].items()} if res.get('rutas')
                  else dict(rutas_ff))
    lineas.append('Rutas comparadas')
    for k in sorted(rutas_ff, key=lambda k: nombre(hosts, k)):
        cambia = rutas_ff[k] != rutas_fort[k]
        lineas.append(f"  {nombre(hosts, k)}: FF {' | '.join(rutas_ff[k]) or 'local'}"
                      + (f"  =>  FORT {' | '.join(rutas_fort[k])}" if cambia else '  (sin cambio)'))
    lineas.append('')
    comparacion = []
    mff, mfo = bloque(lineas, f"A. CAPTURA POST FF (seleccion del Target) | carga medida {cap['carga']:.2f} Mbps",
                      hosts, arcos_c, capac_c, fondo_c, {f['id']: f['demanda'] for f in flujos_c},
                      rutas_ff, rutas_fort)
    comparacion.append(('Captura: MLU FF', mff, res.get('referencia')))
    if res.get('rutas'):
        comparacion.append(('Captura: MLU del Target', mfo, res.get('mlu')))
    lineas.append('')
    fin, ev = r.get('final'), r.get('evaluacion')
    if fin and ev:
        arcos_f = fin['arcos']
        en_captura = {e: i for i, e in enumerate(arcos_c)}
        fondo_f = [fondo_c[en_captura[e]] if e in en_captura else 0.0 for e in arcos_f]
        capac_f = [e['capacidad'] for e in fin['modelo']['enlaces']]
        mff, mfo = bloque(lineas, f"B. EVALUACION DESPUES DE INSTALAR (misma carga para FF y FORT) | carga medida "
                          f"{ev['carga']:.2f} Mbps ({ev['variacion']:+.2f} % respecto de la captura)",
                          hosts, arcos_f, capac_f, fondo_f,
                          {f['id']: f['demanda_media'] for f in fin['modelo']['flujos']}, rutas_ff, rutas_fort,
                          ev['mlu_observada'])
        comparacion += [('Evaluacion: MLU FF calculada', mff, ev['mlu_ff']),
                        ('Evaluacion: MLU FORT calculada', mfo, ev['mlu_fort'])]
        lineas.append(f"    Reduccion = {mff:.2f} - {ev['mlu_observada']:.2f} = {mff - ev['mlu_observada']:.2f} pp "
                      f"({100 * (mff - ev['mlu_observada']) / mff:.2f} %)" if mff > 0 else '')
        lineas.append('')
    else:
        lineas.append(f"B. Sin evaluacion posterior: decision de FORT {res.get('estado')} ({res.get('motivo')})")
        lineas.append('')
    lineas.append('C. CONTRASTE CALCULO MANUAL / VALOR REPORTADO POR FORT')
    for etiqueta, manual, fort in comparacion:
        if fort is None:
            continue
        lineas.append(f'  {etiqueta:<34} manual {manual:7.2f} % | FORT {fort:7.2f} % | diferencia {manual - fort:+.4f} pp')
    return '\n'.join(lineas)


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    texto = generar(sys.argv[1])
    if len(sys.argv) > 2:
        open(sys.argv[2], 'w', encoding='utf-8').write(texto + '\n')
    print(texto)


if __name__ == '__main__':
    main()
