#!/usr/bin/env bash
# Caso 3: saturacion del enlace mas cargado (3) y su linea base (3B). Caida de s1-s2.
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 3,3B caso3
