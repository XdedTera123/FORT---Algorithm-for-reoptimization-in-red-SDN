#!/usr/bin/env bash
# Calibracion: una corrida de 1a, 1b, 1c y 3 para comprobar que FF deja s4->s2 cerca de 30, 60, 90 y 105 %.
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 1a,1b,1c,3 calibracion 1
