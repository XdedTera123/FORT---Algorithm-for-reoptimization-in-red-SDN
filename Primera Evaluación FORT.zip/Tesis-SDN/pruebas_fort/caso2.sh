#!/usr/bin/env bash
# Caso 2: independencia del enlace caido con carga de 60 % (2a: s1-s4, 2b: s2-s4, 2c: s4-s7).
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 2a,2b,2c caso2
