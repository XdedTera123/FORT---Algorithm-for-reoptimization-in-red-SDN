#!/usr/bin/env bash
# Caso 1: reoptimizacion con cargas de 30, 60 y 90 % (1a, 1b, 1c) y linea base al 60 % (1B). Caida de s1-s2.
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 1a,1b,1c,1B caso1
