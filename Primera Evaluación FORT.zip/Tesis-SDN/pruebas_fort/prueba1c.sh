#!/usr/bin/env bash
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 1c prueba1c 1
