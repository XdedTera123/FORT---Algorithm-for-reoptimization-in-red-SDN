#!/usr/bin/env bash
# Caso 4: una sola comunicacion; no existe mejora posible y FORT debe conservar FF.
source "$(dirname "$0")/config_pruebas.sh"
ejecutar 4 caso4
