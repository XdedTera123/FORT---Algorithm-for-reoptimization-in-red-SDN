#!/usr/bin/env bash
# Trafico UDP de tasa constante para las pruebas de FORT, desde una terminal independiente.
# Solo lanza y detiene trafico; los enlaces se bajan y suben desde Mininet (link s1 s2 down).
#
# Uso:
#   sudo ./trafico_fort.sh carga30    [factor]   caso 1a
#   sudo ./trafico_fort.sh carga60    [factor] [constante|iperf3]   casos 1b, 2, 5 y 6
#   sudo ./trafico_fort.sh carga90    [factor]   caso 1c
#   sudo ./trafico_fort.sh saturacion [factor]   caso 3
#   sudo ./trafico_fort.sh unica      [factor]   caso 4
#   sudo ./trafico_fort.sh detener
#
# factor multiplica todas las tasas (1 por defecto). El trafico sigue hasta ejecutar detener.
# Usa generador_udp.py (misma carpeta): tasa constante, sin rafagas de recuperacion.
# Los registros de cada receptor quedan en /tmp/trafico_fort/receptor_<origen>_<destino>.log

set -u
DIR=/tmp/trafico_fort
GENERADOR="$(cd "$(dirname "$0")" && pwd)/generador_udp.py"
PUERTO_BASE=5301
TAMANO=1200

if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta con sudo: sudo $0 $*" >&2
    exit 1
fi

en_host() {
    local host=$1; shift
    local pid
    pid=$(pgrep -f "mininet:$host\$" | head -n 1)
    if [ -z "$pid" ]; then
        echo "No se encontro el host $host. Inicia antes la topologia." >&2
        exit 1
    fi
    mnexec -a "$pid" "$@"
}

detener_iperf() {
    pkill -x iperf3 2>/dev/null
    pkill -f generador_udp.py 2>/dev/null || return 1
    for _ in $(seq 1 20); do
        pgrep -f generador_udp.py >/dev/null || return 0
        sleep 0.25
    done
    pkill -9 -f generador_udp.py 2>/dev/null
    sleep 0.5
    return 0
}

ip_host() {
    en_host "$1" ip -4 -o addr show dev "$1-eth0" | awk '{print $4}' | cut -d/ -f1
}

caso=${1:-}
case "$caso" in
    carga30)
        flujos="h1 h2 14.0
h1 h4 13.4
h2 h1 19.1
h3 h4 15.3
h4 h2 15.3"
        aviso="Caso 1a: baja s1-s2; FF dejara s4->s2 cerca de 30 %" ;;
    carga60)
        flujos="h1 h2 28.1
h1 h4 26.8
h2 h1 38.3
h3 h4 30.6
h4 h2 30.6"
        aviso="Casos 1b, 2, 5 y 6: con s1-s2 caido, FF dejara s4->s2 cerca de 60 %" ;;
    carga90)
        flujos="h1 h2 42.1
h1 h4 13.4
h2 h1 19.1
h3 h4 15.3
h4 h2 45.9"
        aviso="Caso 1c: baja s1-s2; FF dejara s4->s2 cerca de 90 %" ;;
    saturacion)
        flujos="h1 h2 50
h1 h4 13.4
h2 h1 19.1
h3 h4 15.3
h4 h2 55"
        aviso="Caso 3: baja s1-s2; s4->s2 quedara cerca de 105 %" ;;
    unica)
        flujos="h1 h2 30"
        aviso="Caso 4: baja s1-s2; FORT debe conservar FF" ;;
    detener)
        detener_iperf && echo "Trafico detenido" || echo "No habia trafico activo"
        exit 0 ;;
    *)
        sed -n '2,16p' "$0"
        exit 1 ;;
esac

factor=${2:-0.5}
modo=${3:-constante}   # constante (generador_udp.py) o iperf3
detener_iperf
rm -rf "$DIR"; mkdir -p "$DIR"
n=0; total=0
while read -r origen destino tasa; do
    puerto=$((PUERTO_BASE + n))
    mbps=$(awk -v t="$tasa" -v f="$factor" 'BEGIN{printf "%g", t*f}')
    en_host "$destino" sysctl -q -w net.core.wmem_max=16777216 net.core.rmem_max=16777216 >/dev/null 2>&1
    en_host "$origen" sysctl -q -w net.core.wmem_max=16777216 net.core.rmem_max=16777216 >/dev/null 2>&1
    if [ "$modo" = iperf3 ]; then
        en_host "$destino" iperf3 -s -p "$puerto" -1 -D -i 1 --logfile "$DIR/receptor_${origen}_${destino}.log"
        sleep 0.3
        en_host "$origen" setsid nohup iperf3 -u -c "$(ip_host "$destino")" -p "$puerto" -b "${mbps}M" \
            -l "$TAMANO" -t 0 --logfile "$DIR/emisor_${origen}_${destino}.log" </dev/null >/dev/null 2>&1 &
    else
        en_host "$destino" setsid nohup /usr/bin/python3 "$GENERADOR" receptor --puerto "$puerto" \
            --log "$DIR/receptor_${origen}_${destino}.log" </dev/null >/dev/null 2>&1 &
        sleep 0.3
        en_host "$origen" setsid nohup /usr/bin/python3 "$GENERADOR" emisor --destino "$(ip_host "$destino")" \
            --puerto "$puerto" --tasa "$mbps" --tamano "$TAMANO" \
            --log "$DIR/emisor_${origen}_${destino}.log" </dev/null >/dev/null 2>&1 &
    fi
    printf '%s -> %s | %s Mbps\n' "$origen" "$destino" "$mbps"
    total=$(awk -v a="$total" -v b="$mbps" 'BEGIN{printf "%g", a+b}')
    n=$((n + 1))
done <<< "$flujos"
tiempo="sin limite, hasta ejecutar detener"
echo "Trafico $caso ($modo) | carga total $total Mbps | $tiempo"
echo "$aviso"
