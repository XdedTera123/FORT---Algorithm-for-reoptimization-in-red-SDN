#!/usr/bin/env python3
"""Ejecucion automatica de los casos de validacion de FORT.

Normalmente se usa a traves de los scripts casoN.sh (ver config_pruebas.sh).
Cada corrida es independiente: limpia Mininet, inicia FORT y la topologia desde cero,
lanza el trafico UDP, baja el enlace, espera el fin del ciclo y de la evaluacion,
recupera el enlace, verifica que la proteccion FF original se reinstale y cierra todo.
Entre corridas hay un reposo configurable.

Por sesion se generan:
    tabla_comparativa.txt / .csv   una tabla por caso: repeticiones, media, desviacion,
                                   minimo, maximo y si cada corrida cumple el criterio
    corridas.csv                   todas las metricas de cada corrida
    resumen.csv                    estadisticos por caso y metrica
    caso_X/rep_N/                  consola de FORT, receptores UDP, ultimo_ciclo.json
                                   y calculo_manual.txt (evidencia de cada corrida)

Criterio de aprobacion (metodologia): estabilizacion alcanzada, precision <= 2 pp y entrega
minima >= 95 %; en las lineas base solo estabilizacion y precision; en el caso 4, conservar FF.

Uso directo (desde la carpeta del proyecto):
    sudo /usr/bin/python3 ejecutar_pruebas.py --casos 1b,1B --repeticiones 5 --capacidad 20 --factor 0.2

Casos: 1a, 1b y 1c (cargas de 30, 60 y 90 % con caida de s1-s2), 2a (s1-s4), 2b (s2-s4),
       2c (s4-s7), 3 (saturacion), 4 (sin mejora), 5 (doble caida, la segunda durante la
       optimizacion), 1B y 3B (linea base: FORT calcula el Target pero conserva FF).
"""
import argparse
import csv
import importlib.util
import json
import math
import os
import re
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import time
from pathlib import Path

# Niveles calibrados para que, al caer s1-s2, Fast Failover deje s4->s2 (el enlace mas
# cargado) en 30, 60 y 90 % de utilizacion, incluyendo los 4 bytes de la etiqueta VLAN.
PATRONES = {
    'carga30': [('h1', 'h2', 14.0), ('h1', 'h4', 13.4), ('h2', 'h1', 19.1), ('h3', 'h4', 15.3), ('h4', 'h2', 15.3)],
    'carga60': [('h1', 'h2', 28.1), ('h1', 'h4', 26.8), ('h2', 'h1', 38.3), ('h3', 'h4', 30.6), ('h4', 'h2', 30.6)],
    'carga90': [('h1', 'h2', 42.1), ('h1', 'h4', 13.4), ('h2', 'h1', 19.1), ('h3', 'h4', 15.3), ('h4', 'h2', 45.9)],
    'saturacion': [('h1', 'h2', 50), ('h1', 'h4', 13.4), ('h2', 'h1', 19.1), ('h3', 'h4', 15.3), ('h4', 'h2', 55)],
    'unica': [('h1', 'h2', 30)],
}

# caso: (descripcion, patron, enlaces a bajar, variables de entorno de FORT, repeticiones)
CASOS = {
    '1a': ('Carga de 30 %, caida de s1-s2', 'carga30', [('s1', 's2')], {}, 5),
    '1b': ('Carga de 60 %, caida de s1-s2', 'carga60', [('s1', 's2')], {}, 5),
    '1c': ('Carga de 90 %, caida de s1-s2', 'carga90', [('s1', 's2')], {}, 5),
    '1B': ('Linea base con carga de 60 % (FF conservado)', 'carga60', [('s1', 's2')], {'FORT_MODO': 'ff'}, 5),
    '2a': ('Carga de 60 %, caida de s1-s4', 'carga60', [('s1', 's4')], {}, 5),
    '2b': ('Carga de 60 %, caida de s2-s4', 'carga60', [('s2', 's4')], {}, 5),
    '2c': ('Carga de 60 %, caida de s4-s7', 'carga60', [('s4', 's7')], {}, 5),
    '3': ('Saturacion de s4->s2', 'saturacion', [('s1', 's2')], {}, 5),
    '3B': ('Linea base de saturacion (FF conservado)', 'saturacion', [('s1', 's2')], {'FORT_MODO': 'ff'}, 5),
    '4': ('Sin mejora posible', 'unica', [('s1', 's2')], {}, 5),
    '5': ('Segunda caida durante la reoptimizacion, carga de 60 %', 'carga60', [('s1', 's2'), ('s4', 's7')], {}, 5),
}
LINEA_BASE = {'1B', '3B'}
SIN_MEJORA = {'4'}
ORDEN = ['1a', '1b', '1c', '1B', '2a', '2b', '2c', '3', '3B', '4', '5']
PATRON_IPERF = re.compile(r'(\d+\.\d+)-(\d+\.\d+)\s+sec.*?(\d+)/(\d+)\s+\(')


def log(texto):
    print(time.strftime('%H:%M:%S') + ' | ' + texto, flush=True)


class Consola:
    """Lee la consola de FORT a medida que crece y registra cuando aparece cada evento."""

    def __init__(self, ruta):
        self.ruta = ruta
        self.texto = ''
        self.eventos = []

    def leer(self):
        try:
            with open(self.ruta, encoding='utf-8', errors='replace') as archivo:
                archivo.seek(len(self.texto.encode('utf-8', errors='replace')))
                nuevo = archivo.read()
        except OSError:
            return
        if nuevo:
            ahora = time.time()
            for linea in nuevo.splitlines():
                m = re.match(r'\[FORT-[^\]]+\] (\w+)', linea)
                if m:
                    self.eventos.append((ahora, m.group(1), linea))
            self.texto += nuevo

    def esperar(self, evento, desde, limite, tambien=()):
        """Espera un evento posterior al instante 'desde'; devuelve (evento, instante) o (None, None)."""
        fin = time.time() + limite
        buscados = (evento,) + tuple(tambien)
        while time.time() < fin:
            self.leer()
            for instante, nombre, _ in self.eventos:
                if instante >= desde and nombre in buscados:
                    return nombre, instante
            time.sleep(0.5)
        return None, None

    def contar(self, evento, desde=0.0):
        self.leer()
        return sum(1 for instante, nombre, linea in self.eventos
                   if instante >= desde and (nombre == evento or evento in linea))


def cargar_topologia(ruta):
    spec = importlib.util.spec_from_file_location('topologia_fort', ruta)
    modulo = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(ruta).parent))
    spec.loader.exec_module(modulo)
    return modulo


def puerto_libre(puerto, limite=30):
    fin = time.time() + limite
    while time.time() < fin:
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(('127.0.0.1', puerto))
                return True
            except OSError:
                time.sleep(1)
    return False


GENERADOR = str(Path(__file__).resolve().parent / 'generador_udp.py')


def limpiar_mininet():
    subprocess.run(['mn', '-c'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    subprocess.run(['pkill', '-x', 'iperf3'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    subprocess.run(['pkill', '-f', 'generador_udp.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                   check=False)


def grupos_ff():
    total = 0
    salida = subprocess.run(['ovs-vsctl', 'list-br'], capture_output=True, text=True, check=False).stdout
    for sw in salida.split():
        grupos = subprocess.run(['ovs-ofctl', '-O', 'OpenFlow13', 'dump-groups', sw],
                                capture_output=True, text=True, check=False).stdout
        total += grupos.count('type=ff')
    return total


def perdidas(registros, inicio, fin):
    """Paquetes perdidos y enviados en [inicio, fin) segun los receptores UDP (hora absoluta)."""
    perdidos = enviados = 0
    for ruta, comienzo in registros:
        try:
            lineas = Path(ruta).read_text(errors='replace').splitlines()
        except OSError:
            continue
        for linea in lineas:
            if 'receiver' in linea or 'sender' in linea:
                continue
            m = PATRON_IPERF.search(linea)
            if not m:
                continue
            a = comienzo + float(m.group(1))
            perdido, total = int(m.group(3)), int(m.group(4))
            if inicio <= a < fin and 0 <= perdido <= total:
                perdidos += perdido
                enviados += total
    return perdidos, enviados


def porcentaje(par):
    perdidos, enviados = par
    return round(100.0 * perdidos / enviados, 3) if enviados else None


def una_corrida(args, caso, repeticion, carpeta, modulo):
    descripcion, patron, enlaces, entorno, _ = CASOS[caso]
    fila = dict(caso=caso, repeticion=repeticion, descripcion=descripcion, patron=patron, trafico=args.trafico,
                tamano=args.tamano,
                factor=args.factor, enlace=' y '.join(f'{a}-{b}' for a, b in enlaces), estado='INICIADA')
    carpeta.mkdir(parents=True, exist_ok=True)
    consola_ruta = carpeta / 'consola_fort.txt'
    registro = carpeta / 'ultimo_ciclo.json'
    limpiar_mininet()
    if not puerto_libre(6653):
        fila['estado'] = 'PUERTO_6653_OCUPADO'
        return fila
    env = dict(os.environ, OSKEN_HUB_TYPE='eventlet', FORT_REGISTRO=str(registro),
               FORT_EVALUACIONES=str(args.evaluaciones),
               FORT_INTERVALO_EVALUACION=f'{args.intervalo_evaluacion:g}')
    env.update(entorno)
    with open(consola_ruta, 'w') as salida:
        fort = subprocess.Popen([args.python, '-u', args.fort], cwd=args.proyecto, env=env,
                                stdout=salida, stderr=subprocess.STDOUT, start_new_session=True)
    consola = Consola(consola_ruta)
    red = None
    procesos = []
    try:
        time.sleep(3)
        from mininet.net import Mininet
        from mininet.node import OVSSwitch, RemoteController
        red = Mininet(topo=modulo.TopologiaSDN(capacidad_mbps=modulo.leer_capacidad()), controller=None,
                      switch=OVSSwitch, link=modulo.EnlaceFORT, build=False, autoSetMacs=False,
                      autoStaticArp=False, waitConnected=False)
        red.addController('c0', controller=RemoteController, ip='127.0.0.1', port=6653)
        red.build()
        red.start()
        # Buffers de socket amplios: si un enlace se congestiona, la cola descarta paquetes
        # (como una red real) en lugar de bloquear al emisor y provocar rafagas de recuperacion.
        subprocess.run(['sysctl', '-q', '-w', 'net.core.wmem_max=16777216', 'net.core.rmem_max=16777216'],
                       check=False)
        for host in red.hosts:
            host.cmd('sysctl -q -w net.core.wmem_max=16777216 net.core.rmem_max=16777216 >/dev/null 2>&1')
        if args.mtu:
            # Tramas jumbo: la misma tasa en Mbps con muchos menos paquetes por segundo.
            for nodo in red.hosts + red.switches:
                for intf in nodo.intfList():
                    if intf.name != 'lo':
                        nodo.cmd(f'ip link set dev {intf.name} mtu {args.mtu} >/dev/null 2>&1')
        if args.sin_offload:
            for nodo in red.hosts + red.switches:
                for intf in nodo.intfList():
                    if intf.name != 'lo':
                        nodo.cmd(f'ethtool -K {intf.name} tx off rx off gso off tso off gro off >/dev/null 2>&1')
        time.sleep(6)
        lista = None
        for _ in range(6):
            red.pingAll(timeout=1)
            lista, _t = consola.esperar('RED_LISTA', 0, 20)
            if lista:
                break
        if not lista:
            fila['estado'] = 'SIN_RED_LISTA'
            return fila
        fila['grupos_ff_iniciales'] = grupos_ff()

        # Trafico UDP de tasa constante, sin limite de tiempo.
        registros = []
        for n, (o, d, tasa) in enumerate(PATRONES[patron]):
            puerto = 5301 + n
            destino = red.get(d)
            receptor = carpeta / f'receptor_{o}_{d}.log'
            emisor_log = str(carpeta / f'emisor_{o}_{d}.log')
            if args.trafico == 'iperf3':
                # iperf3 tal cual: mantiene el promedio y compensa los atrasos con rafagas.
                procesos.append(destino.popen(['iperf3', '-s', '-p', str(puerto), '-1', '-i', '1',
                                               '--logfile', str(receptor)]))
                time.sleep(0.3)
                procesos.append(red.get(o).popen(['iperf3', '-u', '-c', destino.IP(), '-p', str(puerto),
                                                  '-b', f'{tasa * args.factor:g}M', '-l', str(args.tamano), '-t', '0',
                                                  '--logfile', emisor_log]))
            else:
                procesos.append(destino.popen(['/usr/bin/python3', GENERADOR, 'receptor', '--puerto', str(puerto),
                                               '--log', str(receptor)]))
                time.sleep(0.3)
                procesos.append(red.get(o).popen(['/usr/bin/python3', GENERADOR, 'emisor', '--destino',
                                                  destino.IP(), '--puerto', str(puerto),
                                                  '--tasa', f'{tasa * args.factor:g}', '--tamano', str(args.tamano),
                                                  '--log', emisor_log]))
            registros.append((receptor, time.time()))
        fila['carga_ofrecida_mbps'] = round(sum(t for _, _, t in PATRONES[patron]) * args.factor, 3)
        time.sleep(args.espera_trafico)

        # Caida del enlace (o de los dos enlaces del caso 6).
        t_fallo = time.time()
        a, b = enlaces[0]
        red.configLinkStatus(a, b, 'down')
        log(f'   enlace {a}-{b} abajo')
        desde_fin = t_fallo
        if len(enlaces) > 1:
            # Caso 5: la segunda caida se provoca cuando FORT ya esta optimizando, no antes de capturar.
            evento, _t = consola.esperar(args.evento_segundo_fallo, t_fallo, 180)
            a2, b2 = enlaces[1]
            red.configLinkStatus(a2, b2, 'down')
            desde_fin = time.time()
            fila['segundo_fallo'] = f'{evento or "SIN_EVENTO"} +{desde_fin - t_fallo:.1f} s'
            log(f'   enlace {a2}-{b2} abajo ({fila["segundo_fallo"]})')
        fin_ciclo, t_fin = consola.esperar('CICLO_FINALIZADO', desde_fin, args.limite_ciclo)
        if not fin_ciclo:
            fila['estado'] = 'SIN_CICLO_FINALIZADO'
            return fila
        consola.leer()
        conservo = any(n == 'CONSERVAR_FF' and i >= t_fallo for i, n, _ in consola.eventos)
        t_eval = t_fin
        if not conservo:
            resumen, t_eval = consola.esperar('EVALUACION_RESUMEN', t_fin, args.limite_evaluacion,
                                              ('EVALUACION_INTERRUMPIDA',))
            t_eval = t_eval or time.time()
        fila['perdida_previa_pct'] = porcentaje(perdidas(registros, t_fallo - args.espera_trafico + 3, t_fallo))
        fila['perdida_fallo_a_fin_ciclo_pct'] = porcentaje(perdidas(registros, t_fallo, t_fin))
        fila['perdida_post_ciclo_pct'] = porcentaje(perdidas(registros, t_fin, t_eval))
        fila['duracion_ciclo_s'] = round(t_fin - t_fallo, 2)

        # Recuperacion y verificacion de la proteccion original.
        for p in procesos:
            p.terminate()
        procesos.clear()
        t_sube = time.time()
        for x, y in reversed(enlaces):
            red.configLinkStatus(x, y, 'up')
            time.sleep(3)
        ok, _t = consola.esperar('PROTECCION_FF', t_sube, 120)
        lista, _t = consola.esperar('RED_LISTA', t_sube, 120)
        fila['grupos_ff_recuperados'] = grupos_ff()
        fila['recuperacion_ok'] = bool(ok and lista and fila['grupos_ff_recuperados'] == fila['grupos_ff_iniciales'])
        fila['estado'] = 'COMPLETADA'
        return fila
    except Exception as error:  # una corrida fallida no detiene la sesion
        fila['estado'] = f'ERROR {type(error).__name__}: {error}'
        return fila
    finally:
        consola.leer()
        fila['switches_desconectados'] = consola.contar('SWITCH_DESCONECTADO')
        fila['pausas_medicion'] = consola.contar('PAUSA_DURANTE_LA_MEDICION')
        completar_desde_registro(fila, registro)
        guardar_calculo_manual(fila, registro, carpeta / 'calculo_manual.txt')
        if fila.get('modo_candidatos') == 'ACOTADO':
            completar_optimalidad(args, fila, registro)
        evaluar_aprobacion(fila)
        for p in procesos:
            p.terminate()
        if red is not None:
            try:
                red.stop()
            except Exception:
                pass
        try:
            os.killpg(fort.pid, signal.SIGTERM)
            fort.wait(timeout=10)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(fort.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        limpiar_mininet()


FACTOR_TRAMA = 1246 / 1200   # bytes por paquete en el enlace (con etiqueta VLAN) / carga util de iperf3
TOLERANCIA_ESTABLE = 0.10      # la misma variacion maxima que exige la estabilizacion


def evaluacion_estable(r, fila):
    """Promedia las evaluaciones continuas con la red en regimen estable: carga medida dentro de
    +-10 % de la carga ofrecida. Asi una rafaga transitoria no altera la comparacion."""
    oferta = fila.get('carga_ofrecida_mbps')
    # Solo las evaluaciones continuas (desde 10 s despues de instalar): la evaluacion inmediata
    # incluye el vaciado transitorio de las colas acumuladas durante Fast Failover.
    continuas = list(r.get('evaluacion_continua') or [])
    evaluaciones = [e for e in (continuas or [r.get('evaluacion')])
                    if isinstance(e, dict) and isinstance(e.get('carga'), (int, float))]
    if not oferta or not evaluaciones:
        return
    tamano = fila.get('tamano') or 1200
    referencia = oferta * (tamano + 46) / tamano   # cabeceras UDP, IP y Ethernet mas la etiqueta VLAN
    estables = [e for e in evaluaciones if abs(e['carga'] / referencia - 1) <= TOLERANCIA_ESTABLE]
    fila['evaluaciones_estables'] = f'{len(estables)}/{len(evaluaciones)}'
    cargas = [e['carga'] for e in evaluaciones]
    fila['carga_eval_min_mbps'], fila['carga_eval_max_mbps'] = min(cargas), max(cargas)
    if fila.get('trafico') == 'iperf3':
        # Trafico variable: se usan todas las evaluaciones continuas. Cada una compara FF y FORT
        # con la demanda medida en esa misma ventana, aunque esa demanda cambie entre ventanas.
        estables = evaluaciones
    fila['mlu_ff_primera_pct'] = fila.get('mlu_ff_calculada_pct')
    fila['carga_primera_mbps'] = fila.get('carga_eval_mbps')
    campos = ('carga_eval_mbps', 'mlu_ff_calculada_pct', 'mlu_fort_calculada_pct', 'mlu_observada_pct',
              'reduccion_pp', 'reduccion_pct', 'precision_max_pp', 'precision_media_pp', 'entrega_minima_pct')
    if not estables:
        for k in campos:
            fila[k] = None
        return
    media = lambda k: statistics.mean(e[k] for e in estables)
    entregas = [e['entrega_minima'] for e in estables if isinstance(e.get('entrega_minima'), (int, float))]
    fila.update(carga_eval_mbps=media('carga'), mlu_ff_calculada_pct=media('mlu_ff'),
                mlu_fort_calculada_pct=media('mlu_fort'), mlu_observada_pct=media('mlu_observada'),
                reduccion_pp=media('reduccion_pp'), reduccion_pct=media('reduccion_pct'),
                precision_max_pp=max(e['error_maximo'] for e in estables),
                precision_media_pp=media('error_medio'), entrega_minima_pct=min(entregas) if entregas else None)


def completar_desde_registro(fila, ruta):
    try:
        r = json.loads(Path(ruta).read_text())
    except (OSError, ValueError):
        return
    res = r.get('resultado') or {}
    cap = r.get('captura') or {}
    est = r.get('estabilizacion') or {}
    ev = r.get('evaluacion') or {}
    rec = r.get('recursos') or {}
    tiempos = r.get('tiempos') or {}
    res_eval = r.get('evaluacion_resumen') or {}
    elegido = next((t for t in res.get('targets', []) if t.get('id') == res.get('elegido')), {})
    fila.update(
        decision=res.get('estado'), motivo=res.get('motivo'),
        estabilizacion_alcanzada=est.get('estable'), variacion_captura_pct=est.get('variacion_total'),
        carga_captura_mbps=cap.get('carga'), mlu_ff_captura_pct=res.get('referencia'),
        mlu_optima_pct=res.get('z_opt'), mlu_target_pct=res.get('mlu'),
        modo_candidatos=(res.get('candidatos') or {}).get('modo'),
        caminos_candidatos=(res.get('candidatos') or {}).get('caminos'),
        targets_generados=len(res.get('targets', [])), comunicaciones_cambiadas=len(elegido.get('cambios', [])),
        carga_eval_mbps=ev.get('carga'), variacion_carga_pct=ev.get('variacion'),
        mlu_ff_calculada_pct=ev.get('mlu_ff'), mlu_fort_calculada_pct=ev.get('mlu_fort'),
        mlu_observada_pct=ev.get('mlu_observada'), precision_max_pp=ev.get('error_maximo'),
        precision_media_pp=ev.get('error_medio'), reduccion_pp=ev.get('reduccion_pp'),
        reduccion_pct=ev.get('reduccion_pct'), entrega_minima_pct=ev.get('entrega_minima'),
        reduccion_continua_media_pp=res_eval.get('reduccion_media'),
        precision_continua_max_pp=res_eval.get('error_maximo'),
        sin_respaldo_antes=rec.get('sin_respaldo_antes'), sin_respaldo_despues=rec.get('sin_respaldo_despues'),
        tiempo_calculo_s=tiempos.get('calculo'), tiempo_total_s=tiempos.get('transicion_fin'))
    evaluacion_estable(r, fila)


def guardar_calculo_manual(fila, registro, destino):
    """Desarrolla la formula de la MLU paso a paso y anota la mayor diferencia con FORT."""
    if not Path(registro).exists():
        return
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import calculo_manual
        texto = calculo_manual.generar(registro)
        destino.write_text(texto + '\n', encoding='utf-8')
        difs = [abs(float(m.group(1))) for m in re.finditer(r'diferencia ([+-]\d+\.\d+) pp', texto)]
        fila['diferencia_manual_max_pp'] = max(difs) if difs else None
    except Exception as error:
        destino.write_text(f'No se pudo generar el calculo manual: {error}\n', encoding='utf-8')


UMBRAL_PRECISION_PP = 2.0
UMBRAL_ENTREGA_PCT = 95.0


def completar_optimalidad(args, fila, registro):
    """Caso 5: resuelve el modelo completo con la misma captura y calcula eta = z*_acotado / z*_completo."""
    try:
        r = json.loads(Path(registro).read_text())
        modelo = dict(r['captura']['modelo'])
        parametros = dict(r['parametros']['solver'])
        parametros['limite_caminos'] = max(5000, int(parametros.get('limite_caminos', 0)))
        modelo['parametros'] = parametros
        salida = subprocess.run([args.python, '-u', args.fort, '--resolver'], input=json.dumps(modelo),
                                capture_output=True, text=True, timeout=600, cwd=args.proyecto)
        respuesta = json.loads(salida.stdout.strip().splitlines()[-1])
        completo = respuesta.get('z_opt')
        fila['mlu_optima_completa_pct'] = completo
        if completo and isinstance(fila.get('mlu_optima_pct'), (int, float)):
            fila['eta_optimalidad'] = round(fila['mlu_optima_pct'] / completo, 4)
    except Exception as error:
        fila['eta_optimalidad'] = None
        log(f'   no se pudo calcular eta: {type(error).__name__}: {error}')


def evaluar_aprobacion(fila):
    """Criterio de la metodologia: estabilizacion, precision <= 2 pp y entrega minima >= 95 %."""
    caso = fila['caso']
    base = caso in LINEA_BASE
    # En la linea base se observa FF y se calcula el Target; con FORT es al reves.
    fila['mlu_ff_tabla'] = fila.get('mlu_observada_pct') if base else fila.get('mlu_ff_calculada_pct')
    fila['mlu_fort_tabla'] = fila.get('mlu_fort_calculada_pct') if base else fila.get('mlu_observada_pct')
    motivos = []
    if fila.get('estado') != 'COMPLETADA':
        motivos.append(str(fila.get('estado')))
    if fila.get('switches_desconectados'):
        motivos.append('switches desconectados')
    if caso in SIN_MEJORA:
        if fila.get('decision') != 'CONSERVAR_FF':
            motivos.append('se esperaba conservar FF')
    else:
        if fila.get('estabilizacion_alcanzada') is not True:
            motivos.append('sin estabilizacion')
        p = fila.get('precision_max_pp')
        if str(fila.get('evaluaciones_estables', '')).startswith('0/') and fila.get('trafico') != 'iperf3':
            motivos.append('sin evaluacion con carga estable')
        elif not isinstance(p, (int, float)):
            motivos.append('sin evaluacion')
        elif p > UMBRAL_PRECISION_PP:
            motivos.append(f'precision {p:.2f} pp')
        e = fila.get('entrega_minima_pct')
        if not base and (not isinstance(e, (int, float)) or e < UMBRAL_ENTREGA_PCT):
            motivos.append('entrega ' + (f'{e:.1f} %' if isinstance(e, (int, float)) else 'sin dato'))
    fila['aprobado'] = 'NO' if motivos else 'SI'
    if fila.get('recuperacion_ok') is False:
        motivos.append('aviso: proteccion FF no restaurada al final')
    fila['motivo_aprobacion'] = '; '.join(motivos)


COLUMNAS_TABLA = [('Rep', 'repeticion'), ('Decision', 'decision'), ('MLU FF %', 'mlu_ff_tabla'),
                  ('MLU FORT %', 'mlu_fort_tabla'), ('Red. pp', 'reduccion_pp'), ('Red. %', 'reduccion_pct'),
                  ('Prec. pp', 'precision_max_pp'), ('Entrega %', 'entrega_minima_pct'),
                  ('Perd. ciclo %', 'perdida_fallo_a_fin_ciclo_pct'), ('Cambios', 'comunicaciones_cambiadas'),
                  ('Calc. s', 'tiempo_calculo_s'), ('Ciclo s', 'duracion_ciclo_s'), ('Carga min', 'carga_eval_min_mbps'),
                  ('Carga max', 'carga_eval_max_mbps'), ('Eval. est.', 'evaluaciones_estables'),
                  ('eta', 'eta_optimalidad'), ('2do fallo', 'segundo_fallo'), ('Aprobado', 'aprobado')]
DECISIONES = {'TARGET_SELECCIONADO': 'Target', 'CONSERVAR_FF': 'Conserva FF'}


def texto_valor(v):
    if isinstance(v, bool):
        return 'si' if v else 'no'
    if isinstance(v, float):
        return f'{v:.2f}'
    return '-' if v is None or v == '' else str(DECISIONES.get(v, v))


def escribir_tabla_comparativa(filas, ruta_txt, ruta_csv):
    """Una tabla por caso: cada repeticion y, debajo, media, desviacion estandar, minimo y maximo."""
    bloques, filas_csv = [], []
    for caso in [c for c in ORDEN if any(f['caso'] == c for f in filas)]:
        propias = [f for f in filas if f['caso'] == caso]
        columnas = [(t, k) for t, k in COLUMNAS_TABLA
                    if k in ('repeticion', 'aprobado') or any(f.get(k) not in (None, '') for f in propias)]
        completadas = [f for f in propias if f.get('estado') == 'COMPLETADA']
        renglones = [[texto_valor(f.get(k)) for _, k in columnas] for f in propias]
        for nombre, funcion in (('Media', statistics.mean), ('Desv. est.', None), ('Min.', min), ('Max.', max)):
            renglon = []
            for t, k in columnas:
                valores = [float(f[k]) for f in completadas
                           if isinstance(f.get(k), (int, float)) and not isinstance(f.get(k), bool)
                           and math.isfinite(f[k])]
                if k == 'repeticion':
                    renglon.append(nombre)
                elif k == 'aprobado':
                    renglon.append(f"{sum(f.get('aprobado') == 'SI' for f in propias)}/{len(propias)}"
                                   if nombre == 'Media' else '')
                elif not valores or k == 'decision':
                    renglon.append('')
                elif funcion is None:
                    renglon.append(f'{statistics.stdev(valores):.2f}' if len(valores) > 1 else '0.00')
                else:
                    renglon.append(f'{funcion(valores):.2f}')
            renglones.append(renglon)
        titulos = [t for t, _ in columnas]
        anchos = [max(len(titulos[i]), *(len(r[i]) for r in renglones)) for i in range(len(titulos))]
        linea = lambda r: ' | '.join(str(x).rjust(anchos[i]) for i, x in enumerate(r))
        separador = '-+-'.join('-' * a for a in anchos)
        texto = [f'CASO {caso}: {CASOS[caso][0]}', linea(titulos), separador]
        texto += [linea(r) for r in renglones[:len(propias)]] + [separador]
        texto += [linea(r) for r in renglones[len(propias):]]
        motivos = [f"  rep {f['repeticion']}: {f['motivo_aprobacion']}" for f in propias if f.get('motivo_aprobacion')]
        if motivos:
            texto += ['Observaciones:'] + motivos
        bloques.append('\n'.join(texto))
        filas_csv += [[caso] + r for r in [titulos] + renglones] + [[]]
    Path(ruta_txt).write_text('\n\n'.join(bloques) + '\n', encoding='utf-8')
    with open(ruta_csv, 'w', newline='') as archivo:
        csv.writer(archivo).writerows(filas_csv)
    return '\n\n'.join(bloques)


CAMPOS = ['caso', 'repeticion', 'descripcion', 'patron', 'factor', 'enlace', 'estado', 'aprobado',
          'motivo_aprobacion', 'trafico', 'decision', 'motivo', 'evaluaciones_estables', 'carga_eval_min_mbps',
          'carga_eval_max_mbps', 'mlu_ff_primera_pct',
          'carga_primera_mbps', 'segundo_fallo', 'mlu_optima_completa_pct', 'eta_optimalidad',
          'estabilizacion_alcanzada', 'variacion_captura_pct', 'carga_ofrecida_mbps', 'carga_captura_mbps',
          'mlu_ff_captura_pct', 'mlu_optima_pct', 'mlu_target_pct', 'modo_candidatos', 'caminos_candidatos',
          'targets_generados', 'comunicaciones_cambiadas', 'carga_eval_mbps', 'variacion_carga_pct',
          'mlu_ff_calculada_pct', 'mlu_fort_calculada_pct', 'mlu_observada_pct', 'precision_max_pp',
          'precision_media_pp', 'reduccion_pp', 'reduccion_pct', 'reduccion_continua_media_pp',
          'precision_continua_max_pp', 'entrega_minima_pct', 'perdida_previa_pct',
          'perdida_fallo_a_fin_ciclo_pct', 'perdida_post_ciclo_pct', 'sin_respaldo_antes',
          'sin_respaldo_despues', 'duracion_ciclo_s', 'tiempo_calculo_s', 'tiempo_total_s',
          'grupos_ff_iniciales', 'grupos_ff_recuperados', 'recuperacion_ok', 'switches_desconectados',
          'pausas_medicion', 'diferencia_manual_max_pp']
METRICAS = ['carga_eval_mbps', 'mlu_ff_calculada_pct', 'mlu_observada_pct', 'reduccion_pp', 'reduccion_pct',
            'precision_max_pp', 'entrega_minima_pct', 'perdida_fallo_a_fin_ciclo_pct', 'perdida_post_ciclo_pct',
            'comunicaciones_cambiadas', 'tiempo_calculo_s', 'duracion_ciclo_s', 'diferencia_manual_max_pp',
            'eta_optimalidad']


def escribir_resumen(filas, ruta):
    with open(ruta, 'w', newline='') as archivo:
        w = csv.writer(archivo)
        w.writerow(['caso', 'corridas_validas', 'metrica', 'media', 'desv_estandar', 'minimo', 'maximo'])
        for caso in ORDEN:
            validas = [f for f in filas if f['caso'] == caso and f.get('estado') == 'COMPLETADA'
                       and not f.get('switches_desconectados')]
            for m in METRICAS:
                valores = [float(f[m]) for f in validas if isinstance(f.get(m), (int, float)) and math.isfinite(f[m])]
                if not valores:
                    continue
                desv = statistics.stdev(valores) if len(valores) > 1 else 0.0
                w.writerow([caso, len(validas), m, round(statistics.mean(valores), 3), round(desv, 3),
                            round(min(valores), 3), round(max(valores), 3)])


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--casos', default=','.join(ORDEN), help='lista separada por comas (por defecto, todos)')
    p.add_argument('--repeticiones', type=int, help='repeticiones por caso (por defecto, 5)')
    p.add_argument('--factor', type=float, default=1.0, help='multiplica todas las tasas de trafico')
    p.add_argument('--capacidad', type=float, help='capacidad de los enlaces en Mbps (escala junto con --factor)')
    p.add_argument('--proyecto', default='.', help='carpeta del proyecto (por defecto, la actual)')
    p.add_argument('--fort', default='Algoritmos/FORT_V1_1.py')
    p.add_argument('--topologia', default='Topologias/Topologia_V1.py')
    p.add_argument('--python', default='.venv/bin/python', help='Python del entorno de FORT')
    p.add_argument('--salida', default='~/fort_resultados')
    p.add_argument('--espera-trafico', type=float, default=20.0, help='segundos de trafico antes de la caida')
    p.add_argument('--evaluaciones', type=int, default=5, help='ventanas de evaluacion continua')
    p.add_argument('--intervalo-evaluacion', type=float, default=10.0, help='segundos entre evaluaciones continuas')
    p.add_argument('--evento-segundo-fallo', default='OPTIMIZACION',
                   help='evento de FORT tras el cual se baja el segundo enlace del caso 5')
    p.add_argument('--pausa', type=float, default=15.0, help='segundos de reposo entre corridas')
    p.add_argument('--tamano', type=int, default=1200, help='bytes de carga util por datagrama UDP')
    p.add_argument('--mtu', type=int, default=0, help='MTU de todas las interfaces (0 = sin cambio; 9000 = jumbo)')
    p.add_argument('--trafico', choices=('constante', 'iperf3'), default='constante',
                   help='constante: generador_udp.py; iperf3: iperf3 UDP con sus variaciones')
    p.add_argument('--etiqueta', default='sesion', help='prefijo de la carpeta de resultados')
    p.add_argument('--limite-ciclo', type=float, default=420.0)
    p.add_argument('--limite-evaluacion', type=float, default=180.0)
    p.add_argument('--sin-offload', action='store_true', help='desactiva offload en las interfaces')
    args = p.parse_args()

    if os.geteuid() != 0:
        sys.exit('Ejecuta con sudo: sudo /usr/bin/python3 ejecutar_pruebas.py')
    for herramienta in ('mn', 'iperf3', 'ovs-ofctl'):
        if shutil.which(herramienta) is None:
            sys.exit(f'Falta {herramienta}')
    args.proyecto = str(Path(args.proyecto).resolve())
    for campo in ('fort', 'topologia', 'python'):
        ruta = Path(getattr(args, campo))
        if not ruta.is_absolute():
            ruta = Path(args.proyecto) / ruta
        if not ruta.exists():
            sys.exit(f'No existe {ruta} (usa --{campo})')
        setattr(args, campo, str(ruta))
    casos = [c.strip() for c in args.casos.split(',') if c.strip()]
    desconocidos = [c for c in casos if c not in CASOS]
    if desconocidos:
        sys.exit('Casos desconocidos: ' + ', '.join(desconocidos) + ' | validos: ' + ', '.join(ORDEN))

    usuario = os.environ.get('SUDO_USER')
    base = Path(os.path.expanduser(f'~{usuario}' if usuario else '~')) if args.salida.startswith('~') else None
    salida = (base / args.salida[2:]) if base else Path(args.salida)
    sesion = salida / time.strftime(f'{args.etiqueta}_%Y%m%d_%H%M%S')
    sesion.mkdir(parents=True, exist_ok=True)
    if args.capacidad is not None:
        config = sesion / 'fort_config.json'
        config.write_text(json.dumps({'capacidad_enlace_mbps': args.capacidad}))
        os.environ['FORT_CONFIG'] = str(config)

    from mininet.log import setLogLevel
    setLogLevel('warning')
    modulo = cargar_topologia(args.topologia)
    plan = [(c, r) for c in casos for r in range(1, (args.repeticiones or CASOS[c][4]) + 1)]
    log(f'Sesion {sesion} | {len(plan)} corridas | trafico {args.trafico} | datagrama {args.tamano} B'
        + (f' | MTU {args.mtu}' if args.mtu else '') + f' | factor {args.factor:g}'
        + (f' | capacidad {args.capacidad:g} Mbps' if args.capacidad else ''))
    (sesion / 'parametros.json').write_text(json.dumps(vars(args), indent=1))
    filas = []
    tabla = sesion / 'corridas.csv'
    for numero, (caso, rep) in enumerate(plan, 1):
        log(f'[{numero}/{len(plan)}] caso {caso} repeticion {rep}: {CASOS[caso][0]}')
        inicio = time.time()
        fila = una_corrida(args, caso, rep, sesion / f'caso_{caso}' / f'rep_{rep}', modulo)
        filas.append(fila)
        with open(tabla, 'w', newline='') as archivo:
            w = csv.DictWriter(archivo, fieldnames=CAMPOS, extrasaction='ignore')
            w.writeheader()
            w.writerows(filas)
        escribir_resumen(filas, sesion / 'resumen.csv')
        texto_tabla = escribir_tabla_comparativa(filas, sesion / 'tabla_comparativa.txt',
                                                 sesion / 'tabla_comparativa.csv')
        detalle = (f"MLU FF {texto_valor(fila.get('mlu_ff_tabla'))} % -> FORT {texto_valor(fila.get('mlu_fort_tabla'))} % | "
                   f"precision {texto_valor(fila.get('precision_max_pp'))} pp"
                   if fila.get('mlu_observada_pct') is not None else f"decision {fila.get('decision')}")
        aviso = ' | ATENCION: switches desconectados' if fila.get('switches_desconectados') else ''
        log(f'   {fila["estado"]} en {time.time() - inicio:.0f} s | aprobado {fila.get("aprobado")} | {detalle}{aviso}')
        if numero < len(plan) and args.pausa > 0:
            log(f'   reposo de {args.pausa:g} s antes de la siguiente corrida')
            time.sleep(args.pausa)
    if usuario:
        subprocess.run(['chown', '-R', f'{usuario}:', str(salida)], check=False)
    print('\n' + texto_tabla + '\n', flush=True)
    log(f'Terminado. Tabla comparativa en {sesion / "tabla_comparativa.txt"} (y .csv); '
        f'detalle por corrida en {tabla}')


if __name__ == '__main__':
    main()
