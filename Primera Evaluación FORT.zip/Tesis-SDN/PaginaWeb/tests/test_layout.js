const assert=require('assert');
const layout=require('../app/web/layout.js');
function run(name, switches, edges, hosts){
 const es=edges.map((e,i)=>({id:e.join('-'),origen:e[0],destino:e[1],estado:'arriba'}));
 const l=layout.compute(switches,es,hosts);let overlap=[];
 for(let i=0;i<l.nodes.length;i++)for(let j=i+1;j<l.nodes.length;j++){
  const a=l.nodes[i],b=l.nodes[j],pa=l.positions[a.id],pb=l.positions[b.id];
  if(Math.abs(pa[0]-pb[0])<(a.width+b.width)/2+5 && Math.abs(pa[1]-pb[1])<(a.height+b.height)/2+5)overlap.push([a.id,b.id]);
 }
 for(const node of l.nodes){const p=l.positions[node.id];assert(p&&p[0]>=0&&p[0]<=l.width&&p[1]>=0&&p[1]<=l.height,`${name}: fuera de lienzo ${node.id}`)}
 console.log(name,`switches=${switches.length}, hosts=${hosts.length}, enlaces=${edges.length}, colisiones=${overlap.length}, lienzo=${l.width}x${l.height}`);
 assert.deepStrictEqual(overlap,[],`${name}: nodos superpuestos`);
 assert.deepStrictEqual(layout.compute(switches,es,hosts).positions,l.positions,`${name}: layout no determinista`);
}
const n=(x)=>Array.from({length:x},(_,i)=>'s'+(i+1));
const V1=[['s1','s2'],['s1','s3'],['s1','s4'],['s2','s4'],['s2','s5'],['s3','s4'],['s3','s6'],['s4','s5'],['s4','s7'],['s5','s8'],['s6','s7'],['s7','s8']];
const V2=[...Array.from({length:5},(_,i)=>['s'+(i+1),'s'+(i+6)]),...Array.from({length:5},(_,i)=>['s11','s'+(i+1)]),...Array.from({length:5},(_,i)=>['s12','s'+(i+6)]),...Array.from({length:4},(_,i)=>['s'+(i+1),'s'+(i+2)]),...Array.from({length:4},(_,i)=>['s'+(i+6),'s'+(i+7)])];
const h=(switches)=>switches.map((s,i)=>({nombre:'h'+(i+1),switch:s,puerto:1,ip:`10.0.0.${i+1}`}));
run('Un switch',n(1),[],h(['s1']));
run('Topologia V1',n(8),V1,h(['s1','s2','s5','s7']));
run('Topologia V2',n(12),V2,h(['s11','s12']));
run('Cadena de 20',n(20),Array.from({length:19},(_,i)=>['s'+(i+1),'s'+(i+2)]),h(['s1','s10','s20']));
run('Malla 6 x 6',n(36),[...Array.from({length:36},(_,i)=>i%6<5?['s'+(i+1),'s'+(i+2)]:null),...Array.from({length:30},(_,i)=>['s'+(i+1),'s'+(i+7)])].filter(Boolean),h(['s1','s8','s20','s36']));
run('Estrella con 15 hosts',n(16),Array.from({length:15},(_,i)=>['s1','s'+(i+2)]),h(Array.from({length:15},(_,i)=>'s'+(i+2))));
