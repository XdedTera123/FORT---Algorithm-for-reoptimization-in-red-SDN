"""Pruebas locales sin Mininet: descubrimiento, trazas y API de solo lectura."""
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from topologia_dinamica import pares_veth, descubrir
from descubrimiento_hosts import descubrir_hosts, namespace_aislado
from servidor import metricas, Solicitud, Estado
from trazabilidad import Observer, flow_entries, parse_groups, resolve_path
from telemetria import analizar_salida, calcular

P=0x464F000000000000

def ingreso(src,dst,port,mb=100000):
 return (f'cookie=0x{P+11:x}, duration=5.2s, table=0, n_packets=100, n_bytes={mb}, '
         f'priority=400,in_port={port},ip,nw_src={src},nw_dst={dst} '
         f'actions=push_vlan:0x8100,set_field:4097->vlan_vid,output:2')
def egreso(src,dst,port):
 return (f'cookie=0x{P+12:x}, duration=5.2s, table=0, n_packets=100, n_bytes=95000, '
         f'priority=300,vlan_tci=0x1001/0x1fff,ip,nw_src={src},nw_dst={dst} '
         f'actions=pop_vlan,output:{port}')

class Tests(unittest.TestCase):
 def test_tx(self):
  out='OFPST_PORT reply:\n port 2: rx pkts=1, bytes=55\n  tx pkts=2, bytes=10000\n'
  self.assertEqual(analizar_salida(out,'s1'),{('s1',2):10000})
 def test_metricas_caido(self):
  e=dict(id='s1-s2',origen='s1',destino='s2',puerto_origen=2,puerto_destino=2,estado='caido')
  a=({('s1',2):1000,('s2',2):1000},{'s1':1,'s2':1})
  b=({('s1',2):2000,('s2',2):2000},{'s1':2,'s2':2})
  self.assertIsNone(metricas(a,b,[e],[dict(e,estado='arriba')],100)[0]['ida']['porcentaje'])
 def test_hosts_desconocidos_no_inventados(self):
  access=[dict(switch='s9',puerto=3,ifindex=111,peer_ifindex=112)]
  with patch('descubrimiento_hosts.procesos_mininet',return_value={}):
   h=descubrir_hosts(access)['hosts'][0]
  self.assertEqual(h['switch'],'s9')
  self.assertIsNone(h['ip'])
  self.assertFalse(h['confirmado'])
 def test_hosts_namespace_cualquier_puerto(self):
  access=[dict(switch='s11',puerto=5,ifindex=43,peer_ifindex=44)]
  interface=[dict(ifindex=44,link_index=43,address='00:00:00:00:00:11',addr_info=[dict(family='inet',local='10.0.1.50')])]
  with patch('descubrimiento_hosts.procesos_mininet',return_value={'h50':1234}),patch('descubrimiento_hosts.interfaces_namespace',return_value=interface):
   h=descubrir_hosts(access)['hosts'][0]
  self.assertEqual((h['nombre'],h['ip'],h['puerto']),('h50','10.0.1.50',5))
 def test_hosts_inferidos_por_flujos(self):
  access=[dict(switch='s4',puerto=5,ifindex=11,peer_ifindex=12)]
  with patch('descubrimiento_hosts.procesos_mininet',return_value={}):
   h=descubrir_hosts(access,[dict(switch='s4',puerto=5,ip='172.20.1.3')])['hosts'][0]
  self.assertEqual(h['ip'],'172.20.1.3')
 def test_resolver_sin_puerto_uno(self):
  src='10.10.0.30'; dst='10.10.0.20'
  links=[dict(origen='s10',puerto_origen=2,destino='s11',puerto_destino=2,estado='arriba',id='s10-s11')]
  flows={'s10':flow_entries(ingreso(src,dst,7)), 's11':flow_entries(egreso(src,dst,8))}
  hosts={src:(src,'s10',7),dst:(dst,'s11',8)}
  path,ff,why=resolve_path(src,dst,flows,{'s10':{},'s11':{}},links,hosts=hosts)
  self.assertEqual(len(path),1)
  self.assertEqual(why,'RUTA_RECONSTRUIDA_OVS')
 def test_observer_dos_hosts_dinamicos(self):
  src='10.10.0.30';dst='10.10.0.20'
  links=[dict(origen='s10',puerto_origen=2,destino='s11',puerto_destino=2,estado='arriba',id='s10-s11')]
  hosts=[dict(ip=src,switch='s10',puerto=7),dict(ip=dst,switch='s11',puerto=8)]
  def fake(*args):
   if 'dump-groups' in args:return ''
   return ingreso(src,dst,7) if args[-1]=='s10' else egreso(src,dst,8)
  with patch('trazabilidad.command',side_effect=fake):
   obs=Observer();a=obs.sample(['s10','s11'],links,hosts)
   self.assertEqual(len(a['comunicaciones']),2)
   self.assertEqual(a['rutas_reconstruidas'],1)
   self.assertEqual(a['ingresos_detectados'],1)
 def test_sin_troncal_es_topologia_valida(self):
  with patch('topologia_dinamica.comando',side_effect=['s1\n','s1-eth1\n']),patch('topologia_dinamica.leer_entero',side_effect=lambda x:51 if x.name=='ifindex' else 52):
   d=descubrir()
  self.assertEqual(d['enlaces'],[])
  self.assertEqual(len(d['accesos']),1)
 def test_proceso_en_namespace_raiz_no_es_host(self):
  with patch('descubrimiento_hosts.os.readlink',side_effect=lambda path: 'net:[42]'):
   self.assertFalse(namespace_aislado(200))
  with patch('descubrimiento_hosts.os.readlink',side_effect=lambda path: 'net:[99]' if path.startswith('/proc/200/') else 'net:[42]'):
   self.assertTrue(namespace_aislado(200))
 def test_cambio_topologia_no_deja_enlaces_fantasma(self):
  sample=lambda id: dict(id=id,origen=id.split('-')[0],destino=id.split('-')[1],estado='arriba')
  st=Estado(2.0,100.0)
  first=st.actualizar_historial([sample('s1-s2'),sample('s2-s3')])
  self.assertEqual(len(first),2)
  second=st.actualizar_historial([sample('s1-s4')])
  self.assertEqual([x['id'] for x in second],['s1-s4'])
  self.assertTrue(any(x['anterior']=='arriba' and x['nuevo']=='ausente' for x in st.eventos))
 def test_servidor_sin_api_action(self):
  import inspect
  self.assertNotIn('consultar_agente',inspect.getsource(Solicitud))

if __name__=='__main__':unittest.main(verbosity=2)
