# FORT Live Monitor V5 — Topología interactiva tipo ONOS

Monitor de **solo lectura** para redes Mininet con Open vSwitch y OpenFlow 1.3. Se ha sustituido el SVG manual por Cytoscape.js 3.33.1, incluido localmente (MIT), sin conexión a internet ni `npm install`.

## ¿Qué cambia respecto a V4?

- Mapa interactivo: zoom, pan, arrastre de nodos, clic en switch/host/enlace, inspección y reajuste.
- Diseños: Automático (evita superposición de cajas y organiza caminos paralelos), Fuerza, Jerárquico, Circular y Cuadrícula.
- No se requieren posiciones preprogramadas de s1...s8: los nodos provienen de puentes OVS, enlaces VETH y puertos de acceso.
- Distingue host real de switch: ignora procesos Mininet que comparten el namespace de red raíz, no convierte nombres de switches en hosts y no supone puerto de acceso 1.
- Si un host no tiene identificación comprobada, lo rotula `?` y conserva su anclaje a un puerto VETH; NO inventa IP, MAC ni nombre.
- Al cambiar la topología, los enlaces que desaparecen generan eventos, pero se retiran del mapa (sin enlaces fantasma).
- Rutas reconstruidas con reglas/grupos OpenFlow; cuadros animados solo cuando hay tráfico IPv4 de ingreso medido y recorrido reconstruido.
- Panel de detalles y telemetría por dirección; histórico y exportación CSV.
- Ningún botón de tráfico, `pingall`, cambios de enlaces ni instalación de reglas. El monitor rechaza POST con HTTP 405.

## Despliegue (tres terminales independientes)

Trabaja en `~/Desktop/Tesis-SDN`. El controlador FORT y Mininet **deben seguir en sus propias terminales**. Solo se reinicia el proceso de dashboard, si ya existía.

1. **Terminal 1, FORT:** mantén tu comando habitual de FORT-V1.0.
2. **Terminal 2, Mininet:** mantén `mininet>` con V1, V2 u otra topología en ejecución.
3. **Terminal 3, dashboard:** si V4 está activo, detén únicamente el servidor V4 con `Ctrl+C`. Luego ejecuta:

```bash
cd ~/Desktop/Tesis-SDN
unzip -o ~/Downloads/FORT_LIVE_MONITOR_V5_ONOS.zip
sudo /usr/bin/python3 FORT_LIVE_MONITOR/app/servidor.py --intervalo 2
```

Abre Firefox en **http://127.0.0.1:8765/** y pulsa `Ctrl+Shift+R` para evitar una caché vieja.

**No ejecutes `iniciar.py` ni `mn -c` para arrancar el monitor.** Este proyecto no contiene un launcher que levante una segunda topología.

### Verificación de funcionamiento

```bash
curl -s http://127.0.0.1:8765/api/state | python3 -m json.tool | head -50
```

Confirma que aparezcan `switches`, `enlaces`, `hosts`, `trazas` y `fort`. Los hosts, sus IP y los puertos se descubren sin ejecutar `pingall` desde la web. **Si FORT aún no ha aprendido un host, ese es un estado independiente del monitor.**

## Generar tráfico únicamente desde Mininet

Por ejemplo, con h1 y h2:

```text
mininet> h2 iperf3 -s -D -p 5201
mininet> h1 iperf3 -c 10.0.0.2 -p 5201 -u -b 20M -t 60 -i 2
```

El mapa colorea **carga de enlaces medida por TX**, NO demanda objetivo de iPerf3. Cada carril es una dirección. Los cuadrados animados son una indicación visual de actividad de comunicaciones con rutas reconstruidas, no paquetes individuales capturados.

## Lectura del monitor

- **Inspector**: clic sobre el switch, host o enlace. Mostrará únicamente información disponible y comprobada.
- **Comunicaciones**: clic en un par IP selecciona su ruta si hay evidencia suficiente. Los botones Activas/Todas/Ocultar controlan visualización, NO envían tráfico.
- **Diseño**: la vista Automática utiliza un algoritmo determinista; los demás diseños de Cytoscape permiten explorar grafos diferentes. El desplazamiento manual se conserva durante sondeos normales; al cambiar la estructura o diseño, se vuelve a distribuir.
- **Eventos**: las desconexiones, reconexiones y desaparición de enlaces se presentan de manera separada.
- **FORT**: sin su exportador opcional, NO es posible atribuir causalmente a MILP un cambio de ruta observado en OVS. Los desvíos FF indicados sin evento de exportador son inferencias de reglas/grupos/puertos.

## Estructura

```text
FORT_LIVE_MONITOR/
  app/
    servidor.py             API HTTP de solo lectura (127.0.0.1:8765)
    topologia_dinamica.py   OVS + VETH;  enlaces y puertos de acceso
    descubrimiento_hosts.py namespaces Mininet + evidencia OpenFlow
    trazabilidad.py         reglas y grupos FF (pasivo)
    telemetria.py           contadores TX por dirección
    exportador.py           puente opcional FORT, no es necesario para usar V5
    web/
      index.html            interfaz
      app.css               apariencia
      app.js                Cytoscape e interacciones
      layout.js             geometría inicial automática
      vendor/               Cytoscape.js embebido + licencia MIT
  docs/                     vistas simuladas y notas
  runtime/                  espacio para exportación opcional de FORT
  tests/                    comprobaciones offline de Python/JS
```

## Requisitos y límites

- Linux/Ubuntu con `ovs-vsctl`, `ovs-ofctl`, `ip`, `nsenter`, `ps`, `python3`; servidor ejecutado con privilegios suficientes para inspeccionar namespaces Mininet.
- Topologías Mininet convencionales: bridges OVS y nombres de interfaces `switch-ethN` con pares VETH. No se promete descubrimiento universal de OpenFlow remoto, túneles GRE/VXLAN ni redes de switches físicos que no presenten esta evidencia local.
- Capacidad por dirección actualmente proviene de la configuración de telemetría compartida; si necesitas **capacidades distintas por enlace**, requiere una futura ampliación.
- No existe un algoritmo que elimine todos los cruces de líneas para un grafo arbitrario no planar. Se evita superposición de cajas en diseños automáticos probados; un grafo denso puede seguir necesitando ajustar zoom, mover nodos o cambiar diseño.
- El flujo/FF/MILP no lo determina el monitor por su cuenta: sus mediciones son observaciones y reconstrucciones con limitaciones.

## Pruebas offline

```bash
cd ~/Desktop/Tesis-SDN/FORT_LIVE_MONITOR
python3 -m unittest discover -s tests -p 'test_*.py' -v
node tests/test_layout.js
```

La prueba visual del desarrollo se efectuó con datos **simulados**, no es una validación del controlador ejecutándose en tu VM. V1 (8 switches/4 hosts), V2 (12 switches/2 hosts) y malla de 36 switches se abrieron en Chromium sin errores JavaScript. La integración final debe comprobarse en tu Ubuntu con las salidas reales de OpenFlow.
