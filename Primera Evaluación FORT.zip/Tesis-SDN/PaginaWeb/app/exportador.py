#!/usr/bin/env python3
"""Crea una COPIA instrumentada de FORT-V1.0; nunca reescribe el original.

No altera el algoritmo: exporta una instantánea de lectura del estado interno
vigente cada ~0,5 s. Solo funciona si se inicia la COPIA como controlador.
"""
import argparse
import ast
import re
from pathlib import Path

MARCA = '# FORT_DASHBOARD_EXPORT_V1'

METODOS = '''\n        # FORT_DASHBOARD_EXPORT_V1: instrumentacion de observabilidad, sin control.\n        def _dashboard_representar_arcos(self, ruta):\n            if ruta is None:\n                return None\n            return [dict(origen=self.nombre_sw(e[0]), puerto_origen=int(e[1]),\n                         destino=self.nombre_sw(e[2]), puerto_destino=int(e[3]))\n                    for e in ruta]\n\n        def _dashboard_publicar_una(self):\n            comunicaciones = []\n            for clave, c in sorted(self.vigentes.items()):\n                principal = list(c.ruta)\n                efectiva = self.ruta_efectiva(c)\n                if efectiva is None:\n                    tipo = 'sin_ruta'\n                elif efectiva != principal:\n                    tipo = 'ff_inferida'\n                else:\n                    tipo = 'principal_inferida'\n                comunicaciones.append(dict(\n                    id=clave, origen_ip=c.origen.ip, destino_ip=c.destino.ip,\n                    origen_switch=self.nombre_sw(c.origen.switch),\n                    destino_switch=self.nombre_sw(c.destino.switch),\n                    ruta_principal=self._dashboard_representar_arcos(principal),\n                    ruta_efectiva=self._dashboard_representar_arcos(efectiva),\n                    tipo=tipo, grupos_ff=len(c.grupos)))\n            datos = dict(\n                esquema='FORT_DASH_V1', version_controlador=VERSION, revision=REVISION,\n                instante=time.time(), sesion=self._dashboard_sesion, pid=os.getpid(),\n                version_escenario=self.version, ciclo=self.ciclo,\n                red_lista=bool(self.lista), incidente=bool(self.incidente),\n                transicion_en_curso=self.transaccion is not None,\n                comunicaciones=comunicaciones,\n                eventos=list(self._dashboard_eventos))\n            ruta = self._dashboard_archivo\n            ruta.parent.mkdir(parents=True, exist_ok=True)\n            tmp = ruta.with_name(ruta.name + '.' + self._dashboard_sesion + '.tmp')\n            with tmp.open('w', encoding='utf-8') as fd:\n                json.dump(datos, fd, ensure_ascii=False, allow_nan=False)\n            os.replace(tmp, ruta)\n\n        def _dashboard_bucle(self):\n            ultimo_error = 0.0\n            while self.activo:\n                try:\n                    self._dashboard_publicar_una()\n                except Exception as exc:\n                    # Fallar al publicar NUNCA puede afectar la logica de FORT.\n                    if time.monotonic() - ultimo_error > 15.0:\n                        print('[DASHBOARD] Publicacion no disponible: '
                              + str(exc), flush=True)\n                        ultimo_error = time.monotonic()\n                hub.sleep(0.5)\n'''


def detectar(raiz):
    posibles = []
    for p in sorted((raiz / 'Algoritmos').glob('*.py')):
        try:
            texto = p.read_text(encoding='utf-8')
        except OSError:
            continue
        if ("VERSION = 'FORT-V1.0'" in texto and "REVISION = 'medicion-02'" in texto
                and 'class FORT(app_manager.OSKenApp)' in texto
                and MARCA not in texto):
            posibles.append(p)
    return posibles


def crear(archivo, destino=None):
    src = archivo.read_text(encoding='utf-8')
    if MARCA in src:
        raise ValueError('El archivo ya parece instrumentado; elige el original.')
    # Validar ANTES de tocar ficheros.
    ast.parse(src, filename=str(archivo))
    anclas = [
        ('        def leer_capacidades(self):', METODOS + '\n        def leer_capacidades(self):'),
        ('            self.emitir(\'INICIO\',', '            self.emitir(\'INICIO\','),
    ]
    if src.count(anclas[0][0]) != 1:
        raise ValueError('No se encontro un unico punto de insercion en la clase FORT.')
    src = src.replace(*anclas[0], 1)
    linea = "            self.capacidad_declarada = self.leer_capacidades()"
    if src.count(linea) != 1:
        raise ValueError('No se encontro el punto de inicializacion esperado.')
    src = src.replace(linea, linea + '''\n            self._dashboard_eventos = deque(maxlen=100)\n            self._dashboard_sesion = uuid.uuid4().hex\n            self._dashboard_archivo = Path(os.environ.get(\n                'FORT_DASHBOARD_ESTADO',\n                str(Path(__file__).resolve().parent.parent / 'FORT_LIVE_MONITOR' / 'runtime' / 'fort_estado.json')))''', 1)
    hook = "            print(f'[{VERSION} v{self.version} c{self.ciclo}] {estado} | {mensaje}', flush=True)"
    if src.count(hook) != 1:
        raise ValueError('No se encontro el metodo emitir del controlador esperado.')
    src = src.replace(hook, hook + '''\n            if hasattr(self, '_dashboard_eventos'):\n                self._dashboard_eventos.append(dict(\n                    instante=time.time(), estado=str(estado), mensaje=str(mensaje),\n                    version=self.version, ciclo=self.ciclo))''', 1)
    spawn = '            self.threads.append(hub.spawn(self.supervisar))'
    if src.count(spawn) != 1:
        raise ValueError('No se encontro la inicializacion del supervisor.')
    src = src.replace(spawn, spawn + '''\n            self.threads.append(hub.spawn(self._dashboard_bucle))''', 1)
    # El original usa de pathlib import? Agregamos import sin afectar nombres existentes.
    if 'from pathlib import Path' not in src:
        src = 'from pathlib import Path\n' + src
    ast.parse(src, filename=str(archivo))
    nombre = archivo.stem + '_dashboard.py'
    destino = Path(destino) if destino is not None else archivo.with_name(nombre)
    destino.parent.mkdir(parents=True, exist_ok=True)
    # No escribir jamás el controlador original; el launcher usa runtime/
    if destino.resolve() == archivo.resolve():
        raise ValueError('No se permite sobrescribir el controlador original')
    destino.write_text(src, encoding='utf-8')
    return destino


def main():
    p = argparse.ArgumentParser(description='Crear copia de observabilidad de FORT V1.0')
    p.add_argument('--controlador', type=Path, help='Ruta del controlador original, si no se detecta de forma unica')
    args = p.parse_args()
    raiz = Path(__file__).resolve().parents[2]
    if args.controlador:
        candidatos = [args.controlador.resolve()]
    else:
        candidatos = detectar(raiz)
    if len(candidatos) != 1:
        print('No se pudo identificar un controlador unico. Encontrados:')
        for a in candidatos:
            print(' ', a)
        print('Usa --controlador RUTA si corresponde.')
        return 1
    destino = crear(candidatos[0])
    print('Controlador ORIGINAL intacto:', candidatos[0])
    print('Controlador instrumentado creado:', destino)
    print('El archivo exportado se escribira en:')
    print(' ', raiz / 'FORT_LIVE_MONITOR' / 'runtime' / 'fort_estado.json')
    print('IMPORTANTE: la copia solo exporta cuando se INICIA como controlador. ')
    print('No se debe ejecutar un segundo controlador simultaneo en puerto 6653.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, SyntaxError) as exc:
        raise SystemExit('[INSTALADOR] ' + str(exc))
