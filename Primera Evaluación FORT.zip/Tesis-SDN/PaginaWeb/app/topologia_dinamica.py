#!/usr/bin/env python3
"""Descubre los enlaces VETH entre bridges OVS; consultas de solo lectura.

En la topologia Mininet actual, las dos puntas troncales VETH viven en
el namespace raiz. La correspondencia ifindex/iflink se comprueba en ambos
sentidos. Si falta evidencia, se informa DESCONOCIDO, nunca ARRIBA.
"""
import re
import subprocess
from pathlib import Path

SYS_NET = Path('/sys/class/net')
PATRON_SW = re.compile(r'^s[0-9]+$')

def orden_natural(s):
    return tuple((0,int(x)) if x.isdigit() else (1,x.lower()) for x in re.split(r'(\d+)',s))
PATRON_PUERTO = re.compile(r'^(.+)-eth([0-9]+)$')


def comando(*argv):
    proceso = subprocess.run(argv, capture_output=True, text=True, timeout=5, check=False)
    if proceso.returncode:
        raise RuntimeError(f"{' '.join(argv)}: {proceso.stderr.strip() or proceso.stdout.strip()}")
    return proceso.stdout


def leer_entero(archivo):
    try:
        return int(archivo.read_text().strip(), 0)
    except (OSError, ValueError):
        return None


def estado_interfaz(nombre, sys_net=SYS_NET):
    """Estado del NIC local: caido / arriba / desconocido (fail-closed)."""
    raiz = sys_net / nombre
    if not raiz.exists():
        return 'ausente'
    flags = leer_entero(raiz / 'flags')
    if flags is not None and not (flags & 0x1):  # IFF_UP
        return 'caido'
    carrier = leer_entero(raiz / 'carrier')
    if carrier == 0:
        return 'caido'
    try:
        operstate = (raiz / 'operstate').read_text().strip().lower()
    except OSError:
        operstate = None
    if operstate in ('down', 'lowerlayerdown', 'dormant', 'notpresent'):
        return 'caido' if operstate != 'notpresent' else 'ausente'
    if flags is not None and flags & 0x1 and (carrier == 1 or operstate == 'up'):
        return 'arriba'
    return 'desconocido'


def pares_veth(puertos, sys_net=SYS_NET):
    """Devuelve enlaces físicos comprobando el peer de cada VETH.

    puertos: lista de (switch, numero_de_puerto, nombre_interfaz).
    """
    datos = {}
    indices = {}
    for sw, puerto, nombre in puertos:
        local = leer_entero(sys_net / nombre / 'ifindex')
        remoto = leer_entero(sys_net / nombre / 'iflink')
        datos[nombre] = (sw, puerto, local, remoto)
        if local is not None:
            indices[local] = nombre
    resultado = []
    vistos = set()
    for nombre, (sw, puerto, local, remoto) in datos.items():
        otro = indices.get(remoto)
        if not otro or otro == nombre or local is None:
            continue  # no es un par verificable en namespace raiz (p. ej. host)
        s2, p2, i2, f2 = datos[otro]
        if s2 == sw or f2 != local:
            continue
        orden = tuple(sorted((nombre, otro)))
        if orden in vistos:
            continue
        vistos.add(orden)
        a, pa, na, b, pb, nb = (sw, puerto, nombre, s2, p2, otro)
        if (b, pb) < (a, pa):
            a, pa, na, b, pb, nb = b, pb, nb, a, pa, na
        ea = estado_interfaz(na, sys_net)
        eb = estado_interfaz(nb, sys_net)
        if 'caido' in (ea, eb):
            estado = 'caido'
        elif 'ausente' in (ea, eb):
            estado = 'ausente'
        elif ea == eb == 'arriba':
            estado = 'arriba'
        else:
            estado = 'desconocido'
        resultado.append(dict(id=f'{a}-{b}', origen=a, puerto_origen=pa,
                              destino=b, puerto_destino=pb, interfaz_origen=na,
                              interfaz_destino=nb, estado=estado,
                              evidencia='veth ifindex/iflink + flags/carrier/operstate'))
    # Un par de switches puede estar conectado por dos o más puertos VETH.
    # Los IDs distinguen enlaces paralelos, manteniendo compatibilidad con los simples.
    from collections import Counter
    cantidad = Counter(e['id'] for e in resultado)
    for e in resultado:
        if cantidad[e['id']] > 1:
            e['id'] += f":{e['puerto_origen']}-{e['puerto_destino']}"
    return sorted(resultado, key=lambda x: (orden_natural(x['origen']), orden_natural(x['destino']), x['puerto_origen']))


def descubrir(sys_net=SYS_NET):
    candidatos = [s.strip() for s in comando('ovs-vsctl', '--timeout=3', 'list-br').splitlines() if s.strip()]
    switches = []
    puertos = []
    for sw in sorted(candidatos, key=orden_natural):
        port_names = [n.strip() for n in comando('ovs-vsctl', '--timeout=3', 'list-ports', sw).splitlines()]
        encontrados = []
        for nombre in port_names:
            m = PATRON_PUERTO.fullmatch(nombre)
            if m and m.group(1) == sw:
                encontrados.append((sw,int(m.group(2)),nombre))
        # Conservar los switches sN aun cuando Mininet aún no conectó sus interfaces.
        # Otros bridges solo entran si tienen interfaces Mininet del propio nombre.
        if PATRON_SW.fullmatch(sw) or encontrados:
            switches.append(sw)
            puertos.extend(encontrados)
    enlaces = pares_veth(puertos, sys_net)
    interfaces_troncales = {e['interfaz_origen'] for e in enlaces} | {e['interfaz_destino'] for e in enlaces}
    accesos = []
    for sw, puerto, nombre in puertos:
        if nombre in interfaces_troncales:
            continue
        local = leer_entero(sys_net / nombre / 'ifindex')
        peer = leer_entero(sys_net / nombre / 'iflink')
        if local is None or peer is None or local == peer:
            continue
        accesos.append(dict(switch=sw, puerto=puerto, interfaz=nombre,
                            ifindex=local, peer_ifindex=peer,
                            estado=estado_interfaz(nombre, sys_net)))
    if not switches:
        raise RuntimeError('NO_HAY_SWITCHES_OVS')
    # Una topología con un solo switch o sin troncales es válida para dibujar.
    return dict(switches=switches, enlaces=enlaces, accesos=accesos,
                fuente='OVS bridges/ports + emparejamiento kernel VETH')
