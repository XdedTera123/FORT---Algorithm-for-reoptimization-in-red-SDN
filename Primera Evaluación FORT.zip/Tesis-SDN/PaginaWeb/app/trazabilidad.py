#!/usr/bin/env python3
"""Observabilidad PASIVA de comunicaciones IPv4 FORT en Open vSwitch.

Lee flows y buckets FF. No instala reglas, no dispara optimización y no simula
tráfico. Los cuadros SVG en el frontend son una REPRESENTACIÓN de contadores.
Una pareja de IP = una comunicación (no separa TCP/UDP/ICMP de ese par).
"""
import re
import subprocess
import time
from collections import deque

COOKIE_PREFIX = 0x464F000000000000
COOKIE_MASK = 0xFFFF000000000000


def command(*args):
    res = subprocess.run(args, capture_output=True, text=True, timeout=4, check=False)
    if res.returncode:
        raise RuntimeError(f'{args[-1]}: {res.stderr.strip() or res.stdout.strip()}')
    return res.stdout


def numeric(text):
    """OpenFlow imprime enteros como decimal o 0xhex; admite 00012 decimal."""
    text = text.strip()
    return int(text, 16 if text.lower().startswith('0x') else 10)


def field(text, *names):
    names = '|'.join(re.escape(n) for n in names)
    m = re.search(r'(?:^|[,\s])(?:' + names + r')=([^,\s]+)', text)
    return m.group(1) if m else None


def flow_entries(output):
    """Lee dump-flows OF1.3 en formatos nw_src/nw_dst e ipv4_src/dst.

    OFPMatch de FORT: ip, origen/destino, prioridad 400 (ingreso),
    prioridad 300 (VLAN tránsito/egreso); cookie 0x464f... .
    """
    result = []
    for line in output.splitlines():
        if 'actions=' not in line or 'cookie=' not in line:
            continue
        left, actions = line.split('actions=', 1)
        raw_cookie = field(left, 'cookie')
        try:
            cookie = numeric(raw_cookie) if raw_cookie else None
            if cookie is None or cookie & COOKIE_MASK != COOKIE_PREFIX:
                continue
            src = field(left, 'nw_src', 'ipv4_src')
            dst = field(left, 'nw_dst', 'ipv4_dst')
            # En modo OF1.3 se imprime ip,nw_src,... . Ignorar matches ARP.
            if not src or not dst or field(left, 'arp_spa', 'arp_tpa') or re.search(r'(?:^|[,\s])arp(?:[,\s]|$)', left):
                continue
            vlan_txt = field(left, 'dl_vlan', 'vlan_vid', 'vlan_tci')
            vlan = numeric(vlan_txt.split('/', 1)[0]) if vlan_txt else None
            ingress = field(left, 'in_port')
            nbytes = field(left, 'n_bytes', 'byte_count')
            npk = field(left, 'n_packets', 'packet_count')
            priority = field(left, 'priority')
            duration = re.search(r'\bduration=([\d.]+)s(?:[,\s]|$)', left)
            result.append(dict(cookie=cookie, src=src, dst=dst,
                               ingress=numeric(ingress) if ingress else None,
                               vlan=vlan, priority=numeric(priority) if priority else 0,
                               bytes=numeric(nbytes) if nbytes else None,
                               packets=numeric(npk) if npk else None,
                               duration=float(duration.group(1)) if duration else None,
                               actions=actions.strip()))
        except (ValueError, TypeError):
            continue
    return result


def parse_groups(out):
    """Parser de grupos Fast Failover: respeta orden de buckets y watch_port."""
    groups = {}
    for line in out.splitlines():
        m = re.search(r'\bgroup_id=(0x[0-9a-fA-F]+|\d+)', line)
        if not m or not re.search(r'\btype=ff\b', line, re.I):
            continue
        buckets = []
        for entry in re.split(r'\bbucket=', line)[1:]:
            watch = re.search(r'\bwatch_port:(0x[0-9a-fA-F]+|\d+)', entry)
            actions = entry.split('actions=', 1)[-1] if 'actions=' in entry else ''
            if watch and actions:
                buckets.append(dict(watch=numeric(watch.group(1)), actions=actions))
        groups[numeric(m.group(1))] = buckets
    return groups


def vlan_action(text):
    m = re.search(r'\bset_field:(0x[0-9a-fA-F]+|\d+)->vlan_vid\b', text)
    if not m:
        m = re.search(r'\b(?:mod_vlan_vid|set_vlan_vid):(0x[0-9a-fA-F]+|\d+)\b', text)
    return numeric(m.group(1)) if m else None


def action_out(actions, groups, live_ports, force_first=False):
    """Devuelve puerto, etiqueta actualizada, selección FF y razón del fallo."""
    tag = vlan_action(actions)
    grp = re.search(r'\bgroup:(0x[0-9a-fA-F]+|\d+)', actions)
    backup = False
    if grp:
        buckets = groups.get(numeric(grp.group(1)))
        if not buckets:
            return None, None, False, 'GRUPO_FF_NO_DISPONIBLE'
        if force_first:
            chosen = 0
        else:
            chosen = next((i for i, x in enumerate(buckets) if x['watch'] in live_ports), None)
        if chosen is None:
            return None, None, False, 'SIN_BUCKET_VIVO'
        backup = chosen > 0
        actions = buckets[chosen]['actions']
        tag = vlan_action(actions) if vlan_action(actions) is not None else tag
    out = re.search(r'\boutput:(0x[0-9a-fA-F]+|\d+)\b', actions)
    if not out:
        return None, tag, backup, 'SIN_OUTPUT'
    return numeric(out.group(1)), tag, backup, 'OK'


def is_vlan_match(flow, tag):
    val = flow.get('vlan')
    if tag is None:
        return val is None
    return val is not None and (val & 0xfff) == (tag & 0xfff)


def resolve_path(src, dst, flows, groups, links, forced_primary=False, hosts=None):
    """Reconstrucción salto a salto de reglas activas; sin camino inventado."""
    hosts = hosts or {}
    if src not in hosts or dst not in hosts:
        return None, False, 'HOST_DESCONOCIDO'
    srcip, start, src_port = hosts[src]
    dstip, end, dst_port = hosts[dst]
    adjacent, up_ports = {}, {}
    for e in links:
        if e['estado'] != 'arriba':
            continue
        a, pa, b, pb = e['origen'], e['puerto_origen'], e['destino'], e['puerto_destino']
        adjacent[(a, pa)] = (b, pb)
        adjacent[(b, pb)] = (a, pa)
        up_ports.setdefault(a, set()).add(pa)
        up_ports.setdefault(b, set()).add(pb)
    switch, tag, path, seen, ff = start, None, [], {start}, False
    for hop in range(len(links) + 2):
        candidates = [x for x in flows.get(switch, []) if x['src'] == srcip and x['dst'] == dstip
                      and ((hop == 0 and x['priority'] == 400 and x['ingress'] == src_port)
                           or (hop > 0 and x['priority'] == 300 and is_vlan_match(x, tag)))]
        if not candidates:
            return None, ff, f'REGLA_AUSENTE:{switch}:salto{hop}'
        # Si hay versiones en transición con el mismo match, no atribuir una ruta arbitraria.
        if len(candidates) > 1:
            variants = {(x['cookie'], x['actions']) for x in candidates}
            if len(variants) > 1:
                return None, ff, f'REGLAS_AMBIGUAS:{switch}'
        rule = candidates[0]
        out, new_tag, used_backup, error = action_out(
            rule['actions'], groups.get(switch, {}), up_ports.get(switch, set()), forced_primary)
        if out is None:
            return None, ff, f'{error}:{switch}'
        ff = ff or used_backup
        if switch == end and out == dst_port:
            return path, ff, 'RUTA_RECONSTRUIDA_OVS'
        peer = adjacent.get((switch, out))
        if peer is None:
            return None, ff, f'SALIDA_NO_DISPONIBLE:{switch}:{out}'
        nextsw, remote = peer
        if nextsw in seen:
            return None, ff, f'BUCLE_DE_FORWARDING:{nextsw}'
        path.append(dict(origen=switch, puerto_origen=out,
                         destino=nextsw, puerto_destino=remote))
        seen.add(nextsw)
        switch = nextsw
        if new_tag is not None:
            tag = new_tag
    return None, ff, 'MAX_SALTOS'


class Observer:
    def __init__(self):
        self.previous = {}
        self.last_at = None
        self.last_paths = {}
        self.events = deque(maxlen=70)
        self.last = dict(estado='iniciando', comunicaciones=[], eventos=[], instante=None)

    def sample(self, switches, links, hosts=None):
        now = time.monotonic()
        flows, groups, errors, sizes = {}, {}, [], {}
        for sw in switches:
            try:
                dump = command('ovs-ofctl', '-O', 'OpenFlow13', 'dump-flows', sw)
                flows[sw] = flow_entries(dump)
                groups[sw] = parse_groups(command('ovs-ofctl', '-O', 'OpenFlow13', 'dump-groups', sw))
                sizes[sw] = dict(reglas_fort_ipv4=len(flows[sw]), grupos_ff=len(groups[sw]),
                                 lineas_de_flujos=sum('actions=' in l for l in dump.splitlines()))
            except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
                errors.append(f'{sw}: {exc}')
                flows[sw], groups[sw] = [], {}
                sizes[sw] = dict(reglas_fort_ipv4=0, grupos_ff=0, error=str(exc))
        records, current = [], {}
        # Detectar IPs presentes en reglas FORT sin presumir cuatro hosts o puerto 1.
        hints = []
        for sw, entries in flows.items():
            for e in entries:
                if e['priority']==400 and e['src'] and e['ingress'] is not None:
                    hints.append(dict(switch=sw, puerto=e['ingress'], ip=e['src']))
        known = {h['ip']: (h['ip'], h['switch'], int(h['puerto']))
                 for h in (hosts or []) if h.get('ip') and h.get('switch') in switches
                 and h.get('puerto') is not None}
        for hint in hints:
            known.setdefault(hint['ip'], (hint['ip'], hint['switch'], hint['puerto']))
        for srcip, (src, access, port) in sorted(known.items()):
            for dstip, (_, dstswitch, dstport) in sorted(known.items()):
                if srcip == dstip:
                    continue
                key = srcip + '>' + dstip
                candidates = [x for x in flows.get(access, []) if x['src'] == srcip and x['dst'] == dstip
                              and x['priority'] == 400 and x['ingress'] == port]
                ingress = candidates[0] if len(candidates) == 1 else None
                path, ff, reason = resolve_path(srcip, dstip, flows, groups, links, hosts=known)
                primary, _, _ = resolve_path(srcip, dstip, flows, groups, links, forced_primary=True, hosts=known)
                mbps, active, sample_valid = None, False, False
                if ingress and ingress['bytes'] is not None:
                    old = self.previous.get(key)
                    if (old and self.last_at is not None and old['cookie'] == ingress['cookie']
                        and old['bytes'] is not None and ingress['bytes'] >= old['bytes']
                        and (old['duration'] is None or ingress['duration'] is None
                             or ingress['duration'] >= old['duration'])):
                        dt = now - self.last_at
                        if dt > 0:
                            delta = ingress['bytes'] - old['bytes']
                            mbps = 8 * delta / dt / 1e6
                            active = delta > 0
                            sample_valid = True
                    current[key] = dict(cookie=ingress['cookie'], bytes=ingress['bytes'],
                                        duration=ingress['duration'])
                pathkey = tuple((e['origen'], e['destino']) for e in path) if path is not None else None
                if key in self.last_paths and self.last_paths[key] != pathkey:
                    self.events.appendleft(dict(instante=time.time(), estado='RUTA_OVS_CAMBIO',
                                                hosts_reconocidos=len(known), inferidos=hints, mensaje=f'{srcip} → {dstip}: {self.last_paths[key]} → {pathkey}'))
                self.last_paths[key] = pathkey
                records.append(dict(id=key, origen_ip=srcip, destino_ip=dstip,
                                    origen_switch=access, destino_switch=dstswitch,
                                    ruta_efectiva=path, ruta_principal=primary,
                                    tipo='ff_inferida' if ff else 'instalada_ovs' if path is not None else 'sin_ruta',
                                    motivo=reason, fuente='OVS reglas/grupos',
                                    mbps_ingreso=mbps, activo_observado=active,
                                    muestra_valida=sample_valid,
                                    contador_ingreso=ingress['bytes'] if ingress else None,
                                    existe_ingreso=ingress is not None))
        self.previous = current
        self.last_at = now
        count = sum(r['existe_ingreso'] for r in records)
        rutas = sum(isinstance(r['ruta_efectiva'], list) for r in records)
        if errors:
            status = 'lectura_parcial'
        elif count == 0:
            status = 'sin_ingresos'
        elif not rutas:
            status = 'sin_rutas'
        else:
            status = 'conectado'
        self.last = dict(estado=status, comunicaciones=records, eventos=list(self.events),
                         instante=time.time(), errores=errors, diagnostico=sizes,
                         ingresos_detectados=count, rutas_reconstruidas=rutas,
                         hosts_reconocidos=len(known), inferidos=hints, mensaje=f'{count}/{len(records)} reglas IPv4 de ingreso; {rutas}/{len(records)} rutas reconstruidas. '
                                 'Cuadritos únicamente con contador de ingreso incremental.')
        return self.last
