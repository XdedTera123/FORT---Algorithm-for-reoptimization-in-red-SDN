#!/usr/bin/env python3
"""Descubre hosts Mininet, sin pingall ni suposiciones de IP/topología.

Primero inspecciona pasivamente namespaces de procesos mininet:HOST, emparejando
ifindex/iflink con los puertos VETH OVS de acceso. Si no hay esa evidencia,
usa reglas IPv4 de ingreso de FORT o muestra un extremo no identificado.
NUNCA genera tráfico, instala reglas ni requiere modificar FORT/Mininet.
"""
import json
import os
import re
import subprocess
from pathlib import Path

NAMESPACE_RE = re.compile(r'(?<![\w.-])mininet:([\w.-]+)')


def run(*argv, timeout=4):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
    if p.returncode:
        raise RuntimeError(p.stderr.strip() or ' '.join(argv))
    return p.stdout


def interfaces_namespace(pid):
    raw = run('nsenter', '-t', str(pid), '-n', 'ip', '-j', 'addr', 'show', timeout=3)
    return json.loads(raw)


def namespace_aislado(pid):
    """Evita confundir shells de switches (namespace raiz) con hosts."""
    try:
        return os.readlink(f'/proc/{pid}/ns/net') != os.readlink('/proc/self/ns/net')
    except (OSError, RuntimeError):
        return False


def procesos_mininet():
    """Proceso bash del host; nombres provienen del prompt mininet:HOST."""
    nombres = {}
    for line in run('ps', '-eo', 'pid=,args=', timeout=4).splitlines():
        m = re.match(r'^\s*(\d+)\s+(.*)$', line)
        if not m:
            continue
        args = m.group(2)
        # Rechazar procesos externos (p.ej. grep o propio ejecutor Python).
        if not ('bash' in args or 'sh --norc' in args):
            continue
        host = NAMESPACE_RE.search(args)
        if host and namespace_aislado(int(m.group(1))):
            nombres.setdefault(host.group(1), int(m.group(1)))
    return nombres


def descubrir_hosts(accesos, inferidos=None, scan_namespace=True, switches=None):
    """Devuelve hosts anclados a un puerto observado, sin posiciones inventadas."""
    inferidos = inferidos or []
    por_peer = {int(a['peer_ifindex']): a for a in accesos
                if a.get('peer_ifindex') is not None}
    por_port = {(a['switch'], int(a['puerto'])):a for a in accesos}
    hosts = {}
    avisos = []
    if scan_namespace and accesos:
        try:
            procesos = procesos_mininet()
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
            procesos = {}
            avisos.append('No se puede enumerar procesos Mininet: '+str(exc))
        for name, pid in procesos.items():
            if name in set(switches or ()):
                continue
            try:
                for interfaz in interfaces_namespace(pid):
                    a = por_peer.get(interfaz.get('ifindex'))
                    if a is None:
                        continue
                    # Compensar versiones de iproute2 donde iflink no se emite.
                    link_index = interfaz.get('link_index')
                    if link_index is not None and link_index != a.get('ifindex'):
                        continue
                    ip = next((x.get('local') for x in interfaz.get('addr_info', [])
                               if x.get('family')=='inet' and x.get('local')), None)
                    key = (a['switch'],a['puerto'])
                    hosts[key] = dict(nombre=name, ip=ip, mac=interfaz.get('address'),
                                      switch=a['switch'], puerto=a['puerto'],
                                      fuente='namespace Mininet + VETH', confirmado=True)
            except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
                avisos.append(f'Host {name}: {str(exc)[:150]}')
    for f in inferidos:
        key=(f.get('switch'),f.get('puerto'))
        if key not in por_port or not f.get('ip'):
            continue
        actual=hosts.get(key)
        if actual is None:
            hosts[key]=dict(nombre=f['ip'], ip=f['ip'], mac=None,
                            switch=key[0], puerto=key[1], fuente='regla IPv4 OVS', confirmado=False)
        elif not actual.get('ip'):
            actual['ip']=f['ip']
    # Endpoint no identificado, no fingir que se conoce su nombre o su IP.
    for key,a in por_port.items():
        hosts.setdefault(key,dict(nombre=f'Host en {a["switch"]}:{a["puerto"]}',
                                   ip=None,mac=None,switch=a['switch'],puerto=a['puerto'],
                                   fuente='puerto de acceso VETH',confirmado=False))
    lista=sorted(hosts.values(),key=lambda h:(h['switch'],h['puerto'],h['nombre']))
    return dict(hosts=lista, avisos=avisos)
