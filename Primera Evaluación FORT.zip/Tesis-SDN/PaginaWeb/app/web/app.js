import { c as cytoscape } from '/vendor/cytoscape.esm.js';

// FORT Live Monitor V5: visualizador pasivo. No hay acciones que modifiquen OVS.
const $ = id => document.getElementById(id);
const N = x => x === null || x === undefined || x === '' || !Number.isFinite(Number(x)) ? null : Number(x);
const percentage = (v, digits=2) => N(v)===null?'Sin datos':`${Number(v).toFixed(digits)} %`;
const mbps = v => N(v)===null?'Sin datos':`${Number(v).toFixed(3)} Mbps`;
const rateColor = v => N(v)===null?'#748da2':v>=80?'#f47383':v>=60?'#f3c875':'#3dd8b4';
const palette=['#63c0fa','#f6ad62','#c78eff','#f784bd','#45d4c1','#e2cb6b','#f67d7a','#93aeff','#d5e87a','#62d7e0','#ed88cd','#f2ad92'];
const sorted = a=>[...a].sort((x,y)=>String(x).localeCompare(String(y),undefined,{numeric:true}));
function hash(s){let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0}
const routeColor = id=>palette[hash(id)%palette.length];
const hk = h=>`host:${h.switch}:${h.puerto}`;
const sk = s=>`switch:${s}`;
const lk = id=>`link:${id}`;
function safeText(element,text){element.textContent=text??'';return element}
function nodeEl(name,cls,text){const e=document.createElement(name);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e}
function addRow(dl,key,value){const row=nodeEl('div','info-item');row.append(nodeEl('dt','',key),nodeEl('dd','',value??'—'));dl.append(row)}
let state=null, cy=null, topologySignature='', selected=null, routeMode='active',selectedRoute=null, history=[], historyKey='',lastTopologyUpdate=0;
const particleCanvas=$('particles'), context=particleCanvas.getContext('2d');
const CY_STYLE=[
 {selector:'node',style:{'text-valign':'center','text-halign':'center','font-family':'Arial, sans-serif','font-weight':700,'color':'#f6fbff','text-outline-color':'#19364e','text-outline-width':1,'font-size':15,'overlay-opacity':0,'z-index':3}},
 {selector:'node.switch',style:{'shape':'round-rectangle','width':64,'height':45,'label':'data(label)','background-color':'#2b6089','border-color':'#81c2ec','border-width':2}},
 {selector:'node.host',style:{'shape':'ellipse','width':52,'height':52,'label':'data(label)','font-size':12,'color':'#1b4862','text-outline-width':0,'background-color':'#d5edff','border-color':'#67bde7','border-width':2}},
 {selector:'node.unknown',style:{'background-color':'#a8b8ca','border-color':'#738aa0','color':'#1b3e50'}},
 {selector:'node:selected',style:{'border-color':'#ffdf83','border-width':5,'background-color':'#316e95'}},
 {selector:'edge',style:{'width':3.6,'line-color':'#3dd8b4','curve-style':'straight','line-cap':'round','opacity':.9,'overlay-opacity':0,'z-index':1}},
 {selector:'edge.backbone',style:{'width':4.5}},
 {selector:'edge.access',style:{'width':2,'line-color':'#708aa2','line-style':'dashed','opacity':.78}},
 {selector:'edge.down',style:{'line-color':'#f26d80','line-style':'dashed','width':4,'opacity':1}},
 {selector:'edge.unknown',style:{'line-color':'#75889c','line-style':'dotted'}},
 {selector:'edge.route-highlight',style:{'line-color':'#ffd16e','width':9,'opacity':1,'z-index':2}},
 {selector:'edge.dim',style:{'opacity':.20}},
 {selector:'edge:selected',style:{'line-color':'#ffeeaa','width':8,'opacity':1,'z-index':4}},
];
function initialize(){
 cy=cytoscape({container:$('cy'),elements:[],style:CY_STYLE,layout:{name:'preset'},wheelSensitivity:.24,minZoom:.12,maxZoom:4,boxSelectionEnabled:false,autoungrabify:false,userPanningEnabled:true,userZoomingEnabled:true});
 cy.on('tap','node,edge',e=>{const ele=e.target; selected={kind:ele.data('kind'),id:ele.id()};if(ele.isEdge()&&ele.data('kind')==='backbone'){const id=ele.data('linkId');$('historySelect').value=id;updateHistory();}selectedRoute=null;updateSelection();});
 cy.on('tap',e=>{if(e.target===cy){selected=null;selectedRoute=null;updateSelection();}});
 cy.on('pan zoom position data',()=>{});
 $('zoomIn').onclick=()=>cy.zoom({level:Math.min(cy.maxZoom(),cy.zoom()*1.24),renderedPosition:{x:cy.width()/2,y:cy.height()/2}});
 $('zoomOut').onclick=()=>cy.zoom({level:Math.max(cy.minZoom(),cy.zoom()/1.24),renderedPosition:{x:cy.width()/2,y:cy.height()/2}});
 $('fit').onclick=()=>cy.fit(undefined,48);
 $('clearSelection').onclick=()=>{selected=null;selectedRoute=null;updateSelection()};
 $('layoutMode').onchange=()=>applyLayout(false);
 $('showActive').onclick=()=>changeMode('active');
 $('showAll').onclick=()=>changeMode('all');
 $('showNone').onclick=()=>changeMode('none');
 $('historySelect').onchange=()=>{historyKey=$('historySelect').value;updateHistory()};
 window.addEventListener('resize',()=>{cy.resize();resizeCanvas();updateHistory()});
 resizeCanvas();requestAnimationFrame(paintParticles);
}
function changeMode(m){routeMode=m;updateRoutes();}
function identifiedHosts(){return state?.hosts||[]}
function linkState(e){return e.estado==='arriba'?'ACTIVO':e.estado==='caido'?'CAÍDO':e.estado==='ausente'?'AUSENTE':'DESCONOCIDO'}
function topologyElements(){
 const switches=sorted(state?.switches||[]),hosts=identifiedHosts(),links=state?.enlaces||[];
 const elems=[];
 for(const s of switches)elems.push({group:'nodes',data:{id:sk(s),kind:'switch',label:s,name:s},classes:'switch'});
 for(const h of hosts){
  const name=h.nombre?.startsWith('Host en ')?'?':h.nombre||h.ip||'?';
  elems.push({group:'nodes',data:{id:hk(h),kind:'host',label:name.length>10?name.slice(0,9)+'…':name,name,ip:h.ip,host:h},classes:h.confirmado?'host':'host unknown'});
  if(switches.includes(h.switch))elems.push({group:'edges',data:{id:'access:'+hk(h),kind:'access',source:hk(h),target:sk(h.switch)},classes:'access'});
 }
 for(const e of links){
  if(!switches.includes(e.origen)||!switches.includes(e.destino))continue;
  elems.push({group:'edges',data:{id:lk(e.id),kind:'backbone',linkId:e.id,source:sk(e.origen),target:sk(e.destino)},classes:'backbone'+(e.estado==='caido'||e.estado==='ausente'?' down':e.estado==='desconocido'?' unknown':'')});
 }
 return elems;
}
function topologyFingerprint(){return JSON.stringify([sorted(state?.switches||[]),(state?.enlaces||[]).map(x=>[x.id,x.origen,x.destino]).sort(),(state?.hosts||[]).map(h=>[h.switch,h.puerto,h.ip,h.nombre]).sort()])}
function refreshTopology(){
 const signature=topologyFingerprint();
 if(signature!==topologySignature){
  topologySignature=signature;
  const elements=topologyElements();
  cy.elements().remove();cy.add(elements);
  applyLayout(true);
  lastTopologyUpdate=Date.now();
  if(selected&&!cy.$id(selected.id).length)selected=null;
 }else{
  for(const e of state?.enlaces||[]){const el=cy.$id(lk(e.id));if(el.length){el.removeClass('down unknown');if(e.estado==='caido'||e.estado==='ausente')el.addClass('down');else if(e.estado!=='arriba')el.addClass('unknown');}}
 }
 $('mapEmpty').hidden=cy.nodes().length>0;
 $('graphFeedback').textContent=`${(state?.switches||[]).length} switches · ${identifiedHosts().length} extremos de acceso · ${(state?.enlaces||[]).length} enlaces · ${cy.nodes().length} nodos en el mapa`;
 for(const e of state?.enlaces||[]){const el=cy.$id(lk(e.id));if(!el.length)continue;const a=e.ida?.valido?e.ida.porcentaje:null,b=e.vuelta?.valido?e.vuelta.porcentaje:null;const val=Math.max(a??0,b??0);if(e.estado==='arriba')el.style('line-color',(a===null&&b===null)?'#70869b':rateColor(val));else el.removeStyle('line-color')}
}
function applyLayout(initial){
 const mode=$('layoutMode').value;
 if(mode==='automatic'){
  const raw=FortLayout.compute(state?.switches||[],state?.enlaces||[],state?.hosts||[]);
  const nodes=cy.nodes();
  nodes.positions(n=>{
   const id=n.data('kind')==='switch'?n.data('name'):'host:'+n.data('host').switch+':'+n.data('host').puerto;
   const p=raw.positions[id];return p?{x:p[0],y:p[1]}:n.position();
  });
  if(initial)cy.fit(undefined,50);else cy.animate({fit:{eles:cy.elements(),padding:50}},{duration:250});
 }else{
  const opt={name:mode,fit:true,padding:46,animate:false};
  if(mode==='cose')Object.assign(opt,{nodeOverlap:42,idealEdgeLength:()=>145,nodeRepulsion:()=>170000,gravity:0.55,numIter:1100,randomize:false});
  if(mode==='breadthfirst')Object.assign(opt,{directed:false,spacingFactor:1.4,avoidOverlap:true,circle:false});
  if(mode==='circle')Object.assign(opt,{avoidOverlap:true,spacingFactor:1.5});
  if(mode==='grid')Object.assign(opt,{avoidOverlap:true,condense:false,spacingFactor:1.3});
  cy.layout(opt).run();
 }
}
function knownHosts(){const m=new Map();for(const h of identifiedHosts())if(h.ip)m.set(h.ip,h);return m}
function communications(){
 const ovs=state?.trazas?.comunicaciones||[],fort=state?.fort?.estado==='conectado'?state.fort.comunicaciones||[]:[], extra=new Map(fort.map(r=>[r.id,r]));
 const base=ovs.length?ovs:fort;
 return base.map(r=>{const ext=extra.get(r.id);const x={...r};if(!Array.isArray(x.ruta_efectiva)&&Array.isArray(ext?.ruta_efectiva)){x.ruta_efectiva=ext.ruta_efectiva;x.fuente='Exportación FORT';}x.activo_observado=Boolean(r.activo_observado&&Array.isArray(x.ruta_efectiva));x.mbps_ingreso=Number.isFinite(r.mbps_ingreso)?r.mbps_ingreso:null;return x;}).sort((a,b)=>a.id.localeCompare(b.id,undefined,{numeric:true}));
}
function routeSegments(r){
 if(!Array.isArray(r?.ruta_efectiva))return [];
 const hosts=knownHosts(),h1=hosts.get(r.origen_ip),h2=hosts.get(r.destino_ip),links=state?.enlaces||[];
 const items=[];
 if(h1&&cy.$id(hk(h1)).length)items.push([hk(h1),sk(h1.switch),null]);
 let current=r.origen_switch;
 for(const arc of r.ruta_efectiva){
  if(!current||arc.origen!==current)return [];
  const link=links.find(e=>e.estado==='arriba'&&((e.origen===arc.origen&&e.destino===arc.destino&&String(e.puerto_origen)===String(arc.puerto_origen))||(e.destino===arc.origen&&e.origen===arc.destino&&String(e.puerto_destino)===String(arc.puerto_origen))))
    ||links.find(e=>e.estado==='arriba'&&((e.origen===arc.origen&&e.destino===arc.destino)||(e.destino===arc.origen&&e.origen===arc.destino)));
  if(!link||!cy.$id(lk(link.id)).length)return [];
  items.push([sk(arc.origen),sk(arc.destino),lk(link.id)]);current=arc.destino;
 }
 if(current!==r.destino_switch)return [];
 if(h2&&cy.$id(hk(h2)).length)items.push([sk(h2.switch),hk(h2),null]);
 return items;
}
function visibleComms(){const all=communications();if(routeMode==='none')return [];if(selectedRoute)return all.filter(r=>r.id===selectedRoute&&Array.isArray(r.ruta_efectiva));return routeMode==='all'?all.filter(r=>Array.isArray(r.ruta_efectiva)):all.filter(r=>r.activo_observado&&Array.isArray(r.ruta_efectiva))}
function updateSelection(){
 cy.elements().removeClass('route-highlight dim');
 if(selectedRoute){
  const found=communications().find(r=>r.id===selectedRoute);
  if(found){const edges=routeSegments(found);cy.edges().addClass('dim');for(const [from,to,id] of edges){const el=cy.$id(id||('access:'+((from.startsWith('host:')?from:to))));if(el.length)el.removeClass('dim').addClass('route-highlight')}}
 }
 if(selected&&selected.kind==='backbone'){const el=cy.$id(selected.id);if(el.length)el.select()}
 updateInspector();updateCommunicationList();
}
function inspectHeading(name,sub,kind){const top=nodeEl('div','inspect-title');top.append(nodeEl('div','inspect-avatar'+(kind==='host'?' host':''),kind==='host'?'⌂':'▦'));const s=nodeEl('div');s.append(nodeEl('b','',name),nodeEl('span','',sub));top.append(s);return top}
function updateInspector(){
 const parent=$('inspector');parent.replaceChildren();
 if(selectedRoute){const r=communications().find(x=>x.id===selectedRoute);if(r){parent.append(inspectHeading(`${r.origen_ip} → ${r.destino_ip}`,'Comunicación dirigida · '+(r.fuente||'OVS'),'route'));const dl=nodeEl('dl','info-list');addRow(dl,'Estado',Array.isArray(r.ruta_efectiva)?'Ruta reconstruida':'Sin ruta verificable');addRow(dl,'Tipo',r.tipo||'—');addRow(dl,'Ingreso medido',mbps(r.mbps_ingreso));addRow(dl,'Actividad',r.activo_observado?'Detectada':'Sin actividad reciente');addRow(dl,'Motivo',r.motivo||'—');addRow(dl,'Ruta',routeSegments(r).map(x=>x[0]).concat(r.destino_switch?sk(r.destino_switch):[]).join(' → ')||'Sin datos');parent.append(dl);return;}}
 if(!selected){parent.append(nodeEl('div','inspect-empty'));const box=parent.firstElementChild;box.append(nodeEl('div','inspect-icon','◎'),nodeEl('strong','','Selecciona un elemento del mapa'),nodeEl('p','','Haz clic en un switch, host o troncal para conocer sus propiedades.'));return;}
 const id=selected.id;
 if(selected.kind==='switch'){
  const sw=id.slice(7),links=(state?.enlaces||[]).filter(e=>e.origen===sw||e.destino===sw);const hosts=identifiedHosts().filter(h=>h.switch===sw);
  parent.append(inspectHeading(sw,'Switch · puente Open vSwitch','switch'));
  const dl=nodeEl('dl','info-list');addRow(dl,'Nombre',sw);addRow(dl,'DPID','No publicado por telemetría');addRow(dl,'Vecinos',sorted(new Set(links.map(e=>e.origen===sw?e.destino:e.origen))).join(', ')||'Sin troncales');addRow(dl,'Enlaces activos',`${links.filter(e=>e.estado==='arriba').length}/${links.length}`);addRow(dl,'Hosts de acceso',hosts.map(h=>`${h.nombre} (p${h.puerto})`).join(', ')||'Ninguno');parent.append(dl);
 }else if(selected.kind==='host'){
  const h=identifiedHosts().find(x=>hk(x)===id);if(!h)return;
  parent.append(inspectHeading(h.nombre?.startsWith('Host en ')?'Host no identificado':h.nombre,'Extremo de acceso','host'));
  const dl=nodeEl('dl','info-list');addRow(dl,'IP',h.ip||'No confirmada');addRow(dl,'MAC',h.mac||'No disponible');addRow(dl,'Switch de acceso',h.switch);addRow(dl,'Puerto',String(h.puerto));addRow(dl,'Fuente',h.fuente);addRow(dl,'Identificación',h.confirmado?'Namespace Mininet comprobado':'No confirmada');parent.append(dl);
 }else if(selected.kind==='backbone'){
  const idlink=id.slice(5),e=(state?.enlaces||[]).find(x=>x.id===idlink);if(!e)return;
  parent.append(inspectHeading(`${e.origen} ↔ ${e.destino}`,'Enlace troncal · dos sentidos','switch'));
  const dl=nodeEl('dl','info-list');addRow(dl,'Estado',linkState(e));addRow(dl,'Puerto origen',`${e.origen}:${e.puerto_origen}`);addRow(dl,'Puerto destino',`${e.destino}:${e.puerto_destino}`);addRow(dl,'Capacidad configurada',`${state.capacidad_mbps} Mbps por sentido`);addRow(dl,`${e.origen} → ${e.destino}`,`${mbps(e.ida?.mbps)} · ${percentage(e.ida?.porcentaje)}`);addRow(dl,`${e.destino} → ${e.origen}`,`${mbps(e.vuelta?.mbps)} · ${percentage(e.vuelta?.porcentaje)}`);parent.append(dl);
 }
}
function updateCommunicationList(){
 const area=$('communications');area.replaceChildren();const all=communications();
 for(const m of ['active','all','none'])$('show'+(m==='active'?'Active':m==='all'?'All':'None')).classList.toggle('active',routeMode===m);
 $('traceStatus').textContent=`${all.length} pares dirigidos · ${all.filter(r=>r.activo_observado).length} con actividad medida · ${all.filter(r=>Array.isArray(r.ruta_efectiva)).length} rutas reconstruidas`;
 for(const r of all){const b=nodeEl('button','comm'+(selectedRoute===r.id?' active':''));b.type='button';const head=nodeEl('div','comm-head');const label=nodeEl('strong','');const dot=nodeEl('i','swatch');dot.style.background=routeColor(r.id);label.append(dot,document.createTextNode(`${r.origen_ip} → ${r.destino_ip}`));head.append(label,nodeEl('span',r.activo_observado?'state-good':'muted',r.activo_observado?'● Activa':'○ Reposo'));b.append(head,nodeEl('div','comm-body',`${Array.isArray(r.ruta_efectiva)?(r.ruta_efectiva.length+' saltos'):'Sin ruta verificable'} · ${mbps(r.mbps_ingreso)} · ${r.tipo||'Sin tipo'}`));b.onclick=()=>{selectedRoute=selectedRoute===r.id?null:r.id;selected=null;updateSelection()};area.append(b)}
 if(!all.length)area.append(nodeEl('div','muted','No hay reglas de comunicación verificables. Se necesita tráfico o reglas OpenFlow instaladas.'));
 $('fortState').textContent=state?.fort?.estado==='conectado'?'Exportador FORT conectado. Distingue inferencias OVS de eventos de optimización confirmados.':'Sin exportador FORT: no se atribuyen los cambios de OVS a una optimización MILP.';
}
function renderLinkCards(){const area=$('linkCards');area.replaceChildren();for(const e of state?.enlaces||[]){const btn=nodeEl('button','link-card'+(selected?.id===lk(e.id)?' active':''));btn.type='button';const head=nodeEl('div','link-head');head.append(nodeEl('span','',e.origen+' ↔ '+e.destino),nodeEl('span','badge'+(e.estado==='arriba'?'':' down'),linkState(e)));btn.append(head);for(const [from,to,val] of [[e.origen,e.destino,e.ida],[e.destino,e.origen,e.vuelta]]){const row=nodeEl('div','bar-row');row.append(nodeEl('span','',from+' → '+to),nodeEl('b','',percentage(val?.valido?val.porcentaje:null,3)));btn.append(row);const track=nodeEl('div','bar-track'),fill=nodeEl('div','bar-fill');fill.style.width=`${Math.min(100,Math.max(0,val?.valido?Number(val.porcentaje)||0:0))}%`;fill.style.background=rateColor(val?.valido?val.porcentaje:null);track.append(fill);btn.append(track)}btn.onclick=()=>{selected={kind:'backbone',id:lk(e.id)};selectedRoute=null;$('historySelect').value=e.id;historyKey=e.id;updateHistory();updateSelection();cy.$id(lk(e.id)).select()};area.append(btn)}if(!(state?.enlaces||[]).length)area.append(nodeEl('div','muted','No se detectaron troncales.'))}
function renderEvents(){const e=$('events');e.replaceChildren();for(const item of (state?.eventos||[]).slice(0,8)){const row=nodeEl('div','event');row.append(nodeEl('span','',`${item.enlace}: ${item.anterior} → ${item.nuevo}`),nodeEl('time','',new Date(item.instante*1000).toLocaleTimeString('es-PE')));e.append(row)}if(!e.children.length)e.append(nodeEl('div','muted tiny','Sin cambios detectados.'));
 const r=$('routeEvents');r.replaceChildren();const events=[...(state?.trazas?.eventos||[]),...(state?.fort?.estado==='conectado'?(state.fort.eventos||[]):[])].sort((a,b)=>(b.instante||0)-(a.instante||0)).slice(0,8);for(const item of events){const row=nodeEl('div','event');row.append(nodeEl('span','',item.mensaje||item.estado||item.tipo||'Evento de ruta'),nodeEl('time','',item.instante?new Date(item.instante*1000).toLocaleTimeString('es-PE'):'—'));r.append(row)}if(!r.children.length)r.append(nodeEl('div','muted tiny','Sin eventos confirmados.'))}
function updateStats(){
 $('swCount').textContent=(state.switches||[]).length;
 const hosts=identifiedHosts();$('hostCount').textContent=hosts.length;
 const unconfirmed=hosts.filter(h=>!h.confirmado).length;$('hostNote').textContent=unconfirmed?`${unconfirmed} sin nombre confirmado`:'Acceso identificado por namespace';
 const links=state.enlaces||[],up=links.filter(e=>e.estado==='arriba').length,down=links.filter(e=>e.estado==='caido'||e.estado==='ausente').length;
 $('linkCount').textContent=`${up} / ${down}`;$('linkNote').textContent=`${links.length} enlaces · arriba / caídos`;
 const rates=links.flatMap(e=>[e.ida,e.vuelta]).filter(r=>r?.valido&&N(r.porcentaje)!==null).map(r=>Number(r.porcentaje));
 $('mlu').textContent=rates.length?`${Math.max(...rates).toFixed(2)} %`:'—';
 $('sampleNo').textContent=state.muestra??'—';$('sampleTime').textContent=`Intervalo objetivo ${state.intervalo_configurado_s}s`;
 $('clock').textContent=state.instante?new Date(state.instante*1000).toLocaleTimeString('es-PE'):'—';
 $('capacity').textContent=`${state.capacidad_mbps} Mbps/dirección`;
 $('status').className='status '+(state.estado==='correcto'?'good':'bad');$('statusText').textContent=state.estado==='correcto'?'Monitor conectado':state.estado==='error'?'Error OVS':'Inicializando';
 $('error').hidden=state.estado!=='error';if(state.estado==='error')$('error').textContent=state.mensaje;
}
function resizeCanvas(){const dpr=Math.min(2,window.devicePixelRatio||1);const rect=particleCanvas.getBoundingClientRect();if(!rect.width||!rect.height)return;particleCanvas.width=Math.ceil(rect.width*dpr);particleCanvas.height=Math.ceil(rect.height*dpr);context.setTransform(dpr,0,0,dpr,0,0)}
function paintParticles(time){requestAnimationFrame(paintParticles);const w=particleCanvas.clientWidth,h=particleCanvas.clientHeight;if(!w||!h)return;context.clearRect(0,0,w,h);if(!cy||!state||document.hidden)return;
 // Cuadritos solo para comunicaciones activas y con ruta reconstruida.
 const routes=visibleComms().filter(r=>r.activo_observado).slice(0,45),occupants=new Map();
 for(const r of routes){const segments=routeSegments(r);segments.forEach(([src,dst,id],i)=>{if(!cy.$id(src).length||!cy.$id(dst).length)return;const group=id||[src,dst].sort().join('|');if(!occupants.has(group))occupants.set(group,[]);occupants.get(group).push({r,src,dst,i})})}
 for(const values of occupants.values()){
  values.forEach((s,i)=>{const a=cy.$id(s.src).renderedPosition(),b=cy.$id(s.dst).renderedPosition(),dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy);if(len<32)return;
   const normal=[-dy/len,dx/len],lane=(i-(values.length-1)/2)*Math.min(7,28/Math.max(values.length,1));
   const nDots=Math.min(4,Math.max(1,Math.ceil((s.r.mbps_ingreso||5)/18)));const speed=3.5-(Math.min(1,(s.r.mbps_ingreso||0)/100));
   context.fillStyle=routeColor(s.r.id);
   for(let j=0;j<nDots;j++){const phase=((time/1000/speed)+(j+.17*s.i)/nDots)%1;const p=.12+.76*phase;const x=a.x+dx*p+normal[0]*lane,y=a.y+dy*p+normal[1]*lane;context.fillRect(x-3.5,y-3.5,7,7)}
  });
 }
}
function syncHistoryOptions(){const ids=(state.enlaces||[]).map(e=>e.id),sel=$('historySelect');if(ids.join('|')!==sel.dataset.ids){const previous=sel.value;sel.replaceChildren();for(const id of ids){const opt=nodeEl('option','',id);opt.value=id;sel.append(opt)}if(ids.includes(previous))sel.value=previous;else if(ids.includes(historyKey))sel.value=historyKey;sel.dataset.ids=ids.join('|')}historyKey=sel.value}
async function updateHistory(){
 const canvas=$('historyCanvas'),dpr=Math.min(2,window.devicePixelRatio||1),rect=canvas.getBoundingClientRect();if(rect.width<2)return;canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);
 const w=rect.width,h=rect.height,selectedId=$('historySelect').value;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#263e55';ctx.lineWidth=1;
 for(let j=0;j<=4;j++){const y=14+(h-28)*j/4;ctx.beginPath();ctx.moveTo(36,y);ctx.lineTo(w-12,y);ctx.stroke();ctx.fillStyle='#839cb5';ctx.font='11px Arial';ctx.fillText(String(Math.round((4-j)*25))+'%',3,y+4)}
 const rows=history.slice(-150),keys=['ida','vuelta'],colors=['#59b9f0','#e2ba6e'];
 for(let series=0;series<2;series++){ctx.strokeStyle=colors[series];ctx.lineWidth=2;ctx.beginPath();let begun=false;rows.forEach((row,i)=>{const link=(row.enlaces||[]).find(e=>e.id===selectedId),v=link?.[keys[series]];if(!v?.valido||N(v.porcentaje)===null){begun=false;return;}const x=36+(w-51)*(rows.length<2?.5:i/(rows.length-1)),y=14+(h-28)*(1-Math.min(100,Math.max(0,v.porcentaje))/100);if(!begun)ctx.moveTo(x,y);else ctx.lineTo(x,y);begun=true});ctx.stroke();}
 $('historyLabel').textContent=selectedId?`${selectedId} · ${rows.length} muestras disponibles`:'Sin enlace';
}
async function pollHistory(){try{const res=await fetch('/api/history',{cache:'no-store'});if(res.ok){history=await res.json();updateHistory()}}catch{}}
let pending=false;
async function poll(){if(pending)return;pending=true;try{const res=await fetch('/api/state',{cache:'no-store'});if(!res.ok)throw Error(`HTTP ${res.status}`);state=await res.json();updateStats();refreshTopology();syncHistoryOptions();updateSelection();renderLinkCards();renderEvents();}catch(e){$('status').className='status bad';$('statusText').textContent='Desconectado';$('error').hidden=false;$('error').textContent=`No se pudo obtener /api/state: ${e.message}`;}finally{pending=false}}
initialize();await poll();await pollHistory();setInterval(poll,2000);setInterval(pollHistory,6000);
