/* FORT Live Monitor: disposición reproducible por grafo, sin dependencias CDN.
 * Evita solapamiento de nodos/etiquetas. Un grafo no planar puede tener cruces
 * de aristas inevitables; las cargas se muestran en tarjetas, no amontonadas.
 */
(function(root,factory){
  const API=factory();
  if(typeof module==='object' && module.exports) module.exports=API;
  if(root) root.FortLayout=API;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function idnum(s){const m=String(s).match(/^(.*?)(\d+)$/);return m?Number(m[2]):Number.POSITIVE_INFINITY}
  function ordered(a,b){return idnum(a)-idnum(b)||String(a).localeCompare(String(b),undefined,{numeric:true})}
  function hash(s){let h=2166136261;for(const c of s){h=Math.imul(h^c.charCodeAt(0),16777619)}return h>>>0}
  function rng(seed){let x=seed||1234567;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296}}
  function compute(switches,links,hosts){
    const ids=[...new Set(switches)].sort(ordered);
    const edges=(links||[]).filter(x=>ids.includes(x.origen)&&ids.includes(x.destino));
    const byAccess=new Map();
    for(const h of hosts||[]){if(ids.includes(h.switch))byAccess.set('host:'+h.switch+':'+h.puerto,h)}
    const members=[...byAccess].sort((a,b)=>a[0].localeCompare(b[0]));
    const all=ids.map(id=>({id,kind:'switch',width:66,height:46}));
    for(const [k,h] of members) all.push({id:k,kind:'host',parent:h.switch,width:62,height:42});
    const idx=new Map(all.map((n,i)=>[n.id,i]));
    const n=all.length;
    const N=Math.max(1,n);
    const width=Math.max(1080,Math.min(3600,320*Math.sqrt(N)));
    const height=Math.max(690,Math.min(2600,Math.round(width*.66)));
    const center=[width/2,height/2];
    const seed=hash(ids.join('|')+'|'+edges.map(e=>[e.origen,e.destino].sort().join(':')).sort().join('|'));
    const rand=rng(seed);
    // Distribución inicial por componentes, luego fuerzas de aristas/repulsión.
    const vectors=new Map(ids.map(s=>[s,[0,0]]));
    const positions=all.map((v,i)=>{
      const angle=2*Math.PI*(i+rand()*.22)/N;
      const radius=Math.min(width,height)*(.20+.13*rand());
      return [center[0]+Math.cos(angle)*radius,center[1]+Math.sin(angle)*radius];
    });
    const pairs=[];
    for(const e of edges){const i=idx.get(e.origen),j=idx.get(e.destino);if(i!==j)pairs.push([i,j,185]);}
    for(const [k,h] of members)pairs.push([idx.get(k),idx.get(h.switch),103]);
    // Estructuras de varias rutas paralelas entre dos distribuidores:
    // composición por niveles (BFS), evitando la maraña de un force layout.
    function layered(){
      const adjacency=new Map(ids.map(s=>[s,new Set()]));
      for(const e of edges){adjacency.get(e.origen)?.add(e.destino);adjacency.get(e.destino)?.add(e.origen)}
      const degrees=ids.map(s=>[s,adjacency.get(s).size]).sort((a,b)=>b[1]-a[1]||ordered(a[0],b[0]));
      if(degrees.length<7||degrees[1][1]<4)return false;
      function bfs(root){const levels=new Map([[root,0]]),queue=[root];for(let z=0;z<queue.length;z++){const n=queue[z];for(const m of adjacency.get(n)){if(!levels.has(m)){levels.set(m,levels.get(n)+1);queue.push(m)}}}return levels}
      // Dos distribuidores distantes; no forzar un esquema de niveles en mallas densas.
      let best=null;
      for(const [src,deg] of degrees.slice(0,5))for(const [dst,deg2] of degrees.slice(0,5)){
        if(src===dst)continue;
        const lv=bfs(src),dist=lv.get(dst);
        if(lv.size!==ids.length||dist===undefined||dist<3)continue;
        const pairScore=deg+deg2+dist*.2;
        if(!best||pairScore>best.score)best={src,dst,lv,score:pairScore};
      }
      if(!best)return false;
      let maxLevel=Math.max(...best.lv.values());
      if(maxLevel<3)return false;
      const buckets=Array.from({length:maxLevel+1},()=>[]);
      for(const s of ids)buckets[best.lv.get(s)].push(s);
      // Conectividad entre niveles vecinos es la situación que mejor representa
      // múltiples alternativas paralelas; si no, usamos layout de fuerzas.
      const near=edges.filter(e=>Math.abs(best.lv.get(e.origen)-best.lv.get(e.destino))<=1).length;
      if(near/Math.max(1,edges.length)<.88)return false;
      for(const group of buckets)group.sort(ordered);
      const spacingX=(width-270)/maxLevel;
      for(let layer=0;layer<buckets.length;layer++){
        const group=buckets[layer],heightSpan=Math.max(0,(group.length-1)*115);
        for(let j=0;j<group.length;j++)positions[idx.get(group[j])]=[135+layer*spacingX,height/2-heightSpan/2+j*115];
      }
      const children=new Map();
      for(const [key,h] of members){if(!children.has(h.switch))children.set(h.switch,[]);children.get(h.switch).push(key)}
      for(const [sw,keys] of children){
        const p=positions[idx.get(sw)];if(!p)continue;
        const side=p[0]<width/2?-1:1;
        keys.forEach((key,i)=>{positions[idx.get(key)]=[p[0]+side*103,p[1]+(i-(keys.length-1)/2)*77]});
      }
      return true;
    }
    const isLayered=layered();
    const k=Math.max(100,Math.min(260,Math.sqrt(width*height/N)*.9));
    const step=(iteration)=>{
      const forces=all.map(()=>[0,0]);
      for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
        const dx=positions[i][0]-positions[j][0],dy=positions[i][1]-positions[j][1];
        const d2=Math.max(36,dx*dx+dy*dy),d=Math.sqrt(d2);
        let f=k*k/d2*(all[i].kind==='switch'&&all[j].kind==='switch'?1.35:1.1);
        const fx=f*dx/d,fy=f*dy/d;
        forces[i][0]+=fx; forces[i][1]+=fy;forces[j][0]-=fx;forces[j][1]-=fy;
      }
      for(const [i,j,preferred] of pairs){
        const dx=positions[i][0]-positions[j][0],dy=positions[i][1]-positions[j][1];
        const d=Math.max(0.01,Math.hypot(dx,dy));
        const f=(d-preferred)*.045;
        forces[i][0]-=f*dx/d;forces[i][1]-=f*dy/d;
        forces[j][0]+=f*dx/d;forces[j][1]+=f*dy/d;
      }
      const temp=Math.max(1.4,50*Math.pow(1-iteration/510,1.35));
      for(let i=0;i<n;i++){
        const p=positions[i],F=forces[i];
        F[0]+=(center[0]-p[0])*.002;F[1]+=(center[1]-p[1])*.002;
        const norm=Math.max(1,Math.hypot(F[0],F[1])/temp);
        p[0]=Math.max(85,Math.min(width-85,p[0]+F[0]/norm));
        p[1]=Math.max(75,Math.min(height-75,p[1]+F[1]/norm));
      }
    };
    if(!isLayered)for(let t=0;t<510;t++)step(t);
    // Resolución geométrica dura: cajas separadas, no solo centros de círculos.
    // Expande hasta encontrar un espacio viable en topologías con muchos nodos.
    for(let round=0;round<300;round++){
      let collisions=0;
      for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
        const A=all[i],B=all[j],p=positions[i],q=positions[j];
        const minX=(A.width+B.width)/2+25,minY=(A.height+B.height)/2+27;
        const dx=q[0]-p[0],dy=q[1]-p[1];
        if(Math.abs(dx)>=minX||Math.abs(dy)>=minY)continue;
        collisions++;
        const theta=2*Math.PI*rand();
        if((minX-Math.abs(dx))/minX < (minY-Math.abs(dy))/minY){
          const sign=dx===0?(Math.cos(theta)>0?1:-1):Math.sign(dx);
          const shift=(minX-Math.abs(dx))/2+1;
          p[0]-=sign*shift;q[0]+=sign*shift;
        }else{
          const sign=dy===0?(Math.sin(theta)>0?1:-1):Math.sign(dy);
          const shift=(minY-Math.abs(dy))/2+1;
          p[1]-=sign*shift;q[1]+=sign*shift;
        }
      }
      if(!collisions)break;
    }
    // Escala final para que cualquier nodo quede dentro del lienzo; el zoom
    // afecta al SVG entero y no distorsiona las distancias entre nodos.
    const minX=Math.min(...positions.map(p=>p[0])),maxX=Math.max(...positions.map(p=>p[0]));
    const minY=Math.min(...positions.map(p=>p[1])),maxY=Math.max(...positions.map(p=>p[1]));
    const pad=94, usedW=maxX-minX||1,usedH=maxY-minY||1;
    const scale=Math.min((width-2*pad)/usedW,(height-2*pad)/usedH,1.4);
    const map={};for(let i=0;i<n;i++)map[all[i].id]=[
      width/2+(positions[i][0]-(minX+maxX)/2)*scale,
      height/2+(positions[i][1]-(minY+maxY)/2)*scale
    ];
    // Si un grafo es denso, además de cajas de nodos, las líneas pueden cruzarse.
    return {width,height,positions:map,nodes:all,edges:pairs.length};
  }
  return {compute,ordered};
});
