#!/usr/bin/env python3
"""FORT Live Monitor - prueba de telemetria de enlaces (solo lectura).

Obtiene los contadores TX de Open vSwitch y calcula Mbps y porcentaje de
utilizacion por direccion. No inicia flujos, no cambia reglas ni enlaces.
Sin listas ni puertos predeterminados; los descubre topologia_dinamica.py.
"""

import argparse
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ENCABEZADO_PUERTO = re.compile(r'^\s*port\s+(?:"([^"]+)"|(\d+)|([^:]+)):\s*rx\b')
CONTADOR_TX = re.compile(r'\btx\s+pkts=\d+,\s*bytes=(\d+)\b')


def capacidad_configurada():
    proyecto = Path(os.environ.get("FORT_PROYECTO", Path(__file__).resolve().parent))
    archivo = Path(os.environ.get("FORT_CONFIG", proyecto / "fort_config.json"))
    valor = 100.0
    if archivo.is_file():
        datos = json.loads(archivo.read_text(encoding="utf-8"))
        if not isinstance(datos, dict):
            raise ValueError("fort_config.json debe ser un objeto JSON")
        valor = datos.get("capacidad_enlace_mbps", valor)
    if isinstance(valor, bool) or not isinstance(valor, (int, float)):
        raise ValueError("capacidad_enlace_mbps debe ser un numero")
    if not math.isfinite(valor) or valor <= 0:
        raise ValueError("capacidad_enlace_mbps debe ser positiva y finita")
    return float(valor)


def analizar_salida(salida, switch):
    """Extrae TX bytes de encabezados numericos (port 2) o con nombre.

    'dump-ports s1' puede mostrar 'port  2:', mientras que consultar
    un puerto concreto puede mostrar 'port "s1-eth2":'.
    """
    resultado = {}
    numero_puerto = None
    for linea in salida.splitlines():
        cabecera = ENCABEZADO_PUERTO.search(linea)
        if cabecera:
            nombre, numero, _otro = cabecera.groups()
            numero_puerto = None
            if numero is not None:
                numero_puerto = int(numero)
            elif nombre is not None:
                encontrado = re.fullmatch(re.escape(switch) + r'-eth(\d+)', nombre)
                if encontrado:
                    numero_puerto = int(encontrado.group(1))
            continue
        if numero_puerto is None:
            continue
        contador = CONTADOR_TX.search(linea)
        if contador:
            resultado[(switch, numero_puerto)] = int(contador.group(1))
            numero_puerto = None
    return resultado


def calcular(anterior, actual, puerto, capacidad):
    a, ta = anterior
    b, tb = actual
    if puerto not in a or puerto not in b:
        raise RuntimeError(f"Falta el contador del puerto {puerto[0]}-eth{puerto[1]}")
    segundos = tb[puerto[0]] - ta[puerto[0]]
    delta = b[puerto] - a[puerto]
    if segundos <= 0 or delta < 0:
        return None  # contador reiniciado / medicion no valida: nunca inventar 0 %
    mbps = 8 * delta / segundos / 1_000_000
    return mbps, 100 * mbps / capacidad

