#!/usr/bin/env python3
"""FORT Live Monitor: dashboard de SOLO LECTURA para cualquier Mininet sN."""
import argparse
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import csv
import io

AQUI = Path(__file__).resolve().parent
PROYECTO = AQUI.parent.parent
RUNTIME = AQUI.parent.parent / 'runtime'
# Los módulos están incluidos en un único paquete, sin PYTHONPATH manual.
os.environ.setdefault('FORT_PROYECTO', str(PROYECTO))
from telemetria import analizar_salida, calcular, capacidad_configurada  # noqa: E402
from topologia_dinamica import descubrir  # noqa: E402
from trazabilidad import Observer  # noqa: E402
from descubrimiento_hosts import descubrir_hosts  # noqa: E402

HTML = AQUI / 'web' / 'index.html'
LAYOUT_JS = AQUI / 'web' / 'layout.js'
APP_JS = AQUI / 'web' / 'app.js'
APP_CSS = AQUI / 'web' / 'app.css'
CYTOSCAPE_JS = AQUI / 'web' / 'vendor' / 'cytoscape.esm.js'
ESTADO_FORT = Path(os.environ.get('FORT_DASHBOARD_ESTADO', RUNTIME / 'fort_estado.json'))

def leer_estado_fort():
    """Lee la exportacion opcional del controlador; jamás muestra rutas caducadas."""
    vacio = dict(estado='sin_exportador', comunicaciones=[], eventos=[],
                 mensaje='FORT aún no publica su estado. El monitor OVS continúa funcionando.')
    try:
        if not ESTADO_FORT.is_file():
            return vacio
        if ESTADO_FORT.stat().st_size > 2_000_000:
            raise ValueError('Exportacion demasiado grande')
        datos = json.loads(ESTADO_FORT.read_text(encoding='utf-8'))
        if not isinstance(datos, dict) or datos.get('esquema') != 'FORT_DASH_V1':
            raise ValueError('Esquema desconocido')
        edad = time.time() - float(datos['instante'])
        if not math.isfinite(edad) or edad < -2 or edad > 6:
            return dict(estado='caducado', comunicaciones=[], eventos=[],
                        mensaje=f'La última publicación de FORT tiene {edad:.1f} s; ocultando rutas')
        if not isinstance(datos.get('comunicaciones'), list):
            raise ValueError('Lista de comunicaciones invalida')
        return dict(datos, estado='conectado', edad_s=edad)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        return dict(estado='error_exportador', comunicaciones=[], eventos=[], mensaje=str(exc))



def capturar_switches(switches):
    contadores, tiempos = {}, {}
    for sw in switches:
        inicio = time.monotonic()
        proceso = subprocess.run(['ovs-ofctl', '-O', 'OpenFlow13', 'dump-ports', sw],
                                 capture_output=True, text=True, timeout=5, check=False)
        fin = time.monotonic()
        if proceso.returncode:
            raise RuntimeError(f'{sw}: ovs-ofctl: {proceso.stderr.strip()}')
        encontrados = analizar_salida(proceso.stdout, sw)
        if not encontrados:
            raise RuntimeError(f'{sw}: no se reconocieron contadores TX')
        contadores.update(encontrados)
        tiempos[sw] = (inicio + fin) / 2
    return contadores, tiempos


def metricas(anterior, actual, enlaces, previos, capacidad):
    anterior_enlaces = {(e['id'], e['puerto_origen'], e['puerto_destino']): e
                       for e in previos}
    resultado = []
    for e in enlaces:
        nuevo = dict(e)
        k = (e['id'], e['puerto_origen'], e['puerto_destino'])
        valido = (e['estado'] == 'arriba' and k in anterior_enlaces
                  and anterior_enlaces[k]['estado'] == 'arriba')
        for clave, sw, puerto in [('ida', e['origen'], e['puerto_origen']),
                                  ('vuelta', e['destino'], e['puerto_destino'])]:
            valor = None
            if valido and anterior is not None and actual is not None:
                try:
                    valor = calcular(anterior, actual, (sw, puerto), capacidad)
                except (ValueError, RuntimeError, KeyError, ZeroDivisionError):
                    pass
            if valor is None or not all(math.isfinite(x) and x >= 0 for x in valor):
                nuevo[clave] = dict(mbps=None, porcentaje=None, valido=False)
            else:
                nuevo[clave] = dict(mbps=valor[0], porcentaje=valor[1], valido=True)
        resultado.append(nuevo)
    return resultado


class Estado:
    def __init__(self, intervalo, capacidad):
        self.intervalo = intervalo
        self.capacidad = capacidad
        self.lock = threading.Lock()
        self.historial = {}
        self.trazador = Observer()
        self.eventos = deque(maxlen=30)
        self.muestra = 0
        self.muestras_historia = deque(maxlen=1800)
        self.datos = dict(estado='iniciando', mensaje='Descubriendo enlaces VETH',
                          instante=None, muestra=0, intervalo_configurado_s=intervalo,
                          capacidad_mbps=capacidad, switches=[], enlaces=[],
                          eventos=[], fuente_topologia='OVS/VETH', fuente_cargas='OpenFlow TX bytes',
                          modo='solo_lectura', hosts=[], avisos_hosts=[],
                          trazas=dict(estado='iniciando', comunicaciones=[], eventos=[]))

    def leer(self):
        with self.lock:
            return self.datos

    def guardar(self, **cambios):
        with self.lock:
            self.datos = {**self.datos, **cambios}

    def actualizar_historial(self, descubiertos):
        actuales = {e['id']: e for e in descubiertos}
        antes = self.historial
        ahora = {}
        for identificador, e in actuales.items():
            anterior = antes.get(identificador)
            if anterior is not None and anterior['estado'] != e['estado']:
                self.eventos.appendleft(dict(instante=time.time(), enlace=identificador,
                                             anterior=anterior['estado'], nuevo=e['estado']))
            elif anterior is None and antes:
                self.eventos.appendleft(dict(instante=time.time(), enlace=identificador,
                                             anterior='no_descubierto', nuevo=e['estado']))
            ahora[identificador] = dict(e)
        for identificador, e in antes.items():
            if identificador not in ahora:
                ausente = dict(e, estado='ausente')
                if e['estado'] != 'ausente':
                    self.eventos.appendleft(dict(instante=time.time(), enlace=identificador,
                                                 anterior=e['estado'], nuevo='ausente'))
                # Solo registrar la desaparicion como evento: no dibujar en V5
                # enlaces de una topologia anterior como si siguieran presentes.
        self.historial = ahora
        return sorted(ahora.values(), key=lambda x: (x['origen'], x['destino'], x['id']))

    def historia(self):
        with self.lock:
            return list(self.muestras_historia)

    def ejecutar(self):
        anterior = None
        previos = []
        while True:
            try:
                topo = descubrir()
                enlaces = self.actualizar_historial(topo['enlaces'])
                actual = capturar_switches(topo['switches'])
                if anterior is None:
                    # No hay todavía ventana para calcular tasas.
                    resultado = metricas(None, None, enlaces, [], self.capacidad)
                else:
                    resultado = metricas(anterior, actual, enlaces, previos, self.capacidad)
                hostinfo = descubrir_hosts(topo.get('accesos', []),
                                        self.trazador.last.get('inferidos', []), switches=topo['switches'])
                try:
                    trazas = self.trazador.sample(topo['switches'], enlaces, hostinfo['hosts'])
                except Exception as err:
                    trazas = dict(estado='error', comunicaciones=[], eventos=[],
                                  mensaje=f'Trazabilidad OVS no disponible: {err}')
                self.muestra += 1
                registro = {'instante':time.time(), 'muestra':self.muestra, 'enlaces':resultado}
                with self.lock: self.muestras_historia.append(registro)
                self.guardar(estado='correcto', mensaje='Estado OVS/VETH observado',
                            instante=time.time(), muestra=self.muestra,
                            switches=topo['switches'], enlaces=resultado,
                            hosts=hostinfo['hosts'], avisos_hosts=hostinfo['avisos'],
                            eventos=list(self.eventos), fuente_topologia=topo['fuente'],
                            trazas=trazas)
                anterior, previos = actual, enlaces
                time.sleep(self.intervalo)
            except Exception as exc:
                # Una lectura fallida invalida el intervalo. No mostrar tasas antiguas como actuales.
                anterior, previos = None, []
                self.guardar(estado='error', mensaje=f'{type(exc).__name__}: {exc}',
                            instante=time.time(), enlaces=[], eventos=list(self.eventos),
                            trazas=dict(estado='sin_datos', comunicaciones=[], eventos=[]))
                time.sleep(max(2, self.intervalo))


class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, direccion, estado):
        self.estado = estado
        super().__init__(direccion, Solicitud)


class Solicitud(BaseHTTPRequestHandler):
    def do_POST(self):
        # Los flujos y fallos se ejecutan exclusivamente desde Mininet.
        self.responder(405, b'Solo lectura', 'text/plain; charset=utf-8')

    def do_GET(self):
        ruta = urlsplit(self.path).path
        if ruta in ('/', '/index.html'):
            try:
                cuerpo = HTML.read_bytes()
            except OSError as exc:
                return self.responder(500, str(exc).encode(), 'text/plain; charset=utf-8')
            self.responder(200, cuerpo, 'text/html; charset=utf-8')
        elif ruta == '/app.js':
            try:
                self.responder(200, APP_JS.read_bytes(), 'application/javascript; charset=utf-8')
            except OSError as exc:
                self.responder(500, str(exc).encode(), 'text/plain; charset=utf-8')
        elif ruta == '/app.css':
            try:
                self.responder(200, APP_CSS.read_bytes(), 'text/css; charset=utf-8')
            except OSError as exc:
                self.responder(500, str(exc).encode(), 'text/plain; charset=utf-8')
        elif ruta == '/vendor/cytoscape.esm.js':
            try:
                self.responder(200, CYTOSCAPE_JS.read_bytes(), 'application/javascript; charset=utf-8')
            except OSError as exc:
                self.responder(500, str(exc).encode(), 'text/plain; charset=utf-8')
        elif ruta == '/layout.js':
            try:
                self.responder(200, LAYOUT_JS.read_bytes(), 'application/javascript; charset=utf-8')
            except OSError as exc:
                self.responder(500, str(exc).encode(), 'text/plain; charset=utf-8')
        elif ruta == '/api/state':
            cuerpo = json.dumps(dict(self.server.estado.leer(), fort=leer_estado_fort()),
                                ensure_ascii=False, allow_nan=False).encode('utf-8')
            self.responder(200, cuerpo, 'application/json; charset=utf-8')
        elif ruta == '/api/history':
            self.responder(200,json.dumps(self.server.estado.historia(),ensure_ascii=False).encode(),'application/json')
        elif ruta == '/api/export.csv':
            salida=io.StringIO()
            escritor=csv.writer(salida)
            escritor.writerow(['instante_unix','muestra','enlace','estado','origen','destino','direccion','mbps','porcentaje'])
            for m in self.server.estado.historia():
                for e in m['enlaces']:
                    for nombre, a, b, d in [('ida',e['origen'],e['destino'],e['ida']), ('vuelta',e['destino'],e['origen'],e['vuelta'])]:
                        escritor.writerow([m['instante'],m['muestra'],e['id'],e['estado'],a,b,nombre,d['mbps'],d['porcentaje']])
            self.responder(200,salida.getvalue().encode('utf-8-sig'),'text/csv; charset=utf-8')
        elif ruta == '/favicon.ico':
            self.responder(204, b'', 'image/x-icon')
        else:
            self.responder(404, b'Ruta no encontrada', 'text/plain; charset=utf-8')

    def responder(self, estado, cuerpo, tipo):
        self.send_response(estado)
        self.send_header('Content-Type', tipo)
        self.send_header('Content-Length', str(len(cuerpo)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy',
                         "default-src 'self'; script-src 'self'; "
                         "style-src 'self' 'unsafe-inline'; connect-src 'self'; "
                         "img-src 'self' data:; object-src 'none'")
        self.end_headers()
        self.wfile.write(cuerpo)

    def log_message(self, fmt, *args):
        if args and str(args[1]) != '200':
            super().log_message(fmt, *args)


def main():
    p = argparse.ArgumentParser(description='FORT Live Monitor completo')
    p.add_argument('--intervalo', type=float, default=2.0)
    p.add_argument('--puerto', type=int, default=8765)
    args = p.parse_args()
    if not math.isfinite(args.intervalo) or args.intervalo < 0.5:
        p.error('--intervalo requiere al menos 0.5 segundos')
    if not (1024 <= args.puerto <= 65535):
        p.error('--puerto invalido')
    if not HTML.is_file():
        raise SystemExit(f'No se encuentra {HTML}')
    capacidad = capacidad_configurada()
    estado = Estado(args.intervalo, capacidad)
    threading.Thread(target=estado.ejecutar, daemon=True).start()
    with Servidor(('127.0.0.1', args.puerto), estado) as s:
        print('FORT Live Monitor | solo lectura | topologia dinamica', flush=True)
        print(f'Abre en Ubuntu: http://127.0.0.1:{args.puerto}', flush=True)
        print('El trafico y los fallos se ejecutan exclusivamente en mininet>.', flush=True)
        try:
            s.serve_forever(poll_interval=0.25)
        except KeyboardInterrupt:
            print('\nDashboard detenido.', flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
