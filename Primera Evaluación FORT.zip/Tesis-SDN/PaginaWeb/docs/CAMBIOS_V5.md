# Cambios de V4 a V5

- Añadidos `web/vendor/cytoscape.esm.js`, `web/app.js` y `web/app.css`.
- Sustituida interfaz HTML fija por mapa interactivo con Cytoscape.js; se mantiene `web/layout.js` para posiciones iniciales reproducibles.
- Nueva visualización con inspector, selección de rutas, medidores, historial y eventos.
- Se mantiene la API HTTP de solo lectura (`/api/state`, `/api/history`, `/api/export.csv`); nuevos recursos JS/CSS locales.
- `descubrimiento_hosts.py`: un proceso con nombre `mininet:s8` no basta para definir un host; su namespace debe diferir del root y el nombre no puede ser un bridge detectado.
- `servidor.py`: los enlaces retirados no permanecen dibujados en sucesivos cambios de topología.
- **No se modificaron FORT-V1.0 ni los scripts Mininet.**

## Pendientes de validación en el entorno real

1. Que el monitor identifique h1/h2/h3/h4 mediante namespaces Mininet sin falsos positivos.
2. Que todas las rutas del controlador `medicion-02` se reconstruyan con los `dump-flows` y `dump-groups` reales.
3. Que las tasas en el panel coincidan con lectura TX por puerto y que la fuente de capacidad coincida con la configuración de la topología.
4. Que un cambio de V1 a V2 elimine de inmediato los enlaces antiguos sin reiniciar la página.
5. Que una desconexión y reconexión se representen de forma consistente con OVS y FORT.
