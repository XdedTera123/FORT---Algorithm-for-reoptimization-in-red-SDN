Directorio para los registros. No se incluyen datos antiguos.
