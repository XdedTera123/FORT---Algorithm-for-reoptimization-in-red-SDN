import argparse
import copy
import heapq
import ipaddress
import json
import math
import os
import socket
import subprocess
import sys
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field

VERSION = 'FORT-V1.1'
REVISION = 'targets-01'
COOKIE_PREFIX = 0x464F000000000000
COOKIE_MASK = 0xFFFF000000000000
GROUP_PREFIX = 0x464F0000
EPS = 1e-8


class Cancelado(Exception):
    pass


class NoVerificable(Exception):
    pass


class RespuestaInvalida(Exception):
    pass


def cercano(a, b):
    return abs(a - b) <= EPS * max(1.0, abs(a), abs(b))


def camino(grafo, origen, destino, excluir=frozenset(), prohibidos=frozenset()):
    if origen == destino:
        return []
    cola = deque([origen])
    previo = {origen: None}
    while cola:
        nodo = cola.popleft()
        for e in sorted(grafo.get(nodo, [])):
            if e in excluir or e[2] in prohibidos or e[2] in previo:
                continue
            previo[e[2]] = e
            if e[2] == destino:
                ruta = []
                actual = destino
                while actual != origen:
                    enlace = previo[actual]
                    ruta.append(enlace)
                    actual = enlace[0]
                return list(reversed(ruta))
            cola.append(e[2])
    return None


def inverso(e):
    return e[2], e[3], e[0], e[1]


def fisico(e):
    return min(tuple(e), inverso(e))


def grafo_de(enlaces):
    grafo = defaultdict(list)
    for e in enlaces:
        grafo[e[0]].append(tuple(e))
    return grafo


def validar_ruta(ruta, origen, destino, disponibles):
    if ruta is None:
        return False
    actual = origen
    visitados = {actual}
    for e in ruta:
        e = tuple(e)
        if e not in disponibles or e[0] != actual or e[2] in visitados:
            return False
        actual = e[2]
        visitados.add(actual)
    return actual == destino


def calcular_cargas(modelo, rutas):
    cargas = list(modelo['fondo'])
    for f in modelo['flujos']:
        for e in rutas[f['id']]:
            cargas[e] += f['demanda']
    return cargas


def utilizaciones(modelo, cargas):
    return [100.0 * v / e['capacidad'] for v, e in zip(cargas, modelo['enlaces'])]


def maximo_utilizacion(modelo, cargas):
    return max(utilizaciones(modelo, cargas), default=0.0)


def modelo_con_demanda(modelo, campo):
    """Copia del modelo usando otra demanda por comunicacion (por ejemplo, la media)."""
    copia = dict(modelo)
    copia['flujos'] = [dict(f, demanda=f.get(campo, f['demanda'])) for f in modelo['flujos']]
    return copia


def arcos_de(modelo):
    return [(e['u'], e['puerto'], e['v'], e['remoto']) for e in modelo['enlaces']]


def atributos_camino(arcos, grafo, indices, origen, destino):
    """Proteccion y recursos que necesitaria una comunicacion si se instala por este camino.

    Reproduce exactamente la regla de compilar(): un grupo FF por salto que tenga un
    desvio simple hacia el destino que evite el enlace y los switches ya recorridos.
    """
    ruta = [arcos[j] for j in indices]
    reglas, grupos = defaultdict(int), defaultdict(int)
    etiquetas, sin_respaldo = 1, 0
    reglas[origen] += 2
    for e in ruta[1:]:
        reglas[e[0]] += 2
    if ruta:
        reglas[destino] += 2
    prefijo = set()
    for e in ruta:
        respaldo = camino(grafo, e[0], destino, frozenset((e, inverso(e))), frozenset(prefijo))
        if respaldo:
            etiquetas += 1
            grupos[e[0]] += 1
            for salto in respaldo[1:]:
                reglas[salto[0]] += 2
            reglas[destino] += 2
        else:
            sin_respaldo += 1
        prefijo.add(e[0])
    return dict(saltos=len(ruta), sin_respaldo=sin_respaldo, etiquetas=etiquetas,
                reglas=dict(reglas), grupos=dict(grupos))


class CaminosExcedidos(Exception):
    pass


def enumerar_caminos(arcos, salidas, origen, destino, limite, longitud_max=None, distancias=None):
    """Caminos simples (sin repetir switches) entre origen y destino, como indices de arcos."""
    if origen == destino:
        return [()]
    encontrados = []
    pila = [(origen, (), frozenset((origen,)))]
    while pila:
        nodo, ruta, visitados = pila.pop()
        for j in reversed(salidas.get(nodo, [])):
            siguiente = arcos[j][2]
            if siguiente in visitados:
                continue
            nueva = ruta + (j,)
            if longitud_max is not None:
                restante = distancias.get(siguiente)
                if restante is None or len(nueva) + restante > longitud_max:
                    continue
            if siguiente == destino:
                encontrados.append(nueva)
                if len(encontrados) > limite:
                    raise CaminosExcedidos()
                continue
            pila.append((siguiente, nueva, visitados | {siguiente}))
    return sorted(encontrados, key=lambda r: (len(r), r))


def distancias_hacia(arcos, destino):
    entrantes = defaultdict(list)
    for e in arcos:
        entrantes[e[2]].append(e[0])
    distancia = {destino: 0}
    cola = deque([destino])
    while cola:
        nodo = cola.popleft()
        for previo in entrantes[nodo]:
            if previo not in distancia:
                distancia[previo] = distancia[nodo] + 1
                cola.append(previo)
    return distancia


def generar_candidatos(modelo, parametros):
    """Caminos candidatos calculados dinamicamente sobre la topologia disponible (TS).

    Modo TODOS: todos los caminos simples, si su total no supera el limite; el MILP
    basado en caminos es entonces exacto. Modo ACOTADO: caminos de hasta el minimo de
    saltos mas la holgura, como maximo k por comunicacion. En ambos modos se incluye
    siempre la ruta vigente, por lo que conservar FF siempre es factible. Las
    comunicaciones sin trafico quedan fijas en su ruta vigente.
    """
    arcos = arcos_de(modelo)
    salidas = defaultdict(list)
    for j, e in enumerate(arcos):
        salidas[e[0]].append(j)
    for u in salidas:
        salidas[u].sort(key=lambda j: (arcos[j][2], arcos[j][1]))
    limite = int(parametros['limite_caminos'])
    activos = [f for f in modelo['flujos'] if f['demanda'] > parametros['demanda_minima']]
    modo = 'TODOS'
    candidatos = {}
    try:
        total = 0
        for f in activos:
            lista = enumerar_caminos(arcos, salidas, f['origen'], f['destino'], limite - total)
            total += len(lista)
            candidatos[f['id']] = lista
    except CaminosExcedidos:
        modo = 'ACOTADO'
        candidatos = {}
        for f in activos:
            distancias = distancias_hacia(arcos, f['destino'])
            if f['origen'] not in distancias:
                candidatos[f['id']] = []
                continue
            maximo = distancias[f['origen']] + int(parametros['holgura'])
            lista = enumerar_caminos(arcos, salidas, f['origen'], f['destino'], limite,
                                     maximo, distancias)
            candidatos[f['id']] = lista[:int(parametros['k'])]
    for f in modelo['flujos']:
        vigente = tuple(f['ruta'])
        lista = candidatos.get(f['id'], [])
        if vigente not in lista:
            lista = [vigente] + lista
        candidatos[f['id']] = lista
    return modo, candidatos


class ProblemaMILP:
    def __init__(self, cantidad):
        self.cantidad = cantidad
        self.filas, self.columnas, self.valores = [], [], []
        self.bajos, self.altos = [], []

    def agregar(self, coefs, lo=-math.inf, hi=math.inf):
        fila = len(self.bajos)
        for col, val in coefs.items():
            if val:
                self.filas.append(fila)
                self.columnas.append(col)
                self.valores.append(val)
        self.bajos.append(lo)
        self.altos.append(hi)

    def resolver(self, objetivo, enteros, cota_bajo, cota_alto, tiempo):
        import numpy as np
        from scipy.optimize import Bounds, LinearConstraint, milp
        from scipy.sparse import coo_matrix
        matriz = coo_matrix((self.valores, (self.filas, self.columnas)),
                            shape=(len(self.bajos), self.cantidad)).tocsc()
        return milp(np.asarray(objetivo, dtype=float), integrality=np.asarray(enteros),
                    bounds=Bounds(np.asarray(cota_bajo, dtype=float), np.asarray(cota_alto, dtype=float)),
                    constraints=LinearConstraint(matriz, np.asarray(self.bajos, dtype=float),
                                                 np.asarray(self.altos, dtype=float)),
                    options={'mip_rel_gap': 0.0, 'presolve': True, 'time_limit': float(tiempo)})


def resolver_modelo(modelo):
    """Busqueda de Targets en tres pasos.

    Paso 1: MLU minima posible (z*) con un MILP basado en caminos candidatos y con los
    recursos libres de cada switch como restriccion.
    Paso 2: con la MLU limitada a z* mas la tolerancia, generar Targets que minimicen,
    en este orden, los saltos sin respaldo FF, los cambios de ruta y la longitud total,
    excluyendo cada solucion ya encontrada.
    Paso 3 (embudo): verificar proteccion, recursos y transicion, y seleccionar uno.

    Proteccion: 'prioridad' (predeterminado) la minimiza dentro de la tolerancia;
    'estricta' prohibe Targets menos protegidos que las rutas FF; 'ninguna' la ignora.
    """
    import numpy as np
    parametros = modelo['parametros']
    enlaces = modelo['enlaces']
    if any(not math.isfinite(e['capacidad']) or e['capacidad'] <= 0 for e in enlaces):
        raise ValueError('CAPACIDAD_NO_VALIDA')
    if len(modelo['fondo']) != len(enlaces):
        raise ValueError('FONDO_INCONSISTENTE')
    if any(not math.isfinite(x) or x < 0 for x in modelo['fondo']):
        raise ValueError('FONDO_NO_VALIDO')
    for f in modelo['flujos']:
        if not math.isfinite(f['demanda']) or f['demanda'] < 0:
            raise ValueError('DEMANDA_NO_VALIDA')
    flujos = modelo['flujos']
    vigentes = {f['id']: list(f['ruta']) for f in flujos}
    referencia = maximo_utilizacion(modelo, calcular_cargas(modelo, vigentes))
    mejora_minima = float(parametros['mejora_minima_pp'])
    base = dict(referencia=referencia, mejora_minima=mejora_minima)
    if not enlaces or not any(f['demanda'] > parametros['demanda_minima'] for f in flujos):
        return dict(base, estado='CONSERVAR_FF', motivo='SIN_DEMANDA_REENRUTABLE', mlu=referencia)

    arcos = arcos_de(modelo)
    grafo = grafo_de(arcos)
    modo, candidatos = generar_candidatos(modelo, parametros)
    atributos = {f['id']: [atributos_camino(arcos, grafo, p, f['origen'], f['destino'])
                           for p in candidatos[f['id']]] for f in flujos}
    if any(not candidatos[f['id']] for f in flujos):
        return dict(base, estado='CONSERVAR_FF', motivo='COMUNICACION_SIN_CAMINOS')

    variables = [(f['id'], i) for f in flujos for i in range(len(candidatos[f['id']]))]
    indice = {v: n for n, v in enumerate(variables)}
    iz = len(variables)
    cantidad = iz + 1
    demanda = {f['id']: f['demanda'] for f in flujos}
    vigente_idx = {f['id']: candidatos[f['id']].index(tuple(f['ruta'])) for f in flujos}
    proteccion_ref = sum(atributos[f['id']][vigente_idx[f['id']]]['sin_respaldo'] for f in flujos)
    recursos = modelo.get('recursos')

    def problema(con_proteccion):
        p = ProblemaMILP(cantidad)
        for f in flujos:
            p.agregar({indice[(f['id'], i)]: 1.0 for i in range(len(candidatos[f['id']]))}, 1, 1)
        uso = defaultdict(dict)
        for (fid, i), n in indice.items():
            for j in candidatos[fid][i]:
                uso[j][n] = uso[j].get(n, 0.0) + demanda[fid]
        for j, e in enumerate(enlaces):
            coefs = dict(uso[j])
            coefs[iz] = -e['capacidad']
            p.agregar(coefs, hi=-modelo['fondo'][j])
        if con_proteccion:
            p.agregar({n: float(atributos[fid][i]['sin_respaldo']) for (fid, i), n in indice.items()},
                      hi=proteccion_ref)
        if recursos is not None:
            switches = {str(s) for s in recursos['reglas']} | {str(s) for s in recursos['grupos']}
            for sw in switches:
                p.agregar({n: float(atributos[fid][i]['reglas'].get(int(sw), 0))
                           for (fid, i), n in indice.items()}, hi=recursos['reglas'].get(sw, 0))
                p.agregar({n: float(atributos[fid][i]['grupos'].get(int(sw), 0))
                           for (fid, i), n in indice.items()}, hi=recursos['grupos'].get(sw, 0))
            p.agregar({n: float(atributos[fid][i]['etiquetas']) for (fid, i), n in indice.items()},
                      hi=recursos['etiquetas'])
        return p

    enteros = [1] * len(variables) + [0]
    tiempo = parametros['tiempo_solver']

    def extraer(res):
        x = res.x
        if x is None or not np.isfinite(x).all():
            raise ValueError('SOLUCION_NO_FINITA')
        if np.max(np.abs(x[:iz] - np.rint(x[:iz]))) > 1e-6:
            raise ValueError('SOLUCION_NO_ENTERA')
        elegidos = {}
        for (fid, i), n in indice.items():
            if round(x[n]) == 1:
                if fid in elegidos:
                    raise ValueError('DOS_CAMINOS_PARA_UNA_COMUNICACION')
                elegidos[fid] = i
        if len(elegidos) != len(flujos):
            raise ValueError('COMUNICACION_SIN_CAMINO_EN_SOLUCION')
        return elegidos

    def certificado(res):
        # HiGHS solo informa estado 0 (Optimal) cuando la brecha entre la solucion y la cota
        # cumple sus tolerancias (relativa 0 y absoluta 1e-6); la brecha se registra igual.
        return res.status == 0 and (getattr(res, 'mip_gap', 0.0) or 0.0) <= 1e-4

    # Paso 1: MLU minima; en modo estricto tambien sin la exigencia, como referencia.
    modo_proteccion = str(parametros['proteccion'])
    proteccion = modo_proteccion == 'estricta'
    cota_bajo = [0.0] * cantidad
    cota_alto = [1.0] * len(variables) + [math.inf]
    objetivo = [0.0] * len(variables) + [1.0]
    res = problema(proteccion).resolver(objetivo, enteros, cota_bajo, cota_alto, tiempo)
    if res.status == 2:
        return dict(base, estado='CONSERVAR_FF', motivo='SIN_CONFIGURACION_FACTIBLE_CON_RECURSOS_Y_PROTECCION')
    if not certificado(res):
        return dict(base, estado='SIN_OPTIMO_CERTIFICADO',
                    motivo=f'{res.message} | brecha {getattr(res, "mip_gap", None)}')
    optimo_sol = extraer(res)
    base['brecha_optimo'] = float(getattr(res, 'mip_gap', 0.0) or 0.0)
    z_opt = 100.0 * float(res.x[iz])
    z_libre = z_opt
    if proteccion:
        libre = problema(False).resolver(objetivo, enteros, cota_bajo, cota_alto, tiempo)
        if certificado(libre):
            z_libre = 100.0 * float(libre.x[iz])
    estadisticas = dict(modo=modo, caminos=sum(len(v) for v in candidatos.values()),
                        por_comunicacion={k: len(v) for k, v in candidatos.items()},
                        fijas=sum(1 for f in flujos if f['demanda'] <= parametros['demanda_minima']),
                        variables=len(variables))
    base.update(z_opt=z_opt, z_libre=z_libre, proteccion_ref=proteccion_ref, candidatos=estadisticas,
                modo_proteccion=modo_proteccion, tolerancia=float(parametros['tolerancia_pp']))
    if z_opt > referencia - mejora_minima:
        return dict(base, estado='CONSERVAR_FF', motivo='MEJORA_MENOR_QUE_LA_MINIMA_EXIGIDA', mlu=z_opt)

    # Paso 2: Targets dentro de la tolerancia, priorizando menos cambios y caminos cortos.
    cota = min(z_opt + float(parametros['tolerancia_pp']), referencia - mejora_minima)
    base['cota'] = cota
    peso = 1 + sum(max(a['saltos'] for a in atributos[f['id']]) for f in flujos)
    peso_proteccion = peso * (len(flujos) + 1) if modo_proteccion != 'ninguna' else 0.0
    objetivo2 = [0.0] * cantidad
    for (fid, i), n in indice.items():
        objetivo2[n] = (peso_proteccion * atributos[fid][i]['sin_respaldo'] +
                        (peso if i != vigente_idx[fid] else 0.0) + atributos[fid][i]['saltos'])
    cota_alto2 = list(cota_alto)
    cota_alto2[iz] = cota / 100.0 + 1e-9
    segundo = problema(proteccion)
    soluciones = [('OPTIMO_MLU', optimo_sol)]
    vistas = {tuple(sorted(optimo_sol.items()))}
    while len(soluciones) < int(parametros['max_targets']):
        res2 = segundo.resolver(objetivo2, enteros, cota_bajo, cota_alto2, tiempo)
        if res2.status == 2:
            break
        if not certificado(res2):
            break
        sol = extraer(res2)
        firma = tuple(sorted(sol.items()))
        segundo.agregar({indice[(fid, i)]: 1.0 for fid, i in sol.items()}, hi=len(sol) - 1)
        if firma in vistas:
            continue
        vistas.add(firma)
        soluciones.append(('MENOS_CAMBIOS', sol))

    # Paso 3: embudo de verificacion y seleccion.
    targets = []
    for numero, (origen_t, sol) in enumerate(soluciones, 1):
        rutas = {fid: list(candidatos[fid][i]) for fid, i in sol.items()}
        cargas = calcular_cargas(modelo, rutas)
        mlu = maximo_utilizacion(modelo, cargas)
        elegidos = [atributos[fid][i] for fid, i in sol.items()]
        sin_respaldo = sum(a['sin_respaldo'] for a in elegidos)
        reglas_sw, grupos_sw = defaultdict(int), defaultdict(int)
        for a in elegidos:
            for sw, n in a['reglas'].items():
                reglas_sw[sw] += n
            for sw, n in a['grupos'].items():
                grupos_sw[sw] += n
        etiquetas = sum(a['etiquetas'] for a in elegidos)
        cambios = sorted(fid for fid, i in sol.items() if i != vigente_idx[fid])
        t = dict(id=f'T{numero}', origen=origen_t, rutas=rutas, cargas=cargas, mlu=mlu,
                 cambios=cambios, sin_respaldo=sin_respaldo, reglas=sum(reglas_sw.values()),
                 grupos=sum(grupos_sw.values()), etiquetas=etiquetas,
                 saltos=sum(a['saltos'] for a in elegidos), estado='APTO', motivo='')
        if proteccion and sin_respaldo > proteccion_ref:
            t.update(estado='DESCARTADO', motivo='MENOR_PROTECCION_QUE_FF')
        elif recursos is not None and (
                etiquetas > recursos['etiquetas'] or
                any(n > recursos['reglas'].get(str(sw), 0) for sw, n in reglas_sw.items()) or
                any(n > recursos['grupos'].get(str(sw), 0) for sw, n in grupos_sw.items())):
            t.update(estado='DESCARTADO', motivo='RECURSOS_INSUFICIENTES')
        elif mlu > cota + 1e-6:
            t.update(estado='DESCARTADO', motivo='FUERA_DE_TOLERANCIA')
        else:
            plan = planificar_transition(modelo, rutas)
            if plan is None:
                t.update(estado='DESCARTADO', motivo='TRANSICION_NO_ADMISIBLE')
            else:
                t['transition'] = plan
                t['pico'] = plan['pico']
        targets.append(t)
    aptos = [t for t in targets if t['estado'] == 'APTO']
    if not aptos:
        return dict(base, estado='CONSERVAR_FF', motivo='TODOS_LOS_TARGETS_DESCARTADOS', targets=targets)
    elegido = min(aptos, key=lambda t: ((t['sin_respaldo'] if modo_proteccion != 'ninguna' else 0),
                                        len(t['cambios']), round(t['pico'], 6), round(t['mlu'], 6),
                                        t['reglas'], t['saltos'], t['id']))
    elegido['estado'] = 'ELEGIDO'
    return dict(base, estado='TARGET_SELECCIONADO', targets=targets, elegido=elegido['id'],
                rutas=elegido['rutas'], cargas=elegido['cargas'], mlu=elegido['mlu'],
                transition=elegido['transition'], certificado=True)


def planificar_transition(modelo, nuevas):
    """Orden de activacion que minimiza la MLU maxima de los estados intermedios.

    El estado inicial no se cuenta, porque ya existe y no depende del orden. Se descartan
    estados que superen la capacidad salvo que el inicial o el final ya la superen.
    """
    anteriores = {f['id']: f['ruta'] for f in modelo['flujos']}
    cambios = [f for f in modelo['flujos'] if list(f['ruta']) != list(nuevas[f['id']])]
    inicial = calcular_cargas(modelo, anteriores)
    final = calcular_cargas(modelo, nuevas)
    techo = [max(e['capacidad'], a, b) for e, a, b in zip(modelo['enlaces'], inicial, final)]
    mlu0 = maximo_utilizacion(modelo, inicial)
    if not cambios:
        return dict(orden=[], pico=mlu0, estados=1, intermedios=[], inicial=mlu0, certificado=True)
    diferencias = []
    for f in cambios:
        delta = defaultdict(float)
        for e in f['ruta']:
            delta[e] -= f['demanda']
        for e in nuevas[f['id']]:
            delta[e] += f['demanda']
        diferencias.append(dict(delta))
    objetivo = (1 << len(cambios)) - 1
    frontera = [(0.0, (), 0)]
    mejores = {0: (0.0, ())}
    evaluados = 0
    while frontera:
        pico, orden, mascara = heapq.heappop(frontera)
        if mejores.get(mascara) != (pico, orden):
            continue
        evaluados += 1
        cargas = inicial.copy()
        for i, delta in enumerate(diferencias):
            if mascara & (1 << i):
                for e, d in delta.items():
                    cargas[e] += d
        if mascara == objetivo:
            intermedios = []
            actual = inicial.copy()
            for i in orden:
                for e, d in diferencias[i].items():
                    actual[e] += d
                intermedios.append(maximo_utilizacion(modelo, actual))
            return dict(orden=[cambios[i]['id'] for i in orden], pico=pico, inicial=mlu0,
                        estados=evaluados, intermedios=intermedios, certificado=True)
        for i, delta in enumerate(diferencias):
            bit = 1 << i
            if mascara & bit:
                continue
            siguiente = cargas.copy()
            for e, d in delta.items():
                siguiente[e] += d
            if any(x > t + EPS * max(1.0, t) for x, t in zip(siguiente, techo)):
                continue
            valor = max(pico, maximo_utilizacion(modelo, siguiente))
            candidato = (valor, orden + (i,))
            estado = mascara | bit
            if estado not in mejores or candidato < mejores[estado]:
                mejores[estado] = candidato
                heapq.heappush(frontera, (valor, candidato[1], estado))
    return None


def resolver_subproceso():
    try:
        modelo = json.load(sys.stdin)
        if modelo.get('_operacion') == 'transition':
            respuesta = dict(estado='TRANSITION', plan=planificar_transition(modelo['modelo'], modelo['rutas']))
        else:
            respuesta = resolver_modelo(modelo)
    except BaseException as exc:
        respuesta = dict(estado='ERROR_CALCULO', motivo=f'{type(exc).__name__}: {exc}')
    print(json.dumps(respuesta, allow_nan=False), flush=True)


def tasa_tc(valor):
    if isinstance(valor, (int, float)):
        return float(valor) * 8.0 / 1e6
    if isinstance(valor, str):
        import re
        m = re.fullmatch(r'\s*([0-9.]+)\s*([kKmMgGtT]?)(bit|bps|Bps|b)?\s*', valor)
        if m:
            factor = {'': 1, 'k': 1e3, 'm': 1e6, 'g': 1e9, 't': 1e12}[m[2].lower()]
            return float(m[1]) * factor * (8 if m[3] in (None, 'Bps', 'b') else 1) / 1e6
    return None


def leer_json_tc(argumentos):
    """Salida JSON de tc; una salida vacia o no interpretable se trata como lista vacia."""
    salida = subprocess.check_output(['tc', '-j'] + argumentos, stderr=subprocess.PIPE, timeout=3,
                                     text=True, env=dict(os.environ, LC_ALL='C'))
    try:
        datos = json.loads(salida) if salida.strip() else []
    except json.JSONDecodeError:
        return None, salida
    return datos, salida


def capacidad_local(nombre, velocidad):
    respaldo_openflow = (velocidad / 1000.0, 'OPENFLOW_CURR_SPEED') if velocidad > 0 else (None, 'DESCONOCIDA')
    if not nombre or '/' in nombre or not os.path.exists('/sys/class/net/' + nombre):
        return respaldo_openflow
    try:
        clases, salida = leer_json_tc(['class', 'show', 'dev', nombre])
        if clases is None:
            clases = []
            for linea in salida.splitlines():
                palabras = linea.split()
                if not palabras:
                    continue
                if len(palabras) < 4 or palabras[:2] != ['class', 'htb']:
                    raise ValueError('CLASE_TC_TEXTO_NO_INTERPRETABLE')
                clase = {'kind': 'htb', 'handle': palabras[2]}
                if palabras[3] == 'root':
                    clase['root'] = True
                elif palabras[3] == 'parent' and len(palabras) > 4:
                    clase['parent'] = palabras[4]
                else:
                    raise ValueError('JERARQUIA_TC_NO_INTERPRETABLE')
                for campo in ('rate', 'ceil'):
                    if campo not in palabras or palabras.index(campo) + 1 >= len(palabras):
                        raise ValueError('TASA_HTB_INCOMPLETA')
                    clase[campo] = palabras[palabras.index(campo) + 1]
                clases.append(clase)
        if not isinstance(clases, list) or any(
            not isinstance(c, dict) or not isinstance(c.get('options', {}), dict) for c in clases
        ):
            raise ValueError('CLASES_TC_NO_INTERPRETABLES')
        raices = [c for c in clases if c.get('root') or c.get('parent') in (None, 'root')]
        if not raices and len(clases) == 1:
            raices = clases
        if raices:
            opciones = [dict(c, **c.get('options', {})) for c in raices]
            limites = [tasa_tc(c.get('ceil', c.get('rate'))) for c in opciones]
            if all(x is not None and x > 0 for x in limites):
                return sum(limites), 'TC_CLASSES'
        colas, _ = leer_json_tc(['qdisc', 'show', 'dev', nombre])
        for c in colas or []:
            if isinstance(c, dict) and c.get('root') and c.get('kind') in ('tbf', 'cake'):
                opciones = dict(c, **(c.get('options') or {}))
                limite = tasa_tc(opciones.get('rate', opciones.get('bandwidth')))
                if limite is not None and limite > 0:
                    return limite, 'TC_QDISC'
        if any(isinstance(c, dict) and c.get('kind') in ('htb', 'hfsc', 'tbf', 'cake', 'netem')
               for c in colas or []):
            return None, 'TC_NO_INTERPRETABLE'
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        detalle = getattr(error, 'stderr', None)
        if isinstance(detalle, bytes):
            detalle = detalle.decode('utf-8', errors='replace')
        mensaje = ' '.join(f'{error} {detalle or ""}'.split())
        return None, f'TC_ERROR_{type(error).__name__}: {mensaje}'
    if '/virtual/' in os.path.realpath('/sys/class/net/' + nombre):
        return None, 'INTERFAZ_VIRTUAL_SIN_CAPACIDAD_DECLARADA'
    return respaldo_openflow


def registro_configurado():
    """Ruta del archivo efimero del ultimo ciclo; FORT_REGISTRO=no lo desactiva."""
    valor = os.environ.get('FORT_REGISTRO', 'ultimo_ciclo.json')
    if valor.strip().lower() in ('', 'no', 'ninguno'):
        return None
    return os.path.abspath(valor)


def a_json(valor):
    """Convierte estructuras internas (tuplas, conjuntos, claves no textuales) a JSON."""
    if isinstance(valor, dict):
        return {str(k) if not isinstance(k, tuple) else '|'.join(map(str, k)): a_json(v)
                for k, v in valor.items()}
    if isinstance(valor, (list, tuple)):
        return [a_json(v) for v in valor]
    if isinstance(valor, (set, frozenset)):
        return [a_json(v) for v in sorted(valor, key=str)]
    if isinstance(valor, float) and not math.isfinite(valor):
        return None
    if isinstance(valor, (str, int, float, bool)) or valor is None:
        return valor
    return str(valor)


@dataclass
class Host:
    ip: str
    mac: str
    switch: int
    puerto: int
    nombre: str


@dataclass
class Regla:
    switch: int
    cookie: int
    prioridad: int
    match: dict
    acciones: list


@dataclass
class Grupo:
    switch: int
    identificador: int
    principal: int
    respaldo: int
    etiqueta: int


@dataclass
class Comunicacion:
    identificador: str
    origen: Host
    destino: Host
    ruta: list
    cookie: int
    etiqueta: int
    grupos: list = field(default_factory=list)
    reglas: list = field(default_factory=list)
    ingresos: list = field(default_factory=list)
    respaldos: dict = field(default_factory=dict)
    etiquetas: set = field(default_factory=set)


if __name__ == '__main__' and '--resolver' in sys.argv:
    resolver_subproceso()
    sys.exit(0)


import importlib.util

if importlib.util.find_spec('os_ken') is not None:
    os.environ.setdefault('OSKEN_HUB_TYPE', 'eventlet')
    from os_ken import cfg
    from os_ken.base import app_manager
    from os_ken.controller import ofp_event
    from os_ken.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, DEAD_DISPATCHER, set_ev_cls
    from os_ken.lib import hub
    from os_ken.lib.packet import packet, ethernet, arp, ipv4, vlan
    from os_ken.ofproto import ofproto_v1_3, ofproto_protocol
    from os_ken.topology import event as topo_event
    from os_ken.topology.api import get_link
    from os_ken.topology import switches
    from eventlet import tpool

    class FORT(app_manager.OSKenApp):
        OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.dps = {}
            self.puertos = {}
            self.nombres = {}
            self.features = {}
            self.tablas = {}
            self.enlaces = set()
            self.conocidos = set()
            self.fallos = set()
            self.observados = {}
            self.hosts = {}
            self.capacidades = {}
            self.cap_fuentes = {}
            self.capacidad_cache = {}
            self.version_lista_datos = None
            self.pendientes = {}
            self.errores = deque(maxlen=32)
            self.numero_error = 0
            self.version = 0
            self.ciclo = 0
            self.ultimo_cambio = time.monotonic()
            self.latencias = deque([0.1], maxlen=32)
            self.intervalo = float(os.environ.get('FORT_INTERVALO', '2'))
            if not math.isfinite(self.intervalo) or self.intervalo <= 0:
                raise ValueError('FORT_INTERVALO debe ser positivo')
            self.vigentes = {}
            self.registro = {}
            self.etiquetas = set()
            self.etiquetas_externas = set()
            self.grupos_usados = defaultdict(set)
            self.cookies_usadas = set()
            self.secuencia = (uuid.uuid4().int & 0xFFFFFFFF) << 16
            self.legado = []
            self.legado_grupos = defaultdict(set)
            self.proceso = None
            self.activo = True
            self.lista = False
            self.reconstruir = True
            self.incidente = False
            self.referencia_inicial = {}
            self.analisis = None
            self.transaccion = None
            self.ultimo_mensaje = {}
            self.secuencia_hosts = 0
            self.capacidad_declarada = self.leer_capacidades()
            self.ventanas = max(1, int(os.environ.get('FORT_VENTANAS', '3')))
            self.variacion_maxima = float(os.environ.get('FORT_VARIACION_MAXIMA', '10'))
            self.entrega_minima = float(os.environ.get('FORT_ENTREGA_MINIMA', '95'))
            self.umbral_saturacion = float(os.environ.get('FORT_UMBRAL_SATURACION', '95'))
            self.intentos_maximos = max(1, int(os.environ.get('FORT_INTENTOS_ESTABILIZACION', '5')))
            self.modo = os.environ.get('FORT_MODO', 'fort').lower()
            if self.modo not in ('fort', 'ff'):
                raise ValueError('FORT_MODO debe ser fort o ff')
            self.detalle = os.environ.get('FORT_DETALLE', 'normal').lower()
            self.registro_ruta = registro_configurado()
            self.evaluaciones_maximas = max(0, int(os.environ.get('FORT_EVALUACIONES', '10')))
            self.intervalo_evaluacion = float(os.environ.get('FORT_INTERVALO_EVALUACION', '10'))
            self.parametros_solver = dict(
                tolerancia_pp=float(os.environ.get('FORT_TOLERANCIA_PP', '1.0')),
                mejora_minima_pp=float(os.environ.get('FORT_MEJORA_MINIMA_PP', '1.0')),
                max_targets=max(1, int(os.environ.get('FORT_MAX_TARGETS', '8'))),
                limite_caminos=max(1, int(os.environ.get('FORT_LIMITE_CAMINOS', '5000'))),
                holgura=max(0, int(os.environ.get('FORT_HOLGURA', '2'))),
                k=max(1, int(os.environ.get('FORT_K', '8'))),
                proteccion=os.environ.get('FORT_PROTECCION', 'prioridad').lower(),
                demanda_minima=float(os.environ.get('FORT_DEMANDA_MINIMA', '0.01')),
                tiempo_solver=float(os.environ.get('FORT_TIEMPO_SOLVER', '120')))
            if self.parametros_solver['proteccion'] not in ('prioridad', 'estricta', 'ninguna'):
                raise ValueError('FORT_PROTECCION debe ser prioridad, estricta o ninguna')
            self.intentos_estabilidad = 0
            self.evaluacion = None
            self.tiempos = {}
            self.topologia_mostrada = None
            self.ultima_limpieza = None
            self.emitir('INICIO', f'OpenFlow 1.3 | modo {self.modo} | {self.ventanas} ventanas de medicion | '
                        f"tolerancia {self.parametros_solver['tolerancia_pp']:g} pp | "
                        f"proteccion {self.parametros_solver['proteccion']} | sin historial persistente")
            self.emitir('DESCUBRIMIENTO', 'Los hosts se reconocen mediante ARP/IPv4; pingall permite anunciarlos en Mininet.')
            self.threads.append(hub.spawn(self.supervisar))

        def leer_capacidades(self):
            ruta = os.environ.get('FORT_CAPACIDADES')
            if not ruta:
                return {}
            with open(ruta, encoding='utf-8') as archivo:
                datos = json.load(archivo)
            resultado = {}
            for nombre, valor in datos.items():
                numero = float(valor)
                if not math.isfinite(numero) or numero <= 0:
                    raise ValueError('CAPACIDAD_DECLARADA_NO_VALIDA: ' + nombre)
                resultado[str(nombre)] = numero
            return resultado

        def emitir(self, estado, mensaje):
            print(f'[{VERSION} v{self.version} c{self.ciclo}] {estado} | {mensaje}', flush=True)

        def avisar(self, clave, texto):
            firma = (self.version, texto)
            if self.ultimo_mensaje.get(clave) != firma:
                self.ultimo_mensaje[clave] = firma
                self.emitir(clave, texto)

        def nombre_sw(self, sw):
            return self.nombres.get(sw, f'DPID-{sw:x}')

        def texto_enlace(self, e):
            return f'{self.nombre_sw(e[0])}:{e[1]}->{self.nombre_sw(e[2])}:{e[3]}'

        def texto_ruta(self, comunicacion, ruta):
            if ruta is None:
                return 'SIN_CAMINO_OPERATIVO'
            partes = [comunicacion.origen.nombre, self.nombre_sw(comunicacion.origen.switch)]
            partes.extend(self.nombre_sw(e[2]) for e in ruta)
            partes.append(comunicacion.destino.nombre)
            return ' -> '.join(partes)

        def comprobar(self, version):
            if not self.activo or version != self.version:
                raise Cancelado()

        def esperar(self, segundos, version):
            fin = time.monotonic() + segundos
            while time.monotonic() < fin:
                self.comprobar(version)
                hub.sleep(min(0.1, max(0, fin - time.monotonic())))

        def cambiar(self, motivo, tipo='cambio', referencia=None, evento='CAMBIO_DE_RED'):
            if self.lista or self.vigentes:
                self.referencia_inicial = referencia if referencia is not None else {
                    k: self.texto_ruta(c, self.ruta_efectiva(c)) for k, c in self.vigentes.items()}
            if tipo == 'fallo' and self.vigentes and not self.incidente:
                self.ciclo += 1
                self.tiempos = dict(fallo=time.monotonic())
            self.intentos_estabilidad = 0
            if self.evaluacion is not None:
                self.cerrar_evaluacion('EVALUACION_INTERRUMPIDA', motivo)
            self.version += 1
            self.capacidad_cache.clear()
            self.cap_fuentes.clear()
            self.version_lista_datos = None
            self.ultimo_cambio = time.monotonic()
            self.analisis = None
            self.transaccion = None
            self.ultimo_mensaje.clear()
            if tipo == 'fallo' and self.vigentes:
                self.incidente = True
                self.reconstruir = False
            elif tipo in ('recuperacion', 'cambio'):
                self.reconstruir = True
            if self.proceso is not None and self.proceso.poll() is None:
                try:
                    self.proceso.terminate()
                except ProcessLookupError:
                    pass
            if self.lista or self.detalle == 'completo':
                self.emitir(evento, motivo)

        def puerto_vivo(self, sw, puerto):
            p = self.puertos.get((sw, puerto))
            return sw in self.dps and p is not None and not (p.state & ofproto_v1_3.OFPPS_LINK_DOWN or p.config & ofproto_v1_3.OFPPC_PORT_DOWN)

        def enviar(self, dp, mensaje, version=None):
            if version is not None:
                self.comprobar(version)
            if self.dps.get(dp.id) is not dp:
                raise NoVerificable('CONEXION_OPENFLOW_REEMPLAZADA')
            dp.send_msg(mensaje)

        def iniciar_consulta(self, dp, mensaje, tipo, version=None):
            dp.set_xid(mensaje)
            clave = (id(dp), mensaje.xid)
            registro = dict(dp=dp, tipo=tipo, datos=[], inicio=time.monotonic(), fin=None, error=None)
            self.pendientes[clave] = registro
            try:
                self.enviar(dp, mensaje, version)
            except BaseException:
                self.pendientes.pop(clave, None)
                raise
            return clave, registro

        def terminar_consultas(self, consultas, version=None):
            limite = max(5.0, 8.0 * max(self.latencias))
            try:
                while any(r['fin'] is None and r['error'] is None for _, r in consultas):
                    if version is not None:
                        self.comprobar(version)
                    if any(time.monotonic() - r['inicio'] > limite for _, r in consultas if r['fin'] is None):
                        faltantes = ', '.join(
                            self.nombre_sw(r['dp'].id) + ':' + r['tipo']
                            for _, r in consultas if r['fin'] is None
                        )
                        raise NoVerificable(
                            'OPENFLOW_SIN_RESPUESTA_COMPLETA: ' + faltantes
                        )
                    if any(self.dps.get(r['dp'].id) is not r['dp'] for _, r in consultas):
                        raise NoVerificable('SWITCH_DESCONECTADO_DURANTE_CONSULTA')
                    hub.sleep(0.01)
                if any(r['error'] is not None for _, r in consultas):
                    raise NoVerificable('OPENFLOW_ERROR: ' + str([r['error'] for _, r in consultas if r['error']]))
                for _, r in consultas:
                    self.latencias.append(r['fin'] - r['inicio'])
                return [r for _, r in consultas]
            finally:
                for clave, _ in consultas:
                    self.pendientes.pop(clave, None)

        def consultar(self, dp, mensaje, tipo, version=None):
            return self.terminar_consultas([self.iniciar_consulta(dp, mensaje, tipo, version)], version)[0]

        @set_ev_cls([ofp_event.EventOFPPortDescStatsReply, ofp_event.EventOFPFlowStatsReply,
                     ofp_event.EventOFPGroupDescStatsReply, ofp_event.EventOFPGroupStatsReply,
                     ofp_event.EventOFPPortStatsReply, ofp_event.EventOFPGroupFeaturesStatsReply,
                     ofp_event.EventOFPTableFeaturesStatsReply,
                     ofp_event.EventOFPBarrierReply], [CONFIG_DISPATCHER, MAIN_DISPATCHER])
        def respuesta(self, ev):
            msg = ev.msg
            registro = self.pendientes.get((id(msg.datapath), msg.xid))
            if registro is None:
                return
            cuerpo = getattr(msg, 'body', [])
            registro['datos'].extend(cuerpo if isinstance(cuerpo, list) else [cuerpo])
            if not getattr(msg, 'flags', 0) & ofproto_v1_3.OFPMPF_REPLY_MORE:
                registro['fin'] = time.monotonic()

        @set_ev_cls(ofp_event.EventOFPErrorMsg, [CONFIG_DISPATCHER, MAIN_DISPATCHER])
        def error_openflow(self, ev):
            msg = ev.msg
            detalle = f'{self.nombre_sw(msg.datapath.id)} tipo={msg.type} codigo={msg.code} xid={msg.xid}'
            self.numero_error += 1
            self.errores.append(detalle)
            registro = self.pendientes.get((id(msg.datapath), msg.xid))
            if registro is not None:
                registro['error'] = detalle
            self.emitir('ERROR_OPENFLOW', detalle)

        @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
        def conectar(self, ev):
            dp = ev.msg.datapath
            anterior = self.dps.get(dp.id)
            self.dps[dp.id] = dp
            if anterior is not dp:
                self.features.pop(dp.id, None)
                self.tablas.pop(dp.id, None)
                self.puertos = {k: v for k, v in self.puertos.items() if k[0] != dp.id}
                self.grupos_usados[dp.id].clear()
                self.cambiar(f'DPID {dp.id:x}', evento='SWITCH_CONECTADO')
                self.actualizar_enlaces()
            hub.spawn(self.preparar_switch, dp)

        @set_ev_cls(ofp_event.EventOFPStateChange, DEAD_DISPATCHER)
        def desconectar(self, ev):
            dp = ev.datapath
            if self.dps.get(dp.id) is not dp:
                return
            self.cambiar(self.nombre_sw(dp.id), 'fallo', evento='SWITCH_DESCONECTADO')
            self.dps.pop(dp.id, None)
            self.features.pop(dp.id, None)
            self.tablas.pop(dp.id, None)
            self.actualizar_enlaces()

        def preparar_switch(self, dp):
            try:
                p, o = dp.ofproto_parser, dp.ofproto
                consultas = [self.iniciar_consulta(dp, p.OFPPortDescStatsRequest(dp, 0), 'puertos'),
                             self.iniciar_consulta(dp, p.OFPGroupFeaturesStatsRequest(dp, 0), 'features'),
                             self.iniciar_consulta(dp, p.OFPTableFeaturesStatsRequest(dp, 0, []), 'tablas'),
                             self.iniciar_consulta(dp, p.OFPGroupDescStatsRequest(dp, 0), 'grupos'),
                             self.iniciar_consulta(dp, p.OFPFlowStatsRequest(dp, match=p.OFPMatch()), 'flujos')]
                respuestas = self.terminar_consultas(consultas)
                for r in respuestas:
                    if r['tipo'] == 'puertos':
                        for puerto in r['datos']:
                            self.puertos[dp.id, puerto.port_no] = puerto
                            if puerto.port_no == o.OFPP_LOCAL:
                                self.nombres[dp.id] = puerto.name.decode(errors='replace').rstrip('\x00')
                    elif r['tipo'] == 'features':
                        if not r['datos'] or not r['datos'][0].types & (1 << o.OFPGT_FF):
                            raise NoVerificable('SWITCH_SIN_FAST_FAILOVER')
                        self.features[dp.id] = r['datos'][0]
                    elif r['tipo'] == 'tablas':
                        tabla = next((t for t in r['datos'] if t.table_id == 0), None)
                        if tabla is None:
                            raise NoVerificable('CAPACIDAD_DE_TABLA_NO_DISPONIBLE')
                        self.tablas[dp.id] = int(tabla.max_entries)
                    elif r['tipo'] == 'grupos':
                        for grupo in r['datos']:
                            self.grupos_usados[dp.id].add(grupo.group_id)
                            if grupo.group_id & 0xFFFF0000 == GROUP_PREFIX:
                                self.legado_grupos[dp.id].add(grupo.group_id)
                    else:
                        for flujo in r['datos']:
                            campos = dict(flujo.match.items())
                            etiqueta = campos.get('vlan_vid', 0)
                            if isinstance(etiqueta, int) and etiqueta & 0x1000:
                                self.etiquetas.add(etiqueta & 0xFFF)
                                if flujo.cookie & COOKIE_MASK != COOKIE_PREFIX:
                                    self.etiquetas_externas.add(etiqueta & 0xFFF)
                            if flujo.cookie & COOKIE_MASK == COOKIE_PREFIX:
                                self.cookies_usadas.add(flujo.cookie)
                                self.legado.append((dp.id, flujo))
                                if campos.get('ipv4_src') and campos.get('eth_src') and campos.get('in_port'):
                                    self.aprender_host(campos['ipv4_src'], campos['eth_src'], dp.id, campos['in_port'])
                self.instalar_auxiliares(dp)
                self.emitir('SWITCH_RECONOCIDO', self.nombre_sw(dp.id) + ' | FF disponible')
            except Exception as exc:
                if self.dps.get(dp.id) is dp and self.activo:
                    self.features.pop(dp.id, None)
                    self.avisar('SWITCH_NO_PREPARADO_' + str(dp.id), f'{self.nombre_sw(dp.id)} | {exc}')
                    hub.spawn_after(self.intervalo, self.preparar_switch, dp)

        def instalar_auxiliares(self, dp):
            o = dp.ofproto
            entradas = [(60000, dict(eth_type=0x88CC), [('controller',)]),
                        (100, dict(vlan_vid=(o.OFPVID_PRESENT, o.OFPVID_PRESENT)), []),
                        (10, dict(eth_type=0x0806), [('controller',)]),
                        (10, dict(eth_type=0x0800), [('controller',)])]
            for prioridad, campos, acciones in entradas:
                regla = Regla(dp.id, COOKIE_PREFIX, prioridad, campos, acciones)
                self.enviar_regla(regla, None)

        @set_ev_cls(ofp_event.EventOFPPortStatus, MAIN_DISPATCHER)
        def estado_puerto(self, ev):
            dp, puerto = ev.msg.datapath, ev.msg.desc
            anterior = self.puerto_vivo(dp.id, puerto.port_no)
            antes = set(self.enlaces)
            referencia = {k: self.texto_ruta(c, self.ruta_efectiva(c)) for k, c in self.vigentes.items()}
            if ev.msg.reason == dp.ofproto.OFPPR_DELETE:
                self.puertos.pop((dp.id, puerto.port_no), None)
            else:
                self.puertos[dp.id, puerto.port_no] = puerto
            actual = self.puerto_vivo(dp.id, puerto.port_no)
            if anterior == actual:
                return
            self.actualizar_enlaces()
            acceso = any((h.switch, h.puerto) == (dp.id, puerto.port_no) for h in self.hosts.values())
            if antes != self.enlaces or acceso:
                tramos = {fisico(e) for e in antes ^ self.enlaces}
                detalle = ', '.join(self.texto_fisico(e) for e in sorted(tramos)) or 'puerto de acceso'
                self.cambiar(f'{self.nombre_sw(dp.id)} puerto {puerto.port_no} | enlace {detalle}',
                             'recuperacion' if actual else 'fallo', referencia,
                             evento='ENLACE_ARRIBA' if actual else 'ENLACE_ABAJO')

        @set_ev_cls(topo_event.EventLinkAdd)
        def nuevo_enlace(self, ev):
            l = ev.link
            e = (l.src.dpid, l.src.port_no, l.dst.dpid, l.dst.port_no)
            self.observados[e] = time.monotonic()
            if e not in self.conocidos:
                sustituidos = {x for x in self.conocidos if x != e and
                               ((x[0], x[1]) == (e[0], e[1]) or (x[2], x[3]) == (e[2], e[3]))}
                self.conocidos.difference_update(sustituidos | {inverso(x) for x in sustituidos})
                for x in sustituidos:
                    self.observados.pop(x, None)
                    self.observados.pop(inverso(x), None)
                self.conocidos.add(e)
                for ip, h in list(self.hosts.items()):
                    if (h.switch, h.puerto) in ((e[0], e[1]), (e[2], e[3])):
                        self.hosts.pop(ip, None)
                self.cambiar(self.texto_enlace(e), evento='ENLACE_DESCUBIERTO')
            self.actualizar_enlaces()

        @set_ev_cls(topo_event.EventLinkDelete)
        def lldp_ausente(self, ev):
            self.actualizar_enlaces()

        def actualizar_enlaces(self):
            anteriores = set(self.enlaces)
            self.enlaces = {e for e in self.conocidos if inverso(e) in self.conocidos and
                            self.puerto_vivo(e[0], e[1]) and self.puerto_vivo(e[2], e[3])}
            self.fallos = {fisico(e) for e in self.conocidos if e not in self.enlaces}
            if anteriores != self.enlaces:
                self.ultimo_cambio = time.monotonic()

        def aprender_host(self, ip, mac, sw, puerto):
            try:
                direccion = ipaddress.IPv4Address(ip)
                if direccion.is_unspecified or direccion.is_multicast or int(direccion) == 0xFFFFFFFF:
                    return
            except ValueError:
                return
            if not self.puerto_vivo(sw, puerto):
                return
            if any((e[0], e[1]) == (sw, puerto) for e in self.conocidos):
                return
            actual = self.hosts.get(ip)
            if actual and (actual.mac, actual.switch, actual.puerto) == (mac, sw, puerto):
                return
            if actual:
                nombre = actual.nombre
            else:
                # Nombre estable derivado de la IP (10.0.0.1 -> H1), no del orden de descubrimiento.
                nombre = f'H{int(direccion) & 0xFF}'
                if any(h.nombre == nombre for h in self.hosts.values()):
                    self.secuencia_hosts += 1
                    nombre = f'{nombre}_{self.secuencia_hosts}'
            self.hosts[ip] = Host(ip, mac, sw, puerto, nombre)
            self.cambiar(f'{nombre} | {ip} ({mac}) en {self.nombre_sw(sw)}:{puerto}', evento='HOST_DESCUBIERTO')

        def arbol_puertos(self):
            grafo = grafo_de(self.enlaces)
            visitados = set()
            seleccion = set()
            for raiz in sorted(self.dps):
                if raiz in visitados:
                    continue
                visitados.add(raiz)
                cola = deque([raiz])
                while cola:
                    u = cola.popleft()
                    for e in sorted(grafo[u]):
                        if e[2] not in visitados:
                            visitados.add(e[2])
                            cola.append(e[2])
                            seleccion.add((e[0], e[1]))
                            seleccion.add((e[2], e[3]))
            return seleccion

        @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
        def paquete(self, ev):
            msg, dp = ev.msg, ev.msg.datapath
            if self.dps.get(dp.id) is not dp:
                return
            pkt = packet.Packet(msg.data)
            eth = pkt.get_protocol(ethernet.ethernet)
            if eth is None or eth.ethertype == 0x88CC or pkt.get_protocol(vlan.vlan) is not None:
                return
            ingreso = msg.match.get('in_port')
            a, v = pkt.get_protocol(arp.arp), pkt.get_protocol(ipv4.ipv4)
            if a is not None:
                origen, destino = a.src_ip, a.dst_ip
            elif v is not None:
                origen, destino = v.src, v.dst
            else:
                return
            self.aprender_host(origen, eth.src, dp.id, ingreso)
            objetivo = self.hosts.get(destino)
            salidas = []
            if objetivo and self.puerto_vivo(objetivo.switch, objetivo.puerto):
                ruta = camino(grafo_de(self.enlaces), dp.id, objetivo.switch)
                if ruta is not None:
                    salida = ruta[0][1] if ruta else objetivo.puerto
                    if salida != ingreso:
                        salidas = [salida]
            elif a is not None:
                arbol = self.arbol_puertos()
                troncales = {(e[0], e[1]) for e in self.conocidos}
                if (dp.id, ingreso) in troncales and (dp.id, ingreso) not in arbol:
                    return
                salidas = [puerto for sw, puerto in self.puertos if sw == dp.id and
                           0 < puerto < dp.ofproto.OFPP_MAX and puerto != ingreso and
                           self.puerto_vivo(sw, puerto) and ((sw, puerto) not in troncales or (sw, puerto) in arbol)]
            if salidas:
                p, o = dp.ofproto_parser, dp.ofproto
                acciones = [p.OFPActionOutput(n) for n in sorted(set(salidas))]
                self.enviar(dp, p.OFPPacketOut(dp, o.OFP_NO_BUFFER, ingreso, acciones, msg.data))

        def convertir_acciones(self, dp, acciones):
            p, o = dp.ofproto_parser, dp.ofproto
            resultado = []
            for a in acciones:
                if a[0] == 'output':
                    resultado.append(p.OFPActionOutput(a[1]))
                elif a[0] == 'group':
                    resultado.append(p.OFPActionGroup(a[1]))
                elif a[0] == 'push':
                    resultado.append(p.OFPActionPushVlan(0x8100))
                elif a[0] == 'set':
                    resultado.append(p.OFPActionSetField(vlan_vid=o.OFPVID_PRESENT | a[1]))
                elif a[0] == 'pop':
                    resultado.append(p.OFPActionPopVlan())
                elif a[0] == 'controller':
                    resultado.append(p.OFPActionOutput(o.OFPP_CONTROLLER, o.OFPCML_NO_BUFFER))
                else:
                    raise ValueError('ACCION_DESCONOCIDA')
            return resultado

        def enviar_regla(self, regla, version):
            dp = self.dps.get(regla.switch)
            if dp is None:
                raise NoVerificable('SWITCH_NO_DISPONIBLE')
            p, o = dp.ofproto_parser, dp.ofproto
            acciones = self.convertir_acciones(dp, regla.acciones)
            instrucciones = [p.OFPInstructionActions(o.OFPIT_APPLY_ACTIONS, acciones)]
            mensaje = p.OFPFlowMod(dp, cookie=regla.cookie, table_id=0, command=o.OFPFC_ADD,
                                  priority=regla.prioridad, match=p.OFPMatch(**regla.match),
                                  instructions=instrucciones, flags=o.OFPFF_RESET_COUNTS)
            self.enviar(dp, mensaje, version)

        def enviar_grupo(self, grupo, version):
            dp = self.dps.get(grupo.switch)
            if dp is None:
                raise NoVerificable('SWITCH_NO_DISPONIBLE')
            p, o = dp.ofproto_parser, dp.ofproto
            principal = p.OFPBucket(watch_port=grupo.principal, watch_group=o.OFPG_ANY,
                                    actions=self.convertir_acciones(dp, [('output', grupo.principal)]))
            respaldo = p.OFPBucket(watch_port=grupo.respaldo, watch_group=o.OFPG_ANY,
                                   actions=self.convertir_acciones(dp, [('set', grupo.etiqueta), ('output', grupo.respaldo)]))
            self.enviar(dp, p.OFPGroupMod(dp, o.OFPGC_ADD, o.OFPGT_FF, grupo.identificador,
                                         [principal, respaldo]), version)

        def barreras(self, switches, version):
            consultas = []
            for sw in sorted(set(switches)):
                dp = self.dps.get(sw)
                if dp is None:
                    raise NoVerificable('SWITCH_NO_DISPONIBLE_EN_BARRERA')
                consultas.append(self.iniciar_consulta(dp, dp.ofproto_parser.OFPBarrierRequest(dp), 'barrier', version))
            return self.terminar_consultas(consultas, version)

        def cookie_nueva(self):
            while True:
                self.secuencia = (self.secuencia + 1) & 0xFFFFFFFFFFFF
                cookie = COOKIE_PREFIX | self.secuencia
                if cookie not in self.cookies_usadas and cookie != COOKIE_PREFIX:
                    self.cookies_usadas.add(cookie)
                    return cookie

        def etiqueta_nueva(self):
            for etiqueta in range(1, 4095):
                if etiqueta not in self.etiquetas:
                    self.etiquetas.add(etiqueta)
                    return etiqueta
            raise NoVerificable('ESPACIO_DE_ETIQUETAS_AGOTADO')

        def grupo_nuevo(self, sw):
            for n in range(1, 65536):
                grupo = GROUP_PREFIX | n
                if grupo not in self.grupos_usados[sw]:
                    self.grupos_usados[sw].add(grupo)
                    return grupo
            raise NoVerificable('ESPACIO_DE_GRUPOS_AGOTADO')

        def campos(self, origen, destino, protocolo):
            if protocolo == 0x0800:
                return dict(eth_type=protocolo, ipv4_src=origen.ip, ipv4_dst=destino.ip)
            return dict(eth_type=protocolo, arp_spa=origen.ip, arp_tpa=destino.ip)

        def compilar(self, origen, destino, ruta):
            if not validar_ruta(ruta, origen.switch, destino.switch, self.enlaces):
                raise NoVerificable('RUTA_PROPUESTA_NO_VALIDA')
            identificador = origen.ip + '>' + destino.ip
            etiqueta = self.etiqueta_nueva()
            c = Comunicacion(identificador, copy.copy(origen), copy.copy(destino), list(ruta),
                             self.cookie_nueva(), etiqueta)
            c.etiquetas.add(etiqueta)
            self.registro[c.cookie] = c
            grafo = grafo_de(self.enlaces)
            acciones_principales = {}
            prefijo = set()
            for e in ruta:
                alternativa = camino(grafo, e[0], destino.switch,
                                     frozenset((e, inverso(e))), frozenset(prefijo))
                if alternativa:
                    tag = self.etiqueta_nueva()
                    c.etiquetas.add(tag)
                    grupo = Grupo(e[0], self.grupo_nuevo(e[0]), e[1], alternativa[0][1], tag)
                    c.grupos.append(grupo)
                    c.respaldos[e] = (alternativa, grupo)
                    acciones_principales[e[0]] = [('group', grupo.identificador)]
                    for protocolo in (0x0800, 0x0806):
                        for salto in alternativa[1:]:
                            campos = self.campos(origen, destino, protocolo)
                            campos['vlan_vid'] = 0x1000 | tag
                            c.reglas.append(Regla(salto[0], c.cookie, 300, campos, [('output', salto[1])]))
                        campos = self.campos(origen, destino, protocolo)
                        campos['vlan_vid'] = 0x1000 | tag
                        c.reglas.append(Regla(destino.switch, c.cookie, 300, campos,
                                               [('pop',), ('output', destino.puerto)]))
                else:
                    acciones_principales[e[0]] = [('output', e[1])]
                prefijo.add(e[0])
            for protocolo in (0x0800, 0x0806):
                for salto in ruta[1:]:
                    campos = self.campos(origen, destino, protocolo)
                    campos['vlan_vid'] = 0x1000 | etiqueta
                    c.reglas.append(Regla(salto[0], c.cookie, 300, campos, acciones_principales[salto[0]]))
                if ruta:
                    campos = self.campos(origen, destino, protocolo)
                    campos['vlan_vid'] = 0x1000 | etiqueta
                    c.reglas.append(Regla(destino.switch, c.cookie, 300, campos,
                                           [('pop',), ('output', destino.puerto)]))
                campos = self.campos(origen, destino, protocolo)
                campos.update(in_port=origen.puerto, eth_src=origen.mac, vlan_vid=0)
                acciones = [('push',), ('set', etiqueta)] + acciones_principales[origen.switch] if ruta else [('output', destino.puerto)]
                c.ingresos.append(Regla(origen.switch, c.cookie, 400, campos, acciones))
            return c

        def firma_acciones(self, acciones):
            resultado = []
            for a in acciones:
                nombre = type(a).__name__
                if nombre == 'OFPActionOutput':
                    resultado.append(('output', int(a.port)))
                elif nombre == 'OFPActionGroup':
                    resultado.append(('group', int(a.group_id)))
                elif nombre == 'OFPActionPushVlan':
                    resultado.append(('push', int(a.ethertype)))
                elif nombre == 'OFPActionPopVlan':
                    resultado.append(('pop',))
                elif nombre == 'OFPActionSetField' and a.key == 'vlan_vid':
                    resultado.append(('set', int(a.value)))
                else:
                    resultado.append(('unsupported', nombre))
            return tuple(resultado)

        def firma_esperada(self, sw, acciones):
            return self.firma_acciones(self.convertir_acciones(self.dps[sw], acciones))

        def firma_match(self, campos):
            return tuple(sorted((k, tuple(v) if isinstance(v, list) else v) for k, v in campos.items()))

        def estadisticas(self, version):
            self.comprobar(version)
            consultas = []
            for sw, dp in sorted(self.dps.items()):
                p, o = dp.ofproto_parser, dp.ofproto
                solicitudes = [
                    ('flows', p.OFPFlowStatsRequest(dp, table_id=0, out_port=o.OFPP_ANY,
                                                   out_group=o.OFPG_ANY, match=p.OFPMatch())),
                    ('ports', p.OFPPortStatsRequest(dp, 0, o.OFPP_ANY)),
                    ('groups', p.OFPGroupStatsRequest(dp, 0, o.OFPG_ALL)),
                    ('descs', p.OFPGroupDescStatsRequest(dp, 0))]
                for tipo, solicitud in solicitudes:
                    consultas.append(self.iniciar_consulta(dp, solicitud, tipo, version))
            respuestas = self.terminar_consultas(consultas, version)
            self.comprobar(version)
            datos = dict(version=version, time=time.monotonic(), flows={}, ports={}, groups={}, descs={}, ventanas={}, externas=[], ocupacion=defaultdict(int))
            for r in respuestas:
                sw, tipo = r['dp'].id, r['tipo']
                datos['ventanas'][sw, tipo] = ((r['inicio'] + r['fin']) / 2, r['fin'] - r['inicio'])
                for obj in r['datos']:
                    if tipo == 'flows':
                        datos['ocupacion'][sw] += 1
                        campos = dict(obj.match.items())
                        if obj.cookie & COOKIE_MASK != COOKIE_PREFIX:
                            datos['externas'].append((sw, obj.priority, campos))
                            continue
                        acciones = []
                        for instruccion in obj.instructions:
                            if instruccion.type != ofproto_v1_3.OFPIT_APPLY_ACTIONS:
                                raise NoVerificable('INSTRUCCION_AJENA_EN_REGLA_FORT')
                            acciones.extend(instruccion.actions)
                        clave = (sw, obj.priority, self.firma_match(campos))
                        datos[tipo][clave] = dict(cookie=obj.cookie, match=campos,
                                                 actions=self.firma_acciones(acciones),
                                                 bytes=int(obj.byte_count), paquetes=int(obj.packet_count),
                                                 duracion=obj.duration_sec + obj.duration_nsec / 1e9)
                    elif tipo == 'ports':
                        datos[tipo][sw, obj.port_no] = dict(tx=int(obj.tx_bytes), rx=int(obj.rx_bytes),
                                                          paquetes=int(obj.tx_packets),
                                                          drops=int(obj.tx_dropped), errores=int(obj.tx_errors),
                                                          duracion=obj.duration_sec + obj.duration_nsec / 1e9)
                    elif tipo == 'groups':
                        datos[tipo][sw, obj.group_id] = [(int(b.packet_count), int(b.byte_count)) for b in obj.bucket_stats]
                    else:
                        datos[tipo][sw, obj.group_id] = (obj.type, tuple(
                            (b.watch_port, b.watch_group, self.firma_acciones(b.actions)) for b in obj.buckets))
            return datos

        def verificar(self, comunicaciones, muestra, ingresos=False):
            for c in comunicaciones:
                for r in c.reglas + (c.ingresos if ingresos else []):
                    for sw, prioridad, campos in muestra.get('externas', []):
                        if sw != r.switch or prioridad < r.prioridad:
                            continue
                        separados = any(k in r.match and not isinstance(v, (tuple, list)) and
                                         not isinstance(r.match[k], (tuple, list)) and r.match[k] != v
                                         for k, v in campos.items())
                        if not separados:
                            raise NoVerificable('REGLA_EXTERNA_SUPERPUESTA: ' + self.nombre_sw(sw))
                    dato = muestra['flows'].get((r.switch, r.prioridad, self.firma_match(r.match)))
                    if dato is None or dato['cookie'] != c.cookie or dato['actions'] != self.firma_esperada(r.switch, r.acciones):
                        raise NoVerificable('REGLA_NO_VERIFICADA: ' + c.identificador)
                for g in c.grupos:
                    esperado = (ofproto_v1_3.OFPGT_FF, (
                        (g.principal, ofproto_v1_3.OFPG_ANY, self.firma_esperada(g.switch, [('output', g.principal)])),
                        (g.respaldo, ofproto_v1_3.OFPG_ANY, self.firma_esperada(g.switch, [('set', g.etiqueta), ('output', g.respaldo)]))))
                    if muestra['descs'].get((g.switch, g.identificador)) != esperado:
                        raise NoVerificable('GRUPO_FF_NO_VERIFICADO: ' + str(g.identificador))

        def ruta_efectiva(self, c):
            if not self.puerto_vivo(c.origen.switch, c.origen.puerto) or not self.puerto_vivo(c.destino.switch, c.destino.puerto):
                return None
            ruta = []
            for e in c.ruta:
                if self.puerto_vivo(e[0], e[1]):
                    if e not in self.enlaces:
                        return None
                    ruta.append(e)
                    continue
                alternativa = c.respaldos.get(e)
                if alternativa is None:
                    return None
                desvio, grupo = alternativa
                if not self.puerto_vivo(grupo.switch, grupo.respaldo) or any(x not in self.enlaces for x in desvio):
                    return None
                return ruta + list(desvio)
            return ruta

        def revisar_puertos(self, version):
            self.comprobar(version)
            anteriores = set(self.enlaces)
            accesos = {(h.switch, h.puerto) for h in self.hosts.values()}
            vivos_antes = {k for k in accesos if self.puerto_vivo(*k)}
            referencia = {
                k: self.texto_ruta(c, self.ruta_efectiva(c))
                for k, c in self.vigentes.items()
            }
            consultas = []
            try:
                for sw, dp in sorted(self.dps.items()):
                    solicitud = dp.ofproto_parser.OFPPortDescStatsRequest(dp, 0)
                    consultas.append(
                        self.iniciar_consulta(dp, solicitud, 'puertos', version)
                    )
                respuestas = self.terminar_consultas(consultas, version)
            finally:
                for clave, _ in consultas:
                    self.pendientes.pop(clave, None)

            self.comprobar(version)
            for respuesta in respuestas:
                sw = respuesta['dp'].id
                self.puertos = {
                    k: v for k, v in self.puertos.items() if k[0] != sw
                }
                for puerto in respuesta['datos']:
                    self.puertos[sw, puerto.port_no] = puerto

            self.actualizar_enlaces()
            vivos_despues = {k for k in accesos if self.puerto_vivo(*k)}
            if anteriores != self.enlaces or vivos_antes != vivos_despues:
                bajaron = bool(
                    anteriores - self.enlaces or vivos_antes - vivos_despues
                )
                self.cambiar(
                    'Cambio de puertos confirmado mediante OpenFlow',
                    'fallo' if bajaron else 'recuperacion',
                    referencia,
                    evento='CAMBIO_DE_PUERTOS'
                )
                raise Cancelado()

        def verificar_conectividad(self, version):
            self.revisar_puertos(version)
            observados = {
                (l.src.dpid, l.src.port_no, l.dst.dpid, l.dst.port_no)
                for l in get_link(self, None)
            }
            self.comprobar(version)
            pendientes = self.enlaces - observados
            if not pendientes:
                return

            self.avisar(
                'LLDP_REVALIDANDO',
                ', '.join(
                    self.texto_enlace(e) for e in sorted(pendientes)
                )
            )
            limite = max(5.0, 8.0 * max(self.latencias))
            ttl = max(1, min(65535, math.ceil(limite)))

            for e in sorted(pendientes):
                self.comprobar(version)
                dp = self.dps[e[0]]
                p, o = dp.ofproto_parser, dp.ofproto
                datos = switches.LLDPPacket.lldp_packet(
                    dp.id, e[1], self.puertos[e[0], e[1]].hw_addr, ttl
                )
                self.enviar(
                    dp,
                    p.OFPPacketOut(
                        dp,
                        o.OFP_NO_BUFFER,
                        o.OFPP_CONTROLLER,
                        [p.OFPActionOutput(e[1])],
                        datos
                    ),
                    version
                )

            fin = time.monotonic() + limite
            while True:
                self.comprobar(version)
                observados = {
                    (l.src.dpid, l.src.port_no, l.dst.dpid, l.dst.port_no)
                    for l in get_link(self, None)
                }
                self.comprobar(version)
                pendientes = self.enlaces - observados

                if not pendientes:
                    self.avisar(
                        'LLDP_REVALIDADO',
                        'Todas las direcciones operativas tienen observacion LLDP'
                    )
                    return

                if time.monotonic() >= fin:
                    detalle = ', '.join(
                        self.texto_enlace(e) for e in sorted(pendientes)
                    )
                    raise NoVerificable(
                        'CONECTIVIDAD_SIN_CONFIRMAR: ' + detalle
                    )
                hub.sleep(0.05)

        def preparar_medicion(self, version):
            if self.version_lista_datos == version:
                return
            self.avisar('PREPARACION_DATOS', 'Verificando conectividad, capacidades, reglas y contadores')
            muestra = self.medir(version)
            self.comprobar(version)
            self.version_lista_datos = version
            self.ultimo_mensaje.pop('ESPERANDO_EVIDENCIA', None)
            critico = max(muestra['RS'], key=lambda r: r['utilizacion'], default=None)
            enlace = self.texto_enlace(critico['enlace']) if critico else 'SIN_TRONCALES'
            self.emitir('RED_LISTA', f"{len(self.dps)} switches | {len(self.hosts)} hosts | "
                        f"{len(self.vigentes)} comunicaciones | carga {muestra['carga']:.2f} Mbps | "
                        f"MLU {muestra['mlu']:.2f} % en {enlace} | captura valida")

        def refrescar_capacidades(self, version):
            extremos = {(e[0], e[1]) for e in self.enlaces}
            self.capacidad_cache = {
                k: v for k, v in self.capacidad_cache.items()
                if k in extremos
            }
            existentes, fuentes = {}, {}
            vigencia = max(self.intervalo, 4.0 * max(self.latencias))

            for sw, puerto in sorted(extremos):
                self.comprobar(version)
                descriptor = self.puertos[sw, puerto]
                nombre = descriptor.name.decode(errors='replace').rstrip('\x00')
                velocidad = int(descriptor.curr_speed)
                clave = (sw, puerto)
                firma = (nombre, velocidad)
                declarado = self.capacidad_declarada.get(
                    f'{sw}:{puerto}', self.capacidad_declarada.get(nombre)
                )
                cache = self.capacidad_cache.get(clave)

                if declarado is not None:
                    valor, fuente = declarado, 'DECLARADA_POR_INTERFAZ'
                elif (
                    cache and cache['firma'] == firma
                    and time.monotonic() - cache['instante'] <= vigencia
                ):
                    valor, fuente = cache['valor'], cache['fuente']
                else:
                    valor, fuente = tpool.execute(
                        capacidad_local, nombre, velocidad
                    )
                    self.comprobar(version)
                    if (
                        valor is not None
                        and math.isfinite(valor)
                        and valor > 0
                    ):
                        self.capacidad_cache[clave] = dict(
                            firma=firma,
                            valor=valor,
                            fuente=fuente,
                            instante=time.monotonic()
                        )
                    else:
                        self.capacidad_cache.pop(clave, None)

                self.comprobar(version)
                fuentes[clave] = fuente
                if valor is not None and math.isfinite(valor) and valor > 0:
                    existentes[clave] = valor

            self.capacidades = existentes
            self.cap_fuentes = fuentes
            faltantes = [
                self.texto_enlace(e) + ' ('
                + fuentes.get((e[0], e[1]), 'DESCONOCIDA') + ')'
                for e in sorted(self.enlaces)
                if (e[0], e[1]) not in existentes
            ]
            if faltantes:
                raise NoVerificable(
                    'CAPACIDADES_NO_VERIFICADAS: ' + ', '.join(faltantes)
                )

        def delta(self, anterior, actual, campo):
            a, b = anterior.get(campo), actual.get(campo)
            if a is None or b is None or min(a, b) < 0 or max(a, b) >= (1 << 64) - 1 or b < a:
                raise NoVerificable('CONTADOR_INCOMPLETO_O_REINICIADO')
            if actual.get('duracion', 0) + EPS < anterior.get('duracion', 0):
                raise NoVerificable('CONTADOR_REINICIADO')
            return b - a

        def intervalo_muestra(self, a, b, sw, tipo):
            ta, da = a['ventanas'][sw, tipo]
            tb, db = b['ventanas'][sw, tipo]
            dt = tb - ta
            if dt <= 0 or max(da, db) > dt / 2:
                raise NoVerificable('VENTANA_DE_MEDICION_INCOHERENTE')
            return dt

        def calcular_ventana(self, a, b, rutas, enlaces):
            """Tasas de una ventana entre dos lecturas de contadores."""
            resultado = dict(enlaces=[], flujos={})
            for e in enlaces:
                clave = (e[0], e[1])
                if clave not in a['ports'] or clave not in b['ports']:
                    raise NoVerificable('CONTADOR_DE_PUERTO_AUSENTE')
                dt = self.intervalo_muestra(a, b, e[0], 'ports')
                resultado['enlaces'].append(8 * self.delta(a['ports'][clave], b['ports'][clave], 'tx') / dt / 1e6)
            for clave, c in sorted(self.vigentes.items()):
                ingreso = next(r for r in c.ingresos if r.match['eth_type'] == 0x0800)
                firma = (ingreso.switch, ingreso.prioridad, self.firma_match(ingreso.match))
                x, y = a['flows'].get(firma), b['flows'].get(firma)
                if x is None or y is None or x['cookie'] != y['cookie']:
                    raise NoVerificable('INGRESO_NO_MEDIBLE: ' + clave)
                dt = self.intervalo_muestra(a, b, ingreso.switch, 'flows')
                bytes_entrada = self.delta(x, y, 'bytes')
                paquetes = self.delta(x, y, 'paquetes')
                demanda = 8 * (bytes_entrada + (4 * paquetes if rutas[clave] else 0)) / dt / 1e6
                salida_mbps = 0.0
                if not rutas[clave]:
                    salida_mbps = 8 * bytes_entrada / dt / 1e6
                else:
                    for r in c.reglas:
                        if r.switch != c.destino.switch or r.match['eth_type'] != 0x0800 or ('output', c.destino.puerto) not in r.acciones:
                            continue
                        firma_rx = (r.switch, r.prioridad, self.firma_match(r.match))
                        rx1, rx2 = a['flows'].get(firma_rx), b['flows'].get(firma_rx)
                        if rx1 is None or rx2 is None:
                            raise NoVerificable('EGRESO_NO_MEDIBLE: ' + clave)
                        db = self.delta(rx1, rx2, 'bytes')
                        npk = self.delta(rx1, rx2, 'paquetes')
                        salida_mbps += 8 * max(0, db - 4 * npk) / self.intervalo_muestra(a, b, r.switch, 'flows') / 1e6
                resultado['flujos'][clave] = dict(demanda=demanda, tx=8 * bytes_entrada / dt / 1e6,
                                                  rx=salida_mbps, paquetes=paquetes)
            return resultado

        def evidencia_respaldos(self, a, b):
            """Bucket de respaldo activo de cada comunicacion afectada y su incremento de paquetes."""
            evidencias = {}
            for clave, c in self.vigentes.items():
                for e, (desvio, grupo) in c.respaldos.items():
                    if self.puerto_vivo(e[0], e[1]):
                        continue
                    antes = a['groups'].get((grupo.switch, grupo.identificador))
                    despues = b['groups'].get((grupo.switch, grupo.identificador))
                    if antes is None or despues is None or len(antes) != 2 or len(despues) != 2:
                        raise NoVerificable('CONTADORES_FF_NO_DISPONIBLES')
                    incremento = self.delta({'n': antes[1][0]}, {'n': despues[1][0]}, 'n')
                    evidencias[clave] = dict(grupo=grupo.identificador, switch=grupo.switch, enlace=e,
                                             incremento=incremento)
                    break
            return evidencias

        def saltos_sin_respaldo_instalados(self):
            """Saltos de las rutas efectivas que hoy no tienen un bucket de respaldo."""
            total, detalle = 0, {}
            for clave, c in self.vigentes.items():
                n = 0
                for e in c.ruta:
                    if self.puerto_vivo(e[0], e[1]):
                        if e not in c.respaldos:
                            n += 1
                        continue
                    if e in c.respaldos:
                        n += len(c.respaldos[e][0])
                    break
                detalle[clave] = n
                total += n
            return total, detalle

        def medir(self, version, ventanas=1):
            """Captura FS, RS, PS y TS con una o varias ventanas consecutivas de contadores."""
            self.comprobar(version)
            if set(self.dps) != set(self.features):
                raise NoVerificable('SWITCHES_PENDIENTES_DE_VERIFICACION')
            self.verificar_conectividad(version)
            self.refrescar_capacidades(version)
            rutas = {k: self.ruta_efectiva(c) for k, c in self.vigentes.items()}
            if any(r is None for r in rutas.values()):
                raise NoVerificable('COMUNICACION_SIN_RUTA_OPERATIVA')
            duracion = max(self.intervalo, 4.0 * max(self.latencias))
            muestras = [self.estadisticas(version)]
            self.verificar(list(self.vigentes.values()), muestras[0], True)
            for _ in range(max(1, int(ventanas))):
                self.esperar(duracion, version)
                muestra = self.estadisticas(version)
                self.verificar(list(self.vigentes.values()), muestra, True)
                if muestra['time'] - muestras[-1]['time'] > max(2 * duracion, duracion + 4 * max(self.latencias)):
                    raise NoVerificable('PAUSA_DURANTE_LA_MEDICION')
                muestras.append(muestra)
            if rutas != {k: self.ruta_efectiva(c) for k, c in self.vigentes.items()}:
                raise NoVerificable('FORWARDING_CAMBIO_DURANTE_LA_MEDICION')
            enlaces = sorted(self.enlaces)
            indices = {e: i for i, e in enumerate(enlaces)}
            claves = sorted(self.vigentes)
            por_ventana = [self.calcular_ventana(muestras[i], muestras[i + 1], rutas, enlaces)
                           for i in range(len(muestras) - 1)]
            n = len(por_ventana)
            respaldos = self.evidencia_respaldos(muestras[0], muestras[-1])
            b = muestras[-1]
            registros_rs = []
            for i, e in enumerate(enlaces):
                valores = [v['enlaces'][i] for v in por_ventana]
                capacidad = self.capacidades[e[0], e[1]]
                media = sum(valores) / n
                registros_rs.append(dict(enlace=e, capacidad=capacidad, mbps=media, mbps_max=max(valores),
                                         utilizacion=100 * media / capacidad,
                                         utilizacion_max=100 * max(valores) / capacidad))
            fs, flujos = [], []
            for clave in claves:
                c = self.vigentes[clave]
                datos = [v['flujos'][clave] for v in por_ventana]
                demanda_media = sum(d['demanda'] for d in datos) / n
                demanda_max = max(d['demanda'] for d in datos)
                tx = sum(d['tx'] for d in datos) / n
                rx = sum(d['rx'] for d in datos) / n
                paquetes = sum(d['paquetes'] for d in datos)
                respaldo = respaldos.get(clave)
                if paquetes > 0 and respaldo is not None and respaldo['incremento'] <= 0:
                    raise NoVerificable('ACTIVACION_FF_SIN_EVIDENCIA: ' + clave)
                fs.append(dict(id=clave, ruta=rutas[clave], demanda=demanda_max, demanda_media=demanda_media,
                               tx=tx, rx=rx, paquetes=paquetes, entrega=(100 * rx / tx if tx > 0 else None),
                               respaldo=respaldo,
                               respaldo_corroborado=bool(respaldo and respaldo['incremento'] > 0)))
                flujos.append(dict(id=clave, origen=c.origen.switch, destino=c.destino.switch,
                                   demanda=demanda_max, demanda_media=demanda_media,
                                   ruta=[indices[e] for e in rutas[clave]]))
            conocidos = [0.0] * len(enlaces)
            for f in flujos:
                for i in f['ruta']:
                    conocidos[i] += f['demanda_media']
            fondo = [max(0.0, r['mbps'] - k) for r, k in zip(registros_rs, conocidos)]
            grupos_ff = defaultdict(int)
            for (s, _), d in b['descs'].items():
                if d[0] == ofproto_v1_3.OFPGT_FF:
                    grupos_ff[s] += 1
            recursos = dict(etiquetas=4094 - len(self.etiquetas),
                            grupos={str(sw): max(0, self.features[sw].max_groups[ofproto_v1_3.OFPGT_FF] - grupos_ff[sw])
                                    for sw in self.dps},
                            reglas={str(sw): max(0, self.tablas.get(sw, 0) - b['ocupacion'][sw]) for sw in self.dps})
            modelo = dict(nodos=sorted(self.dps),
                          enlaces=[dict(u=e[0], v=e[2], puerto=e[1], remoto=e[3],
                                        capacidad=self.capacidades[e[0], e[1]]) for e in enlaces],
                          flujos=flujos, fondo=fondo, recursos=recursos)
            umbral = self.parametros_solver['demanda_minima']
            totales = [sum(v['flujos'][k]['tx'] for k in claves) for v in por_ventana]
            media_total = sum(totales) / n
            variacion_flujos = {}
            for clave in claves:
                valores = [v['flujos'][clave]['tx'] for v in por_ventana]
                m = sum(valores) / n
                if m > umbral:
                    variacion_flujos[clave] = 100 * (max(valores) - min(valores)) / m
            mlu_ventanas = [max((100 * v['enlaces'][i] / self.capacidades[e[0], e[1]]
                                 for i, e in enumerate(enlaces)), default=0.0) for v in por_ventana]
            calidad = dict(ventanas=n, duracion=b['time'] - muestras[0]['time'], totales=totales,
                           variacion_total=(100 * (max(totales) - min(totales)) / media_total
                                            if media_total > umbral else 0.0),
                           variacion_flujos=variacion_flujos, mlu_ventanas=mlu_ventanas)
            sin_respaldo, detalle_sin = self.saltos_sin_respaldo_instalados()
            ps = dict(grupos=sum(len(c.grupos) for c in self.vigentes.values()),
                      reglas=sum(len(c.reglas) + len(c.ingresos) for c in self.vigentes.values()),
                      sin_respaldo=sin_respaldo, sin_respaldo_por_comunicacion=detalle_sin,
                      reglas_ocupadas={sw: b['ocupacion'][sw] for sw in sorted(self.dps)},
                      grupos_ff={sw: grupos_ff[sw] for sw in sorted(self.dps)}, verificado=True)
            ts = dict(disponibles=sorted({fisico(e) for e in self.enlaces}), caidos=sorted(self.fallos),
                      capacidades={e: self.capacidades[e[0], e[1]] for e in enlaces})
            return dict(version=version, instante=b['time'], ventana=calidad['duracion'],
                        modelo=modelo, arcos=enlaces, FS=fs, RS=registros_rs, PS=ps, TS=ts, calidad=calidad,
                        mlu=max((r['utilizacion'] for r in registros_rs), default=0.0),
                        carga=sum(f['tx'] for f in fs),
                        texto_rutas={k: self.texto_ruta(self.vigentes[k], r) for k, r in rutas.items()})

        def preparar(self, comunicaciones, version):
            self.comprobar(version)
            error_inicial = self.numero_error
            por_switch = defaultdict(int)
            for c in comunicaciones:
                for g in c.grupos:
                    por_switch[g.switch] += 1
            for sw, cuantos in por_switch.items():
                feature = self.features.get(sw)
                if feature is None or len(self.grupos_usados[sw]) > feature.max_groups[ofproto_v1_3.OFPGT_FF]:
                    raise NoVerificable('CAPACIDAD_DE_GRUPOS_INSUFICIENTE: ' + self.nombre_sw(sw))
            switches = set()
            for c in comunicaciones:
                self.comprobar(version)
                for g in c.grupos:
                    self.enviar_grupo(g, version)
                    switches.add(g.switch)
                for r in c.reglas:
                    self.enviar_regla(r, version)
                    switches.add(r.switch)
                hub.sleep(0)
            self.barreras(switches, version)
            if error_inicial != self.numero_error:
                raise NoVerificable('ERROR_PREPARANDO_REGLAS_O_GRUPOS')
            muestra = self.estadisticas(version)
            self.verificar(comunicaciones, muestra, False)
            self.emitir('PREPARACION_VERIFICADA', f'{len(comunicaciones)} comunicaciones | reglas y respaldos nuevos disponibles')

        def activar(self, c, version):
            self.comprobar(version)
            errores = self.numero_error
            previa = self.estadisticas(version)
            self.verificar([c], previa, False)
            try:
                self.verificar([c], previa, True)
            except NoVerificable:
                pass
            else:
                self.vigentes[c.identificador] = c
                return
            for regla in c.ingresos:
                self.enviar_regla(regla, version)
            self.barreras([c.origen.switch], version)
            muestra = self.estadisticas(version)
            self.verificar([c], muestra, True)
            if errores != self.numero_error:
                raise NoVerificable('ERROR_ACTIVANDO_COMUNICACION')
            self.vigentes[c.identificador] = c

        def reconciliar(self, version):
            muestra = self.estadisticas(version)
            anteriores = set(self.vigentes)
            elegidos = {}
            for (sw, prioridad, firma), dato in muestra['flows'].items():
                if prioridad != 400 or dato['match'].get('eth_type') != 0x0800:
                    continue
                c = self.registro.get(dato['cookie'])
                if c is None:
                    continue
                esperado = next(r for r in c.ingresos if r.match['eth_type'] == 0x0800)
                if sw != esperado.switch or firma != self.firma_match(esperado.match) or dato['actions'] != self.firma_esperada(sw, esperado.acciones):
                    raise NoVerificable('INGRESO_INSTALADO_NO_COINCIDE_CON_INVENTARIO')
                if c.origen.ip in self.hosts and c.destino.ip in self.hosts:
                    elegidos[c.identificador] = c
            self.vigentes = elegidos
            if anteriores - set(elegidos):
                self.reconstruir = True
            for c in list(elegidos.values()):
                if self.ruta_efectiva(c) is None:
                    continue
                arp_regla = next(r for r in c.ingresos if r.match['eth_type'] == 0x0806)
                dato = muestra['flows'].get((arp_regla.switch, arp_regla.prioridad, self.firma_match(arp_regla.match)))
                if dato is None or dato['cookie'] != c.cookie or dato['actions'] != self.firma_esperada(arp_regla.switch, arp_regla.acciones):
                    self.enviar_regla(arp_regla, version)
                    self.barreras([arp_regla.switch], version)
                try:
                    self.verificar([c], muestra, False)
                except NoVerificable:
                    self.reconstruir = True
            return muestra

        def borrar_cookie(self, cookie, switches, version):
            for sw in sorted(set(switches)):
                dp = self.dps.get(sw)
                if dp is None:
                    raise NoVerificable('NO_SE_PUEDE_LIMPIAR_SWITCH_DESCONECTADO')
                p, o = dp.ofproto_parser, dp.ofproto
                self.enviar(dp, p.OFPFlowMod(dp, cookie=cookie, cookie_mask=0xFFFFFFFFFFFFFFFF,
                                            table_id=0, command=o.OFPFC_DELETE, out_port=o.OFPP_ANY,
                                            out_group=o.OFPG_ANY, match=p.OFPMatch()), version)

        def limpiar(self, version):
            self.comprobar(version)
            protegidas = {c.cookie for c in self.vigentes.values()} | {COOKIE_PREFIX}
            antiguas = {cookie for cookie in self.registro if cookie not in protegidas}
            antiguas.update(f.cookie for _, f in self.legado if f.cookie not in protegidas)
            if not antiguas:
                return
            a = self.estadisticas(version)
            for (_, prioridad, _), dato in a['flows'].items():
                if prioridad == 400 and dato['cookie'] in antiguas:
                    antiguas.discard(dato['cookie'])
            if not antiguas:
                return
            self.esperar(max(self.intervalo, 4 * max(self.latencias)), version)
            b = self.estadisticas(version)
            for clave, dato in b['flows'].items():
                if dato['cookie'] in antiguas:
                    previo = a['flows'].get(clave)
                    if previo is None or previo['cookie'] != dato['cookie'] or previo['paquetes'] != dato['paquetes']:
                        raise NoVerificable('DRENAJE_ANTERIOR_PENDIENTE')
            retiradas = sum(1 for dato in b['flows'].values() if dato['cookie'] in antiguas)
            switches = set(self.dps)
            for cookie in antiguas:
                self.borrar_cookie(cookie, switches, version)
            self.barreras(switches, version)
            verificacion = self.estadisticas(version)
            if any(d['cookie'] in antiguas for d in verificacion['flows'].values()):
                raise NoVerificable('RETIRADA_DE_REGLAS_NO_VERIFICADA')
            activos = {(g.switch, g.identificador) for c in self.vigentes.values() for g in c.grupos}
            activos.update((clave[0], accion[1]) for clave, dato in verificacion['flows'].items()
                           for accion in dato['actions'] if accion[0] == 'group')
            eliminados = []
            for sw, identificador in verificacion['descs']:
                if identificador & 0xFFFF0000 != GROUP_PREFIX or (sw, identificador) in activos:
                    continue
                dp = self.dps.get(sw)
                if dp is None:
                    continue
                p, o = dp.ofproto_parser, dp.ofproto
                self.enviar(dp, p.OFPGroupMod(dp, o.OFPGC_DELETE, o.OFPGT_FF, identificador, []), version)
                eliminados.append((sw, identificador))
            self.barreras(switches, version)
            final = self.estadisticas(version)
            if any(k in final['descs'] for k in eliminados):
                raise NoVerificable('RETIRADA_DE_GRUPOS_NO_VERIFICADA')
            for sw, identificador in eliminados:
                self.grupos_usados[sw].discard(identificador)
            for cookie in antiguas:
                c = self.registro.pop(cookie, None)
                if c is not None:
                    self.etiquetas.difference_update(c.etiquetas - self.etiquetas_externas)
                    for g in c.grupos:
                        if (g.switch, g.identificador) not in final['descs']:
                            self.grupos_usados[g.switch].discard(g.identificador)
                self.cookies_usadas.discard(cookie)
            usadas_activas = {tag for c in self.vigentes.values() for tag in c.etiquetas}
            for sw, flujo in self.legado:
                if flujo.cookie not in antiguas:
                    continue
                tag = dict(flujo.match.items()).get('vlan_vid', 0)
                if isinstance(tag, int) and tag & 0x1000 and tag & 0xFFF not in usadas_activas | self.etiquetas_externas:
                    self.etiquetas.discard(tag & 0xFFF)
            self.legado = [(sw, flujo) for sw, flujo in self.legado if flujo.cookie not in antiguas]
            self.legado_grupos.clear()
            self.ultima_limpieza = dict(reglas=retiradas, grupos=len(eliminados), versiones=len(antiguas))
            self.emitir('LIMPIEZA', f'{retiradas} reglas de {len(antiguas)} versiones anteriores y {len(eliminados)} '
                        f'grupos FF retirados | inactividad de contadores verificada')

        def linea(self, texto=''):
            print('  ' + texto, flush=True)

        def clave_comunicacion(self, c):
            return (int(ipaddress.IPv4Address(c.origen.ip)), int(ipaddress.IPv4Address(c.destino.ip)))

        def par(self, c):
            return f'{c.origen.nombre} -> {c.destino.nombre}'

        def texto_fisico(self, e):
            return f'{self.nombre_sw(e[0])}:{e[1]} <-> {self.nombre_sw(e[2])}:{e[3]}'

        def texto_tramo(self, e):
            return f'{self.nombre_sw(e[0])}-{self.nombre_sw(e[2])}'

        def mostrar_topologia(self, version):
            if self.topologia_mostrada == version:
                return
            self.topologia_mostrada = version
            fisicos = sorted({fisico(e) for e in self.conocidos})
            hosts = sorted(self.hosts.values(), key=lambda h: int(ipaddress.IPv4Address(h.ip)))
            self.emitir('TOPOLOGIA_DESCUBIERTA', f'{len(self.dps)} switches | {len(fisicos)} enlaces | {len(hosts)} hosts')
            self.linea('SWITCHES: ' + ' '.join(self.nombre_sw(s) for s in sorted(self.dps)) +
                       ' | todos con soporte Fast Failover')
            self.linea('ENLACES:')
            for e in fisicos:
                ida, vuelta = self.capacidades.get((e[0], e[1])), self.capacidades.get((e[2], e[3]))
                if ida is None or vuelta is None:
                    capacidad = 'capacidad no verificada'
                elif cercano(ida, vuelta):
                    capacidad = f'{ida:g} Mbps'
                else:
                    capacidad = f'{ida:g} / {vuelta:g} Mbps'
                estado = 'disponible' if e in self.enlaces else 'CAIDO'
                self.linea(f'  {self.texto_fisico(e)} | {capacidad} | {estado}')
            self.linea('HOSTS:')
            for h in hosts:
                self.linea(f'  {h.nombre} | {h.ip} | {h.mac} | {self.nombre_sw(h.switch)}:{h.puerto}')

        def mostrar_configuracion(self, evento_rutas, evento_proteccion, comunicaciones=None):
            comunicaciones = self.vigentes if comunicaciones is None else comunicaciones
            orden = sorted(comunicaciones.values(), key=self.clave_comunicacion)
            self.emitir(evento_rutas, f'{len(orden)} comunicaciones | criterio: ' +
                        ('menor numero de saltos' if evento_rutas == 'RUTAS_PRINCIPALES' else 'Target FORT'))
            for c in orden:
                salidas = [f'{self.nombre_sw(e[0])}:{e[1]}' for e in c.ruta]
                salidas.append(f'{self.nombre_sw(c.destino.switch)}:{c.destino.puerto}')
                saltos = f'{len(c.ruta)} salto troncal' if len(c.ruta) == 1 else f'{len(c.ruta)} saltos troncales'
                self.linea(f'{self.par(c)} | {self.texto_ruta(c, c.ruta)} | salidas: {", ".join(salidas)} | {saltos}')
            sin_respaldo = sum(1 for c in orden for e in c.ruta if e not in c.respaldos)
            self.emitir(evento_proteccion, f'{sum(len(c.grupos) for c in orden)} grupos FF | '
                        f'{sin_respaldo} saltos sin respaldo')
            for c in orden:
                self.linea(f'{self.par(c)} | PRINCIPAL: {self.texto_ruta(c, c.ruta)} | VLAN principal {c.etiqueta}')
                for i, e in enumerate(c.ruta):
                    self.linea(f'  Salto {self.texto_tramo(e)} ({self.texto_enlace(e)})')
                    respaldo = c.respaldos.get(e)
                    if respaldo is None:
                        self.linea('    SIN RESPALDO: no existe un desvio simple que evite los switches ya recorridos')
                        continue
                    alternativa, g = respaldo
                    sw = self.nombre_sw(g.switch)
                    self.linea(f'    grupo G{g.identificador & 0xFFFF} ({g.identificador}) en {sw}')
                    self.linea(f'    bucket 0 PRINCIPAL | vigila {sw}:{g.principal} | salida {sw}:{g.principal}')
                    self.linea(f'    bucket 1 RESPALDO  | vigila {sw}:{g.respaldo} | marca VLAN {g.etiqueta} | '
                               f'salida {sw}:{g.respaldo}')
                    self.linea(f'    si cae {self.texto_tramo(e)}: {self.texto_ruta(c, c.ruta[:i] + list(alternativa))}')

        def evaluar_estabilidad(self, medicion):
            calidad = medicion['calidad']
            relevantes = [f for f in medicion['FS']
                          if f['tx'] >= max(self.parametros_solver['demanda_minima'], 0.01 * medicion['carga'])]
            variacion_flujo = max((calidad['variacion_flujos'].get(f['id'], 0.0) for f in relevantes), default=0.0)
            # Un enlace saturado descarta paquetes por congestion; esa perdida es justamente lo que
            # FORT debe corregir, por lo que no se exige entrega minima a las comunicaciones que lo cruzan.
            saturados = {r['enlace'] for r in medicion['RS'] if r['utilizacion_max'] >= self.umbral_saturacion}
            congestionadas = [f for f in relevantes if saturados.intersection(f['ruta'])]
            entregas = [f['entrega'] for f in relevantes if f['entrega'] is not None and f not in congestionadas]
            entrega_minima = min(entregas, default=100.0)
            motivos = []
            if calidad['ventanas'] > 1 and calidad['variacion_total'] > self.variacion_maxima:
                motivos.append(f"carga total varia {calidad['variacion_total']:.2f} % (maximo {self.variacion_maxima:g} %)")
            if calidad['ventanas'] > 1 and variacion_flujo > self.variacion_maxima:
                motivos.append(f'una comunicacion varia {variacion_flujo:.2f} % (maximo {self.variacion_maxima:g} %)')
            if entrega_minima < self.entrega_minima:
                motivos.append(f'entrega minima {entrega_minima:.2f} % (minimo {self.entrega_minima:g} %)')
            return dict(estable=not motivos, variacion_total=calidad['variacion_total'],
                        variacion_flujo=variacion_flujo, entrega_minima=entrega_minima, motivos=motivos,
                        intento=self.intentos_estabilidad + 1, forzada=False,
                        saturados=sorted(saturados), congestionadas=[f['id'] for f in congestionadas])

        def mostrar_fallo(self, captura, estabilidad, inicial):
            afectadas = [f for f in captura['FS'] if f['respaldo'] is not None]
            caidos = ', '.join(self.texto_fisico(e) for e in captura['TS']['caidos']) or 'ninguno'
            self.emitir('FALLO_DETECTADO', f'{caidos} | {len(afectadas)} comunicaciones afectadas | '
                        f'conmutacion local por buckets de respaldo')
            for f in afectadas:
                c, r = self.vigentes[f['id']], f['respaldo']
                trafico = f"+{r['incremento']} paquetes en el bucket" if f['paquetes'] > 0 else 'sin trafico'
                self.linea(f"{self.par(c)} | grupo G{r['grupo'] & 0xFFFF} en {self.nombre_sw(r['switch'])} -> "
                           f"bucket 1 activo | {trafico}")
                self.linea(f"  INICIAL: {inicial.get(f['id'], 'NO_DISPONIBLE')}")
                self.linea(f"  FF:      {captura['texto_rutas'][f['id']]}")
            estado = 'ALCANZADA' if estabilidad['estable'] else (
                f"NO ALCANZADA tras {estabilidad['intento']} intentos; se continua con la demanda maxima")
            self.emitir('ESTABILIZACION', f"{captura['calidad']['ventanas']} ventanas en {captura['ventana']:.2f} s | "
                        f"variacion de carga total {estabilidad['variacion_total']:.2f} % | "
                        f"variacion maxima por comunicacion {estabilidad['variacion_flujo']:.2f} % | "
                        f"entrega minima {estabilidad['entrega_minima']:.2f} % | {estado}")
            for motivo in estabilidad['motivos']:
                self.linea('  ' + motivo)
            if estabilidad['saturados']:
                self.linea('  SATURACION | ' + ', '.join(self.texto_enlace(e) for e in estabilidad['saturados']) +
                           f" con utilizacion de al menos {self.umbral_saturacion:g} % | " +
                           ', '.join(self.par(self.vigentes[k]) for k in estabilidad['congestionadas']) +
                           ' con perdidas por congestion, excluidas de la entrega minima')

        def mostrar_estado(self, evento, medicion):
            critico = max(medicion['RS'], key=lambda r: r['utilizacion'], default=None)
            enlace = self.texto_enlace(critico['enlace']) if critico else 'SIN_TRONCALES'
            self.emitir(evento, f"carga total {medicion['carga']:.2f} Mbps | MLU {medicion['mlu']:.2f} % en {enlace}")
            self.linea('FS | flujos (medias por ventana; demanda de diseno = maximo por ventana)')
            for f in sorted(medicion['FS'], key=lambda f: self.clave_comunicacion(self.vigentes[f['id']])):
                c = self.vigentes[f['id']]
                entrega = f"{f['entrega']:.2f} %" if f['entrega'] is not None else 'sin trafico'
                if f['respaldo'] is not None:
                    uso = f"respaldo G{f['respaldo']['grupo'] & 0xFFFF}/{self.nombre_sw(f['respaldo']['switch'])}"
                else:
                    uso = 'ruta principal'
                self.linea(f"  {self.par(c)} | {medicion['texto_rutas'][f['id']]} | ingreso {f['tx']:.2f} | "
                           f"egreso {f['rx']:.2f} Mbps | entrega {entrega} | demanda de diseno {f['demanda']:.2f} Mbps | {uso}")
            self.linea('RS | enlaces (de mayor a menor utilizacion)')
            for r in sorted(medicion['RS'], key=lambda r: (-r['utilizacion'], r['enlace'])):
                self.linea(f"  {self.texto_enlace(r['enlace'])} | {r['mbps']:.2f} / {r['capacidad']:g} Mbps | "
                           f"{r['utilizacion']:.2f} % (maximo por ventana {r['utilizacion_max']:.2f} %)")
            ps, libres = medicion['PS'], medicion['modelo']['recursos']
            self.linea(f"PS | {ps['grupos']} grupos FF y {ps['reglas']} reglas verificados | "
                       f"{ps['sin_respaldo']} saltos sin respaldo en la proteccion vigente")
            self.linea('  reglas ocupadas / libres: ' + ', '.join(
                f"{self.nombre_sw(sw)} {n}/{libres['reglas'][str(sw)]}" for sw, n in ps['reglas_ocupadas'].items()))
            self.linea('  grupos FF ocupados / libres: ' + ', '.join(
                f"{self.nombre_sw(sw)} {n}/{libres['grupos'][str(sw)]}" for sw, n in ps['grupos_ff'].items()) +
                f" | etiquetas VLAN libres {libres['etiquetas']}")
            ts = medicion['TS']
            capacidades = set(ts['capacidades'].values())
            texto_cap = (f'{capacidades.pop():g} Mbps en todas las direcciones' if len(capacidades) == 1 else
                         ', '.join(f'{self.texto_enlace(e)} {v:g}' for e, v in ts['capacidades'].items()))
            self.linea(f"TS | {len(ts['disponibles'])} enlaces disponibles | caidos: "
                       f"{', '.join(self.texto_tramo(e) for e in ts['caidos']) or 'ninguno'} | {texto_cap}")
            calidad = medicion['calidad']
            self.linea(f"CALIDAD | {calidad['ventanas']} ventanas | carga por ventana: " +
                       ', '.join(f'{x:.2f}' for x in calidad['totales']) +
                       f" Mbps | variacion {calidad['variacion_total']:.2f} % | MLU por ventana: " +
                       ', '.join(f'{x:.2f}' for x in calidad['mlu_ventanas']) + ' %')

        def mostrar_targets(self, resultado, captura):
            r = resultado
            texto = f"referencia FF con la demanda capturada {r['referencia']:.2f} %"
            if 'z_opt' in r:
                texto += (f" | optimo del modelo {r['z_opt']:.2f} % | tolerancia {r['tolerancia']:.2f} pp | "
                          f"mejora minima exigida {r['mejora_minima']:.2f} pp")
            texto += f" | calculo {r.get('tiempo_calculo_s', 0.0):.2f} s"
            self.emitir('TARGETS', texto)
            if 'candidatos' in r:
                cand = r['candidatos']
                activas = len(cand['por_comunicacion']) - cand['fijas']
                self.linea(f"CANDIDATOS | modo {cand['modo']} | {cand['caminos']} caminos | {activas} comunicaciones "
                           f"con trafico | {cand['fijas']} sin trafico, fijas en su ruta actual")
                extra = (f" | optimo sin exigencia de proteccion {r['z_libre']:.2f} %"
                         if r.get('modo_proteccion') == 'estricta' else '')
                self.linea(f"PROTECCION | modo {r.get('modo_proteccion')} | referencia: rutas FF reprotegidas "
                           f"con {r['proteccion_ref']} saltos sin respaldo{extra}")
            for t in r.get('targets', []):
                pico = f"{t['pico']:.2f} %" if 'pico' in t else '-'
                motivo = f": {t['motivo']}" if t['motivo'] else ''
                self.linea(f"{t['id']} | {t['origen']} | MLU {t['mlu']:.2f} % | cambia {len(t['cambios'])} | "
                           f"{t['sin_respaldo']} saltos sin respaldo | {t['reglas']} reglas | {t['grupos']} grupos | "
                           f"pico de transicion {pico} | {t['estado']}{motivo}")
            if r['estado'] != 'TARGET_SELECCIONADO':
                return
            self.linea('SELECCION | menos saltos sin respaldo, menos cambios, menor pico de transicion, '
                       'menor MLU, menos reglas')
            elegido = next(t for t in r['targets'] if t['id'] == r['elegido'])
            self.emitir('TARGET_ELEGIDO', f"{elegido['id']} | MLU {elegido['mlu']:.2f} % | "
                        f"{len(elegido['cambios'])} comunicaciones cambian | "
                        f"{elegido['sin_respaldo']} saltos sin respaldo")
            arcos = captura['arcos']
            vigentes = {f['id']: f['ruta'] for f in captura['modelo']['flujos']}
            for clave in sorted(r['rutas'], key=lambda k: self.clave_comunicacion(self.vigentes[k])):
                c = self.vigentes[clave]
                cambia = list(r['rutas'][clave]) != list(vigentes[clave])
                nueva = self.texto_ruta(c, [arcos[i] for i in r['rutas'][clave]]) if cambia else 'igual'
                self.linea(f"{self.par(c)} | FF: {captura['texto_rutas'][clave]} | TARGET: {nueva}" +
                           (' | CAMBIA' if cambia else ''))
            modelo = captura['modelo']
            antes = utilizaciones(modelo, calcular_cargas(modelo, vigentes))
            despues = utilizaciones(modelo, r['cargas'])
            self.linea('UTILIZACION CON LA DEMANDA CAPTURADA | FF | TARGET')
            for i in sorted(range(len(arcos)), key=lambda i: (-antes[i], -despues[i], arcos[i])):
                self.linea(f'  {self.texto_enlace(arcos[i])} | {antes[i]:.2f} % | {despues[i]:.2f} %')

        def mostrar_plan(self, resultado, captura, nuevas):
            plan = resultado['transition']
            instalar_r = sum(len(c.reglas) + len(c.ingresos) for c in nuevas.values())
            instalar_g = sum(len(c.grupos) for c in nuevas.values())
            retirar_r = sum(len(c.reglas) + len(c.ingresos) for c in self.vigentes.values())
            retirar_g = sum(len(c.grupos) for c in self.vigentes.values())
            self.emitir('TRANSITION_PLAN', f"{len(plan['orden'])} cambios de ruta | pico de estados intermedios "
                        f"{plan['pico']:.2f} % (estado inicial {plan['inicial']:.2f} %) | {instalar_r} reglas y "
                        f"{instalar_g} grupos FF a instalar | {retirar_r} reglas y {retirar_g} grupos a retirar")
            arcos = captura['arcos']
            for n, (clave, mlu) in enumerate(zip(plan['orden'], plan['intermedios']), 1):
                c = self.vigentes[clave]
                nueva = self.texto_ruta(c, [arcos[i] for i in resultado['rutas'][clave]])
                self.linea(f"{n}. {self.par(c)} | {captura['texto_rutas'][clave]} => {nueva} | "
                           f"MLU tras el paso {mlu:.2f} %")
            resto = len(nuevas) - len(plan['orden'])
            if resto:
                self.linea(f'Ademas, {resto} comunicaciones conservan su ruta y reciben proteccion FF recalculada')

        def evaluar(self, captura, medicion, rutas_ff, rutas_fort, instalado):
            """Compara FF y FORT con la misma carga: la medida en esta ventana."""
            arcos = medicion['arcos']
            indices = {e: i for i, e in enumerate(arcos)}
            modelo = modelo_con_demanda(medicion['modelo'], 'demanda_media')
            # El fondo (trafico no atribuido) se toma de la captura y no de esta misma ventana:
            # si se calculara aqui absorberia el error del modelo y la precision siempre daria 0.
            en_captura = {e: i for i, e in enumerate(captura['arcos'])}
            modelo['fondo'] = [captura['modelo']['fondo'][en_captura[e]] if e in en_captura else 0.0
                               for e in arcos]
            ids = [f['id'] for f in modelo['flujos']]
            try:
                ff = {k: [indices[tuple(e)] for e in rutas_ff[k]] for k in ids}
                fort = {k: [indices[tuple(e)] for e in rutas_fort[k]] for k in ids}
            except KeyError:
                return None
            u_ff = utilizaciones(modelo, calcular_cargas(modelo, ff))
            u_fort = utilizaciones(modelo, calcular_cargas(modelo, fort))
            u_obs = [r['utilizacion'] for r in medicion['RS']]
            prediccion = u_fort if instalado else u_ff
            enlaces = [dict(enlace=self.texto_enlace(e), ff=a, fort=b, observada=o, diferencia=o - p,
                            saturado=o >= self.umbral_saturacion)
                       for e, a, b, o, p in zip(arcos, u_ff, u_fort, u_obs, prediccion)]
            validos = [x for x in enlaces if not x['saturado']]
            errores = [x['diferencia'] for x in validos]
            mlu_ff, mlu_fort, mlu_obs = max(u_ff, default=0.0), max(u_fort, default=0.0), max(u_obs, default=0.0)
            referencia, resultado = (mlu_ff, mlu_obs) if instalado else (mlu_obs, mlu_fort)
            carga, carga_captura = medicion['carga'], captura['carga']
            umbral = max(self.parametros_solver['demanda_minima'], 0.01 * carga)
            entregas = {self.par(self.vigentes[f['id']]): f['entrega'] for f in medicion['FS']
                        if f['entrega'] is not None and f['tx'] >= umbral}
            return dict(instalado=instalado, carga=carga, carga_captura=carga_captura,
                        variacion=100 * (carga - carga_captura) / carga_captura if carga_captura > 0 else 0.0,
                        mlu_ff=mlu_ff, mlu_fort=mlu_fort, mlu_observada=mlu_obs,
                        error_maximo=max((abs(x) for x in errores), default=0.0),
                        error_medio=(sum(errores) / len(errores) if errores else 0.0),
                        saturados=[x['enlace'] for x in enlaces if x['saturado']],
                        reduccion_pp=referencia - resultado,
                        reduccion_pct=100 * (referencia - resultado) / referencia if referencia > 0 else 0.0,
                        enlaces=enlaces, entregas=entregas, entrega_minima=min(entregas.values(), default=None))

        def mostrar_evaluacion(self, ev, numero, completa=True):
            if ev is None:
                self.emitir('EVALUACION', 'No evaluable: las rutas registradas ya no existen en la topologia actual')
                return
            observada = 'FORT observada' if ev['instalado'] else 'FF observada'
            if not completa:
                self.emitir('EVALUACION_CONTINUA', f"ventana {numero}/{self.evaluaciones_maximas} | carga "
                            f"{ev['carga']:.2f} Mbps ({ev['variacion']:+.2f} %) | FF calculada {ev['mlu_ff']:.2f} % | "
                            f"FORT calculada {ev['mlu_fort']:.2f} % | {observada} {ev['mlu_observada']:.2f} % | "
                            f"reduccion {ev['reduccion_pp']:.2f} pp | precision {ev['error_maximo']:.2f} pp")
                return
            self.emitir('EVALUACION', f"carga actual {ev['carga']:.2f} Mbps ({ev['variacion']:+.2f} % respecto de la "
                        f"captura de {ev['carga_captura']:.2f} Mbps) | FF y FORT evaluados con esta misma carga")
            self.linea(f'ENLACE | FF calculada | FORT calculada | {observada} | diferencia observada - calculada')
            for x in sorted(ev['enlaces'], key=lambda x: (-max(x['ff'], x['fort'], x['observada']), x['enlace'])):
                self.linea(f"  {x['enlace']} | {x['ff']:.2f} % | {x['fort']:.2f} % | {x['observada']:.2f} % | "
                           f"{x['diferencia']:+.2f} pp" + (' | SATURADO' if x['saturado'] else ''))
            self.linea(f"MLU con la carga actual | FF calculada {ev['mlu_ff']:.2f} % | FORT calculada "
                       f"{ev['mlu_fort']:.2f} % | {observada} {ev['mlu_observada']:.2f} %")
            self.linea(f"Precision del modelo | diferencia maxima por enlace {ev['error_maximo']:.2f} pp | "
                       f"diferencia media {ev['error_medio']:+.2f} pp")
            if ev['saturados']:
                self.linea(f"Enlaces saturados excluidos de la precision (la utilizacion observada esta limitada "
                           f"por la capacidad): {', '.join(ev['saturados'])}")
            if ev['instalado']:
                self.linea(f"Reduccion respecto de FF con la misma carga | {ev['reduccion_pp']:.2f} pp "
                           f"({ev['reduccion_pct']:.2f} %)")
            else:
                self.linea(f"Reduccion que habria logrado FORT con la misma carga | {ev['reduccion_pp']:.2f} pp "
                           f"({ev['reduccion_pct']:.2f} %)")
            if ev['entregas']:
                self.linea(f"Entrega por comunicacion | minima {ev['entrega_minima']:.2f} % | " +
                           ', '.join(f'{k} {v:.2f} %' for k, v in ev['entregas'].items()))

        def mostrar_tiempos(self):
            t = self.tiempos
            if 'fallo' not in t:
                return
            partes = []
            if 'captura_inicio' in t:
                partes.append(f"deteccion a inicio de captura {t['captura_inicio'] - t['fallo']:.2f} s")
            if 'captura_fin' in t:
                partes.append(f"captura {t['captura_fin'] - t['captura_inicio']:.2f} s")
            if 'calculo' in t:
                partes.append(f"calculo {t['calculo']:.2f} s")
            if 'preparacion_fin' in t and 'captura_fin' in t:
                partes.append(f"preparacion y preflight {t['preparacion_fin'] - t['captura_fin'] - t.get('calculo', 0.0):.2f} s")
            if 'transicion_fin' in t:
                partes.append(f"transicion {t['transicion_fin'] - t['transicion_inicio']:.2f} s")
                partes.append(f"total desde la deteccion {t['transicion_fin'] - t['fallo']:.2f} s")
            self.emitir('TIEMPOS', ' | '.join(partes))

        def mostrar_recursos(self, captura, muestra):
            antes = captura['PS']['reglas_ocupadas']
            grupos = defaultdict(int)
            for (s, _), d in muestra['descs'].items():
                if d[0] == ofproto_v1_3.OFPGT_FF:
                    grupos[s] += 1
            despues_sin, _ = self.saltos_sin_respaldo_instalados()
            self.emitir('RECURSOS', 'reglas ocupadas antes -> despues: ' + ', '.join(
                f"{self.nombre_sw(sw)} {antes.get(sw, 0)}->{muestra['ocupacion'][sw]}" for sw in sorted(self.dps)) +
                f" | grupos FF {sum(captura['PS']['grupos_ff'].values())} -> {sum(grupos.values())}" +
                f" | saltos sin respaldo {captura['PS']['sin_respaldo']} -> {despues_sin}")
            return dict(reglas_antes=antes, reglas_despues=dict(muestra['ocupacion']),
                        grupos_antes=sum(captura['PS']['grupos_ff'].values()), grupos_despues=sum(grupos.values()),
                        sin_respaldo_antes=captura['PS']['sin_respaldo'], sin_respaldo_despues=despues_sin)

        def resumen_medicion(self, m):
            if m is None:
                return None
            return dict(carga=m['carga'], mlu=m['mlu'], ventana=m['ventana'], calidad=m['calidad'],
                        FS=[dict(f, ruta=m['texto_rutas'][f['id']],
                                 respaldo=(dict(f['respaldo'], enlace=self.texto_enlace(f['respaldo']['enlace']))
                                           if f['respaldo'] else None)) for f in m['FS']],
                        RS=[dict(r, enlace=self.texto_enlace(r['enlace'])) for r in m['RS']],
                        PS=m['PS'], TS=dict(disponibles=[self.texto_fisico(e) for e in m['TS']['disponibles']],
                                            caidos=[self.texto_fisico(e) for e in m['TS']['caidos']]),
                        arcos=[self.texto_enlace(e) for e in m['arcos']], modelo=m['modelo'])

        def nuevo_registro(self, captura, estabilidad, resultado):
            return dict(fort=VERSION, revision=REVISION, ciclo=self.ciclo, modo=self.modo,
                        escrito=time.strftime('%Y-%m-%d %H:%M:%S'),
                        parametros=dict(ventanas=self.ventanas, variacion_maxima=self.variacion_maxima,
                                        entrega_minima=self.entrega_minima, solver=self.parametros_solver),
                        hosts={h.ip: dict(nombre=h.nombre, mac=h.mac, switch=self.nombre_sw(h.switch),
                                          puerto=h.puerto) for h in self.hosts.values()},
                        captura=self.resumen_medicion(captura), estabilizacion=estabilidad,
                        resultado=resultado)

        def guardar_registro(self, registro):
            """Un unico archivo efimero por ciclo; se reemplaza de forma atomica."""
            if not self.registro_ruta:
                return
            registro['tiempos'] = {k: v - self.tiempos.get('fallo', v) if k != 'calculo' else v
                                   for k, v in self.tiempos.items()}
            temporal = self.registro_ruta + '.tmp'
            try:
                with open(temporal, 'w', encoding='utf-8') as archivo:
                    json.dump(a_json(registro), archivo, ensure_ascii=False, indent=1, allow_nan=False)
                os.replace(temporal, self.registro_ruta)
            except (OSError, ValueError) as error:
                self.avisar('REGISTRO_NO_ESCRITO', f'{type(error).__name__}: {error}')

        def iniciar_evaluacion_continua(self, captura, rutas_ff, rutas_fort, instalado, registro):
            if self.evaluaciones_maximas <= 0:
                return
            self.evaluacion = dict(captura=captura, rutas_ff=rutas_ff, rutas_fort=rutas_fort, instalado=instalado,
                                   resultados=[], registro=registro,
                                   proxima=time.monotonic() + self.intervalo_evaluacion)

        def evaluar_continua(self, version):
            e = self.evaluacion
            medicion = self.medir(version, self.ventanas)
            if self.evaluacion is not e:
                return
            ev = self.evaluar(e['captura'], medicion, e['rutas_ff'], e['rutas_fort'], e['instalado'])
            if ev is None:
                self.cerrar_evaluacion('EVALUACION_FINALIZADA', 'las rutas registradas ya no existen')
                return
            e['resultados'].append(ev)
            self.mostrar_evaluacion(ev, len(e['resultados']), completa=False)
            e['registro'].setdefault('evaluacion_continua', []).append(ev)
            self.guardar_registro(e['registro'])
            e['proxima'] = time.monotonic() + self.intervalo_evaluacion
            if len(e['resultados']) >= self.evaluaciones_maximas:
                self.cerrar_evaluacion('EVALUACION_RESUMEN', 'evaluacion continua completada')

        def cerrar_evaluacion(self, evento, motivo):
            e, self.evaluacion = self.evaluacion, None
            if e is None:
                return
            res = e['resultados']
            if not res:
                self.emitir(evento, motivo + ' | sin ventanas evaluadas')
                return
            reducciones = [r['reduccion_pp'] for r in res]
            resumen = dict(ventanas=len(res), reduccion_min=min(reducciones), reduccion_max=max(reducciones),
                           reduccion_media=sum(reducciones) / len(res),
                           error_maximo=max(r['error_maximo'] for r in res),
                           variacion_min=min(r['variacion'] for r in res),
                           variacion_max=max(r['variacion'] for r in res))
            self.emitir(evento, f"{motivo} | {resumen['ventanas']} ventanas | reduccion respecto de FF con la misma "
                        f"carga: minima {resumen['reduccion_min']:.2f}, media {resumen['reduccion_media']:.2f}, "
                        f"maxima {resumen['reduccion_max']:.2f} pp | precision del modelo: diferencia maxima "
                        f"{resumen['error_maximo']:.2f} pp | carga entre {resumen['variacion_min']:+.2f} y "
                        f"{resumen['variacion_max']:+.2f} % respecto de la captura")
            e['registro']['evaluacion_resumen'] = resumen
            self.guardar_registro(e['registro'])

        def finalizar_incidente(self, texto):
            self.analisis = None
            self.referencia_inicial.clear()
            self.incidente = False
            self.intentos_estabilidad = 0
            self.transaccion = None
            self.emitir('CICLO_FINALIZADO', texto)

        def construir_base(self, version):
            self.comprobar(version)
            self.refrescar_capacidades(version)
            self.mostrar_topologia(version)
            grafo = grafo_de(self.enlaces)
            disponibles = [h for h in self.hosts.values() if self.puerto_vivo(h.switch, h.puerto)]
            deseadas = {}
            inaccesibles = []
            self.emitir('FF_CALCULANDO', 'Rutas principales y respaldos sobre la topologia reconocida')
            for origen in sorted(disponibles, key=lambda h: h.ip):
                for destino in sorted(disponibles, key=lambda h: h.ip):
                    if origen.ip == destino.ip:
                        continue
                    ruta = camino(grafo, origen.switch, destino.switch)
                    clave = origen.ip + '>' + destino.ip
                    if ruta is None:
                        inaccesibles.append(clave)
                        continue
                    deseadas[clave] = self.compilar(origen, destino, ruta)
                self.comprobar(version)
                hub.sleep(0)
            nuevas = [c for k, c in deseadas.items() if self.vigentes.get(k) is not c]
            orden = [c.identificador for c in nuevas]
            if self.vigentes and nuevas and not inaccesibles and all(self.ruta_efectiva(c) is not None for c in self.vigentes.values()):
                medicion = self.medir(version)
                indices = {e: i for i, e in enumerate(medicion['arcos'])}
                finales = {f['id']: [indices[e] for e in deseadas[f['id']].ruta]
                           for f in medicion['modelo']['flujos'] if f['id'] in deseadas}
                if len(finales) == len(medicion['modelo']['flujos']):
                    respuesta = self.ejecutar_solver(dict(_operacion='transition', modelo=medicion['modelo'], rutas=finales), version)
                    if respuesta.get('estado') != 'TRANSITION':
                        raise NoVerificable('RECONSTRUCCION_FF_CALCULO_NO_CERTIFICADO')
                    plan = respuesta['plan']
                    if plan is None:
                        raise NoVerificable('RECONSTRUCCION_FF_SIN_TRANSITION_ADMISIBLE')
                    orden = plan['orden'] + [k for k in orden if k not in plan['orden']]
            if nuevas:
                self.preparar(nuevas, version)
            for clave in orden:
                if clave not in deseadas or self.vigentes.get(clave) is deseadas[clave]:
                    continue
                self.activar(deseadas[clave], version)
            for clave in set(self.vigentes) - set(deseadas):
                c = self.vigentes[clave]
                if c.origen.switch in self.dps:
                    self.borrar_cookie(c.cookie, [c.origen.switch], version)
                    self.barreras([c.origen.switch], version)
                self.vigentes.pop(clave, None)
            self.comprobar(version)
            self.vigentes = deseadas
            muestra = self.estadisticas(version)
            self.verificar(list(deseadas.values()), muestra, True)
            self.lista = True
            self.reconstruir = False
            self.version_lista_datos = None
            self.emitir('FF_INSTALADO', f'{len(self.dps)} switches | {len({fisico(e) for e in self.enlaces})} enlaces | '
                        f'{len(disponibles)} hosts | {len(deseadas)} comunicaciones verificadas')
            self.mostrar_configuracion('RUTAS_PRINCIPALES', 'PROTECCION_FF')
            if inaccesibles:
                self.emitir('PARTICION', 'Comunicaciones sin conectividad fisica: ' + ', '.join(inaccesibles))
            self.limpiar(version)

        def ejecutar_solver(self, modelo, version):
            """Ejecuta el optimizador en un subproceso; reintenta una vez si la respuesta no es valida."""
            try:
                return self.ejecutar_solver_una_vez(modelo, version)
            except RespuestaInvalida as error:
                self.avisar('CALCULO_REINTENTADO', str(error))
            try:
                return self.ejecutar_solver_una_vez(modelo, version)
            except RespuestaInvalida as error:
                raise NoVerificable(str(error))

        def ejecutar_solver_una_vez(self, modelo, version):
            entrada = json.dumps(modelo, allow_nan=False).encode()
            entorno = dict(os.environ)
            entorno['PYTHONUNBUFFERED'] = '1'
            proceso = subprocess.Popen([sys.executable, '-u', os.path.abspath(__file__), '--resolver'],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       env=entorno, close_fds=True)
            self.proceso = proceso
            salida, errores = bytearray(), bytearray()
            enviados = 0
            for flujo in (proceso.stdin, proceso.stdout, proceso.stderr):
                os.set_blocking(flujo.fileno(), False)
            comienzo = time.monotonic()
            try:
                while True:
                    self.comprobar(version)
                    if enviados < len(entrada):
                        try:
                            enviados += os.write(proceso.stdin.fileno(), entrada[enviados:enviados + 65536])
                        except BlockingIOError:
                            pass
                        except BrokenPipeError:
                            enviados = len(entrada)
                        if enviados == len(entrada):
                            proceso.stdin.close()
                    for flujo, destino in ((proceso.stdout, salida), (proceso.stderr, errores)):
                        while True:
                            try:
                                trozo = os.read(flujo.fileno(), 65536)
                            except BlockingIOError:
                                break
                            if not trozo:
                                break
                            destino.extend(trozo)
                            if destino is errores and len(errores) > 65536:
                                del errores[:-65536]
                    if proceso.poll() is not None:
                        break
                    hub.sleep(0.02)
                for flujo, destino in ((proceso.stdout, salida), (proceso.stderr, errores)):
                    while True:
                        try:
                            trozo = os.read(flujo.fileno(), 65536)
                        except BlockingIOError:
                            break
                        if not trozo:
                            break
                        destino.extend(trozo)
                self.comprobar(version)
                if proceso.returncode != 0:
                    raise NoVerificable('CALCULO_NO_CONCLUIDO: ' + errores.decode(errors='replace')[-2000:])
                texto = salida.decode(errors='replace')
                lineas = [l for l in texto.splitlines() if l.startswith('{')]
                try:
                    resultado = json.loads(lineas[-1])
                except (IndexError, json.JSONDecodeError):
                    raise RespuestaInvalida(
                        f'RESPUESTA_DEL_CALCULO_NO_VALIDA: codigo {proceso.returncode} | {len(salida)} bytes | '
                        f'inicio {texto[:120]!r} | error {errores.decode(errors="replace")[-300:]!r}')
                resultado['tiempo_calculo_s'] = time.monotonic() - comienzo
                return resultado
            finally:
                if proceso.poll() is None:
                    proceso.terminate()
                    fin = time.monotonic() + 1
                    while proceso.poll() is None and time.monotonic() < fin:
                        hub.sleep(0.02)
                    if proceso.poll() is None:
                        proceso.kill()
                    while proceso.poll() is None:
                        hub.sleep(0.02)
                for flujo in (proceso.stdin, proceso.stdout, proceso.stderr):
                    if not flujo.closed:
                        flujo.close()
                if self.proceso is proceso:
                    self.proceso = None

        def preflight(self, medicion, resultado, version):
            actual = self.medir(version)
            modelo_anterior = medicion['modelo']
            modelo = actual['modelo']
            if medicion['arcos'] != actual['arcos']:
                raise NoVerificable('PREFLIGHT_TOPOLOGIA_CAMBIADA')
            if [f['id'] for f in modelo_anterior['flujos']] != [f['id'] for f in modelo['flujos']]:
                raise NoVerificable('PREFLIGHT_COMUNICACIONES_CAMBIADAS')
            referencia = maximo_utilizacion(modelo, calcular_cargas(modelo, {f['id']: f['ruta'] for f in modelo['flujos']}))
            final = maximo_utilizacion(modelo, calcular_cargas(modelo, resultado['rutas']))
            if final >= referencia - EPS * max(1.0, referencia):
                raise NoVerificable('PREFLIGHT_DEMANDA_ACTUAL_ANULA_MEJORA')
            plan = resultado['transition']
            rutas = {f['id']: list(f['ruta']) for f in modelo['flujos']}
            inicial = calcular_cargas(modelo, rutas)
            cargas_finales = calcular_cargas(modelo, resultado['rutas'])
            techos = [max(e['capacidad'], a, b) for e, a, b in zip(modelo['enlaces'], inicial, cargas_finales)]
            for clave in plan['orden']:
                rutas[clave] = resultado['rutas'][clave]
                carga = calcular_cargas(modelo, rutas)
                if any(v > t + EPS * max(1.0, t) for v, t in zip(carga, techos)):
                    raise NoVerificable('PREFLIGHT_TRANSITION_NO_ADMISIBLE_CON_DEMANDA_ACTUAL')
            variacion = 100 * (actual['carga'] - medicion['carga']) / medicion['carga'] if medicion['carga'] > 0 else 0.0
            self.emitir('PREFLIGHT', f"carga {actual['carga']:.2f} Mbps ({variacion:+.2f} % respecto de la captura) | "
                        f"FF {referencia:.2f} % -> TARGET {final:.2f} % | transicion admisible")
            return dict(carga=actual['carga'], variacion=variacion, mlu_ff=referencia, mlu_target=final)

        def reoptimizar(self, version):
            self.comprobar(version)
            inicial = dict(self.referencia_inicial)
            self.tiempos['captura_inicio'] = time.monotonic()
            self.avisar('MEDICION_POST_FF', f'Capturando FS, RS, PS y TS en {self.ventanas} ventanas')
            captura = self.medir(version, self.ventanas)
            self.tiempos['captura_fin'] = time.monotonic()
            estabilidad = self.evaluar_estabilidad(captura)
            if not estabilidad['estable']:
                self.intentos_estabilidad += 1
                if self.intentos_estabilidad < self.intentos_maximos:
                    raise NoVerificable(f'ESTABILIZACION_PENDIENTE {self.intentos_estabilidad}/{self.intentos_maximos}: ' +
                                        '; '.join(estabilidad['motivos']))
                estabilidad['forzada'] = True
            self.analisis = captura
            self.mostrar_fallo(captura, estabilidad, inicial)
            self.mostrar_estado('ESTADO_POST_FF', captura)
            modelo = dict(captura['modelo'])
            parametros = dict(self.parametros_solver)
            mlus = captura['calidad']['mlu_ventanas']
            parametros['mejora_minima_pp'] = max(parametros['mejora_minima_pp'], max(mlus) - min(mlus))
            modelo['parametros'] = parametros
            self.emitir('OPTIMIZACION', 'Minimizar MLU con caminos candidatos; seleccionar Target por proteccion, '
                        'cambios, transicion y recursos')
            resultado = self.ejecutar_solver(modelo, version)
            self.comprobar(version)
            self.tiempos['calculo'] = resultado.get('tiempo_calculo_s', 0.0)
            registro = self.nuevo_registro(captura, estabilidad, resultado)
            if resultado['estado'] == 'CONSERVAR_FF':
                self.mostrar_targets(resultado, captura)
                self.emitir('CONSERVAR_FF', resultado['motivo'])
                self.guardar_registro(registro)
                self.finalizar_incidente('FF conservado | supervision activa')
                return
            if resultado['estado'] != 'TARGET_SELECCIONADO':
                self.emitir('SIN_INSTALACION', resultado.get('motivo', resultado['estado']))
                self.guardar_registro(registro)
                self.finalizar_incidente('Sin instalacion | supervision activa')
                return
            self.mostrar_targets(resultado, captura)
            arcos = captura['arcos']
            rutas_ff = {f['id']: list(f['ruta']) for f in captura['FS']}
            rutas_target = {k: [arcos[i] for i in idx] for k, idx in resultado['rutas'].items()}
            if self.modo == 'ff':
                self.emitir('MODO_LINEA_BASE', 'Target calculado y no instalado; FF se conserva para la comparacion')
                final = self.medir(version, self.ventanas)
                ev = self.evaluar(captura, final, rutas_ff, rutas_target, False)
                self.mostrar_evaluacion(ev, 0)
                self.mostrar_tiempos()
                registro.update(final=self.resumen_medicion(final), evaluacion=ev)
                self.guardar_registro(registro)
                self.iniciar_evaluacion_continua(captura, rutas_ff, rutas_target, False, registro)
                self.finalizar_incidente('Linea base registrada | evaluacion continua activa')
                return
            nuevas = {}
            for clave in resultado['rutas']:
                self.comprobar(version)
                c = self.vigentes[clave]
                nuevas[clave] = self.compilar(c.origen, c.destino, rutas_target[clave])
                hub.sleep(0)
            self.mostrar_plan(resultado, captura, nuevas)
            self.preparar(list(nuevas.values()), version)
            registro['preflight'] = self.preflight(captura, resultado, version)
            self.tiempos['preparacion_fin'] = time.monotonic()
            orden = resultado['transition']['orden'] + sorted(
                set(nuevas) - set(resultado['transition']['orden']),
                key=lambda k: self.clave_comunicacion(nuevas[k]))
            self.transaccion = dict(version=version, inicial=inicial, captura=captura, resultado=resultado,
                                    nuevas=nuevas, orden=orden, mostrado=False, registro=registro,
                                    rutas_ff=rutas_ff, rutas_target=rutas_target)
            self.completar_transaccion(version)

        def completar_transaccion(self, version):
            self.comprobar(version)
            t = self.transaccion
            if t is None or t['version'] != version:
                raise Cancelado()
            nuevas, captura = t['nuevas'], t['captura']
            cambios = set(t['resultado']['transition']['orden'])
            self.tiempos.setdefault('transicion_inicio', time.monotonic())
            for numero, clave in enumerate(t['orden'], 1):
                self.comprobar(version)
                c = nuevas[clave]
                if self.vigentes.get(clave) is c:
                    continue
                self.activar(c, version)
                tipo = 'ruta nueva' if clave in cambios else 'misma ruta, proteccion FF actualizada'
                self.emitir('TRANSITION', f'{numero}/{len(nuevas)} | {self.par(c)} | {self.texto_ruta(c, c.ruta)} | '
                            f'{tipo} | ingreso verificado')
            self.tiempos['transicion_fin'] = time.monotonic()
            self.avisar('INSTALACION_VERIFICADA', 'Midiendo la configuracion final con la carga actual')
            final = self.medir(version, self.ventanas)
            for f in final['FS']:
                if f['id'] in nuevas and f['paquetes'] > 0 and f['rx'] <= 0:
                    raise NoVerificable('EGRESO_POST_FORT_NO_CORROBORADO: ' + f['id'])
            if not t['mostrado']:
                self.mostrar_configuracion('RUTAS_FORT', 'PROTECCION_FF_FORT')
                t['mostrado'] = True
            self.limpiar(version)
            muestra = self.estadisticas(version)
            ev = self.evaluar(captura, final, t['rutas_ff'], t['rutas_target'], True)
            self.mostrar_evaluacion(ev, 0)
            self.mostrar_tiempos()
            recursos = self.mostrar_recursos(captura, muestra)
            registro = t['registro']
            registro.update(final=self.resumen_medicion(final), evaluacion=ev, recursos=recursos,
                            limpieza=self.ultima_limpieza)
            self.guardar_registro(registro)
            self.iniciar_evaluacion_continua(captura, t['rutas_ff'], t['rutas_target'], True, registro)
            self.finalizar_incidente('Target instalado y evaluado | ' + (
                'evaluacion continua activa' if self.evaluacion is not None else 'supervision activa'))

        def supervisar(self):
            while self.activo:
                version = self.version
                try:
                    if not self.dps or set(self.dps) != set(self.features):
                        hub.sleep(0.2)
                        continue
                    if time.monotonic() - self.ultimo_cambio < max(self.intervalo, 4 * max(self.latencias)):
                        hub.sleep(0.1)
                        continue
                    self.actualizar_enlaces()
                    if len(self.hosts) < 2:
                        self.avisar('ESPERANDO_HOSTS', 'Genere ARP/IPv4; en Mininet puede ejecutar pingall.')
                        hub.sleep(self.intervalo)
                        continue
                    self.reconciliar(version)
                    if self.transaccion is not None:
                        self.completar_transaccion(version)
                        continue
                    self.limpiar(version)
                    rotas = [c.identificador for c in self.vigentes.values() if self.ruta_efectiva(c) is None]
                    if self.reconstruir or not self.lista or not self.vigentes or rotas:
                        era_incidente = self.incidente
                        if rotas:
                            self.emitir('RECUPERACION_CONTROLADOR', 'FF no mantiene todas las comunicaciones; reconstruyendo rutas disponibles')
                        self.construir_base(version)
                        if not self.fallos:
                            self.incidente = False
                            self.referencia_inicial.clear()
                        elif era_incidente:
                            self.incidente = True
                    if self.incidente:
                        self.reoptimizar(version)
                    else:
                        self.preparar_medicion(version)
                        self.limpiar(version)
                        if self.evaluacion is not None and time.monotonic() >= self.evaluacion['proxima']:
                            self.evaluar_continua(version)
                        self.avisar('SUPERVISION', 'Observando enlaces, conexiones OpenFlow y reglas vigentes')
                        # Sin esta espera el bucle consultaba contadores sin pausa y saturaba los switches.
                        self.esperar(self.intervalo, version)
                except Cancelado:
                    self.analisis = None
                    hub.sleep(0)
                except NoVerificable as exc:
                    self.analisis = None
                    self.avisar('ESPERANDO_EVIDENCIA', str(exc))
                    hub.sleep(self.intervalo)
                except Exception as exc:
                    self.analisis = None
                    self.avisar('ERROR', f'{type(exc).__name__}: {exc}')
                    hub.sleep(self.intervalo)

        def close(self):
            self.activo = False
            self.analisis = None
            self.referencia_inicial.clear()
            if self.proceso is not None and self.proceso.poll() is None:
                self.proceso.terminate()
            return super().close()


def main():
    if importlib.util.find_spec('os_ken') is None:
        raise SystemExit('Faltan dependencias: os-ken, scipy y numpy en este interprete Python')
    argumentos = argparse.ArgumentParser(prog='FORT-V1.0')
    argumentos.add_argument('--direccion', default=os.environ.get('FORT_DIRECCION', '127.0.0.1'))
    argumentos.add_argument('--puerto', type=int, default=int(os.environ.get('FORT_PUERTO', '6653')))
    opciones = argumentos.parse_args()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as prueba:
        prueba.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            prueba.bind((opciones.direccion, opciones.puerto))
        except OSError as exc:
            raise SystemExit(f'Puerto del controlador no disponible: {exc}')
    cfg.CONF(args=[], project='fort-v1')
    cfg.CONF.set_override('ofp_listen_host', opciones.direccion)
    cfg.CONF.set_override('ofp_tcp_listen_port', opciones.puerto)
    cfg.CONF.set_override('observe_links', True)
    ofproto_protocol.set_app_supported_versions([ofproto_v1_3.OFP_VERSION])
    print(f'{VERSION} | revision {REVISION} | OpenFlow 1.3 | {opciones.direccion}:{opciones.puerto}', flush=True)
    registro = registro_configurado()
    if registro:
        for ruta in (registro, registro + '.tmp'):
            if os.path.exists(ruta):
                os.remove(ruta)
                print(f'Registro anterior eliminado: {ruta}', flush=True)
    app_manager.AppManager.run_apps(['os_ken.controller.ofp_handler', 'os_ken.topology.switches', '__main__'])


if __name__ == '__main__':
    main()
