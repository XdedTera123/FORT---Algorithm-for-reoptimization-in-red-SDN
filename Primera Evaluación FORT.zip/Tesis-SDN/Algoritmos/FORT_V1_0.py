import argparse
import copy
import heapq
import ipaddress
import itertools
import json
import math
import os
import socket
import subprocess
import sys
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field

VERSION = 'FORT-V1.0'
REVISION = 'medicion-02'
COOKIE_PREFIX = 0x464F000000000000
COOKIE_MASK = 0xFFFF000000000000
GROUP_PREFIX = 0x464F0000
EPS = 1e-8


class Cancelado(Exception):
    pass


class NoVerificable(Exception):
    pass


def cercano(a, b):
    return abs(a - b) <= EPS * max(1.0, abs(a), abs(b))


def camino(grafo, origen, destino, excluir=frozenset(), prohibidos=frozenset()):
    if origen == destino:
        return []
    cola = deque([origen])
    previo = {origen: None}
    while cola:
        nodo = cola.popleft()
        for e in sorted(grafo.get(nodo, [])):
            if e in excluir or e[2] in prohibidos or e[2] in previo:
                continue
            previo[e[2]] = e
            if e[2] == destino:
                ruta = []
                actual = destino
                while actual != origen:
                    enlace = previo[actual]
                    ruta.append(enlace)
                    actual = enlace[0]
                return list(reversed(ruta))
            cola.append(e[2])
    return None


def inverso(e):
    return e[2], e[3], e[0], e[1]


def fisico(e):
    return min(tuple(e), inverso(e))


def grafo_de(enlaces):
    grafo = defaultdict(list)
    for e in enlaces:
        grafo[e[0]].append(tuple(e))
    return grafo


def validar_ruta(ruta, origen, destino, disponibles):
    if ruta is None:
        return False
    actual = origen
    visitados = {actual}
    for e in ruta:
        e = tuple(e)
        if e not in disponibles or e[0] != actual or e[2] in visitados:
            return False
        actual = e[2]
        visitados.add(actual)
    return actual == destino


def calcular_cargas(modelo, rutas):
    cargas = list(modelo['fondo'])
    for f in modelo['flujos']:
        for e in rutas[f['id']]:
            cargas[e] += f['demanda']
    return cargas


def utilizaciones(modelo, cargas):
    return [100.0 * v / e['capacidad'] for v, e in zip(cargas, modelo['enlaces'])]


def maximo_utilizacion(modelo, cargas):
    return max(utilizaciones(modelo, cargas), default=0.0)


def recursos_target(modelo, rutas):
    limite = modelo.get('recursos')
    if limite is None:
        return True
    arcos = [(e['u'], e['puerto'], e['v'], e['remoto']) for e in modelo['enlaces']]
    grafo = grafo_de(arcos)
    grupos, reglas = defaultdict(int), defaultdict(int)
    etiquetas = 0
    for f in modelo['flujos']:
        ruta = [arcos[j] for j in rutas[f['id']]]
        etiquetas += 1
        for e in ruta[1:]:
            reglas[e[0]] += 2
        if ruta:
            reglas[f['destino']] += 2
        prefijo = set()
        for e in ruta:
            respaldo = camino(grafo, e[0], f['destino'], frozenset((e, inverso(e))), frozenset(prefijo))
            if respaldo:
                etiquetas += 1
                grupos[e[0]] += 1
                for salto in respaldo[1:]:
                    reglas[salto[0]] += 2
                reglas[f['destino']] += 2
            prefijo.add(e[0])
    return (etiquetas <= limite['etiquetas'] and
            all(n <= limite['grupos'].get(str(sw), 0) for sw, n in grupos.items()) and
            all(n <= limite['reglas'].get(str(sw), 0) for sw, n in reglas.items()))


def planificar_transition(modelo, nuevas):
    anteriores = {f['id']: f['ruta'] for f in modelo['flujos']}
    cambios = [f for f in modelo['flujos'] if f['ruta'] != nuevas[f['id']]]
    inicial = calcular_cargas(modelo, anteriores)
    final = calcular_cargas(modelo, nuevas)
    techo = [max(e['capacidad'], a, b) for e, a, b in zip(modelo['enlaces'], inicial, final)]
    mlu0 = maximo_utilizacion(modelo, inicial)
    if not cambios:
        return dict(orden=[], pico=mlu0, estados=1, intermedios=[], certificado=True)
    diferencias = []
    for f in cambios:
        delta = defaultdict(float)
        for e in f['ruta']:
            delta[e] -= f['demanda']
        for e in nuevas[f['id']]:
            delta[e] += f['demanda']
        diferencias.append(dict(delta))
    objetivo = (1 << len(cambios)) - 1
    frontera = [(mlu0, (), 0)]
    mejores = {0: (mlu0, ())}
    evaluados = 0
    while frontera:
        pico, orden, mascara = heapq.heappop(frontera)
        if mejores.get(mascara) != (pico, orden):
            continue
        evaluados += 1
        cargas = inicial.copy()
        for i, delta in enumerate(diferencias):
            if mascara & (1 << i):
                for e, d in delta.items():
                    cargas[e] += d
        if mascara == objetivo:
            intermedios = []
            actual = inicial.copy()
            for i in orden:
                for e, d in diferencias[i].items():
                    actual[e] += d
                intermedios.append(maximo_utilizacion(modelo, actual))
            return dict(orden=[cambios[i]['id'] for i in orden], pico=pico,
                        estados=evaluados, intermedios=intermedios, certificado=True)
        for i, delta in enumerate(diferencias):
            bit = 1 << i
            if mascara & bit:
                continue
            siguiente = cargas.copy()
            for e, d in delta.items():
                siguiente[e] += d
            if any(x > t + EPS * max(1.0, t) for x, t in zip(siguiente, techo)):
                continue
            valor = max(pico, maximo_utilizacion(modelo, siguiente))
            candidato = (valor, orden + (i,))
            estado = mascara | bit
            if estado not in mejores or candidato < mejores[estado]:
                mejores[estado] = candidato
                heapq.heappush(frontera, (valor, candidato[1], estado))
    return None


def resolver_modelo(modelo):
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import coo_matrix
    nodos = list(modelo['nodos'])
    enlaces = modelo['enlaces']
    if any(not math.isfinite(e['capacidad']) or e['capacidad'] <= 0 for e in enlaces):
        raise ValueError('CAPACIDAD_NO_VALIDA')
    if len(modelo['fondo']) != len(enlaces):
        raise ValueError('FONDO_INCONSISTENTE')
    if any(not math.isfinite(x) or x < 0 for x in modelo['fondo']):
        raise ValueError('FONDO_NO_VALIDO')
    for f in modelo['flujos']:
        if not math.isfinite(f['demanda']) or f['demanda'] < 0:
            raise ValueError('DEMANDA_NO_VALIDA')
    base = {f['id']: list(f['ruta']) for f in modelo['flujos']}
    carga_base = calcular_cargas(modelo, base)
    referencia = maximo_utilizacion(modelo, carga_base)
    activos = [f for f in modelo['flujos'] if f['origen'] != f['destino']]
    if not any(f['demanda'] > 0 for f in activos) or not enlaces:
        return dict(estado='CONSERVAR_FF', motivo='SIN_DEMANDA_REENRUTABLE', mlu=referencia)
    indice_nodo = {n: i for i, n in enumerate(nodos)}
    salidas = defaultdict(list)
    entradas = defaultdict(list)
    for j, e in enumerate(enlaces):
        salidas[e['u']].append(j)
        entradas[e['v']].append(j)
    ne, nn, nf = len(enlaces), len(nodos), len(activos)
    cantidad_x = ne * nf
    indice_z = cantidad_x + nn * nf
    cantidad = indice_z + 1
    bajos = np.zeros(cantidad)
    altos = np.ones(cantidad)
    altos[cantidad_x:indice_z] = nn - 1
    altos[indice_z] = np.inf
    enteros = np.zeros(cantidad, dtype=np.uint8)
    enteros[:cantidad_x] = 1
    objetivo = np.zeros(cantidad)
    objetivo[indice_z] = 1
    filas, columnas, valores, limites_b, limites_a = [], [], [], [], []

    def agregar(coefs, lo=-np.inf, hi=np.inf):
        fila = len(limites_b)
        for col, val in coefs.items():
            if val:
                filas.append(fila)
                columnas.append(col)
                valores.append(val)
        limites_b.append(lo)
        limites_a.append(hi)

    for i, f in enumerate(activos):
        if f['origen'] not in indice_nodo or f['destino'] not in indice_nodo:
            return dict(estado='INFACTIBLE', motivo='HOST_FUERA_DE_LA_TOPOLOGIA')
        offset = i * ne
        orden_offset = cantidad_x + i * nn
        altos[orden_offset + indice_nodo[f['origen']]] = 0
        for n in nodos:
            balance = 1 if n == f['origen'] else -1 if n == f['destino'] else 0
            coefs = {offset + e: 1.0 for e in salidas[n]}
            for e in entradas[n]:
                coefs[offset + e] = coefs.get(offset + e, 0.0) - 1.0
            agregar(coefs, balance, balance)
            agregar({offset + e: 1.0 for e in salidas[n]}, hi=1)
            agregar({offset + e: 1.0 for e in entradas[n]}, hi=1)
            if n == f['origen']:
                for e in entradas[n]:
                    altos[offset + e] = 0
            if n == f['destino']:
                for e in salidas[n]:
                    altos[offset + e] = 0
        for j, e in enumerate(enlaces):
            agregar({offset + j: nn,
                     orden_offset + indice_nodo[e['u']]: 1,
                     orden_offset + indice_nodo[e['v']]: -1}, hi=nn - 1)
    for j, e in enumerate(enlaces):
        coefs = {i * ne + j: f['demanda'] for i, f in enumerate(activos)}
        coefs[indice_z] = -e['capacidad']
        agregar(coefs, hi=-modelo['fondo'][j])
    mejor = None
    evaluados = 0
    rechazados = 0
    limite_optimo = None
    while True:
        matriz = coo_matrix((valores, (filas, columnas)), shape=(len(limites_b), cantidad)).tocsc()
        res = milp(objetivo, integrality=enteros, bounds=Bounds(bajos, altos),
                   constraints=LinearConstraint(matriz, limites_b, limites_a),
                   options={'mip_rel_gap': 0.0, 'presolve': True})
        if res.status == 2:
            if mejor is not None:
                mejor['certificado_desempate'] = True
                break
            return dict(estado='SIN_PAREJA_FACTIBLE', motivo='ESPACIO_AGOTADO', evaluados=evaluados)
        if res.status != 0 or res.x is None or getattr(res, 'mip_gap', 0.0) > EPS:
            return dict(estado='SIN_OPTIMO_CERTIFICADO', motivo=str(res.message))
        if not np.isfinite(res.x).all():
            raise ValueError('SOLUCION_NO_FINITA')
        if np.max(np.abs(res.x[:cantidad_x] - np.rint(res.x[:cantidad_x]))) > 1e-6:
            raise ValueError('SOLUCION_NO_ENTERA')
        elegido = np.rint(res.x[:cantidad_x]).astype(int)
        rutas = copy.deepcopy(base)
        for i, f in enumerate(activos):
            usados = {j for j in range(ne) if elegido[i * ne + j]}
            ruta = []
            actual = f['origen']
            visitados = {actual}
            while actual != f['destino']:
                opciones = [j for j in salidas[actual] if j in usados]
                if len(opciones) != 1:
                    raise ValueError('RUTA_NO_RECONSTRUIBLE')
                j = opciones[0]
                actual = enlaces[j]['v']
                if actual in visitados:
                    raise ValueError('CICLO_EN_SOLUCION')
                visitados.add(actual)
                usados.remove(j)
                ruta.append(j)
            if usados:
                raise ValueError('ENLACES_DESCONECTADOS_EN_SOLUCION')
            rutas[f['id']] = ruta
        cargas = calcular_cargas(modelo, rutas)
        mlu = maximo_utilizacion(modelo, cargas)
        if not cercano(mlu, 100 * float(res.fun)):
            raise ValueError('CERTIFICADO_INCONSISTENTE')
        if limite_optimo is not None and mlu > limite_optimo + EPS * max(1.0, limite_optimo):
            mejor['certificado_desempate'] = True
            break
        if mlu >= referencia - EPS * max(1.0, referencia):
            return dict(estado='CONSERVAR_FF', motivo='OPTIMO_NO_MEJORA_REFERENCIA',
                        mlu=mlu, certificado=True, evaluados=evaluados)
        evaluados += 1
        transicion = planificar_transition(modelo, rutas) if recursos_target(modelo, rutas) else None
        if transicion is not None:
            firma = tuple(tuple(rutas[k]) for k in sorted(rutas))
            if mejor is None or (transicion['pico'], firma) < (mejor['transition']['pico'], mejor['_firma']):
                limite_optimo = mlu
                mejor = dict(estado='OPTIMO', rutas=rutas, cargas=cargas, mlu=mlu,
                             referencia=referencia, transition=transicion, certificado=True,
                             certificado_desempate=False, _firma=firma,
                             cota=float(res.mip_dual_bound) * 100.0)
            limite_pico = max(referencia, mlu)
            if transicion['pico'] <= limite_pico + EPS * max(1.0, limite_pico):
                mejor['certificado_desempate'] = True
                break
        else:
            rechazados += 1
        agregar({j: 1.0 if elegido[j] else -1.0 for j in range(cantidad_x)},
                hi=int(elegido.sum()) - 1)
    mejor.pop('_firma', None)
    mejor['evaluados'] = evaluados
    mejor['sin_transition'] = rechazados
    return mejor


def resolver_subproceso():
    try:
        modelo = json.load(sys.stdin)
        if modelo.get('_operacion') == 'transition':
            respuesta = dict(estado='TRANSITION', plan=planificar_transition(modelo['modelo'], modelo['rutas']))
        else:
            respuesta = resolver_modelo(modelo)
    except BaseException as exc:
        respuesta = dict(estado='ERROR_CALCULO', motivo=f'{type(exc).__name__}: {exc}')
    print(json.dumps(respuesta, allow_nan=False), flush=True)


def tasa_tc(valor):
    if isinstance(valor, (int, float)):
        return float(valor) * 8.0 / 1e6
    if isinstance(valor, str):
        import re
        m = re.fullmatch(r'\s*([0-9.]+)\s*([kKmMgGtT]?)(bit|bps|Bps|b)?\s*', valor)
        if m:
            factor = {'': 1, 'k': 1e3, 'm': 1e6, 'g': 1e9, 't': 1e12}[m[2].lower()]
            return float(m[1]) * factor * (8 if m[3] in (None, 'Bps', 'b') else 1) / 1e6
    return None


def capacidad_local(nombre, velocidad):
    if not nombre or '/' in nombre or not os.path.exists('/sys/class/net/' + nombre):
        return (velocidad / 1000.0, 'OPENFLOW_CURR_SPEED') if velocidad > 0 else (None, 'DESCONOCIDA')
    try:
        salida = subprocess.check_output(
            ['tc', '-j', 'class', 'show', 'dev', nombre],
            stderr=subprocess.PIPE, timeout=3, text=True,
            env=dict(os.environ, LC_ALL='C')
        )
        try:
            clases = json.loads(salida)
        except json.JSONDecodeError:
            clases = []
            for linea in salida.splitlines():
                palabras = linea.split()
                if not palabras:
                    continue
                if len(palabras) < 4 or palabras[:2] != ['class', 'htb']:
                    raise ValueError('CLASE_TC_TEXTO_NO_INTERPRETABLE')
                clase = {'kind': 'htb', 'handle': palabras[2]}
                if palabras[3] == 'root':
                    clase['root'] = True
                elif palabras[3] == 'parent' and len(palabras) > 4:
                    clase['parent'] = palabras[4]
                else:
                    raise ValueError('JERARQUIA_TC_NO_INTERPRETABLE')
                for campo in ('rate', 'ceil'):
                    if campo not in palabras:
                        raise ValueError('TASA_HTB_INCOMPLETA')
                    posicion = palabras.index(campo) + 1
                    if posicion >= len(palabras):
                        raise ValueError('TASA_HTB_INCOMPLETA')
                    clase[campo] = palabras[posicion]
                clases.append(clase)
        if not isinstance(clases, list) or any(
            not isinstance(c, dict) or not isinstance(c.get('options', {}), dict)
            for c in clases
        ):
            raise ValueError('CLASES_TC_NO_INTERPRETABLES')
        raices = [c for c in clases if c.get('root') or c.get('parent') in (None, 'root')]
        if not raices and len(clases) == 1:
            raices = clases
        if raices:
            opciones = [dict(c, **c.get('options', {})) for c in raices]
            limites = [tasa_tc(c.get('ceil', c.get('rate'))) for c in opciones]
            if all(x is not None and x > 0 for x in limites):
                return sum(limites), 'TC_CLASSES'
        colas = json.loads(subprocess.check_output(['tc', '-j', 'qdisc', 'show', 'dev', nombre],
                                                   stderr=subprocess.PIPE, timeout=3))
        for c in colas:
            if c.get('root') and c.get('kind') in ('tbf', 'cake'):
                opciones = dict(c, **c.get('options', {}))
                limite = tasa_tc(opciones.get('rate', opciones.get('bandwidth')))
                if limite is not None and limite > 0:
                    return limite, 'TC_QDISC'
        if any(c.get('kind') in ('htb', 'hfsc', 'tbf', 'cake', 'netem') for c in colas):
            return None, 'TC_NO_INTERPRETABLE'
    except (OSError, subprocess.SubprocessError) as error:
        return None, f'TC_FORMATO_NO_INTERPRETABLE: {error}'
        detalle = getattr(error, 'stderr', None)
        if isinstance(detalle, bytes):
            detalle = detalle.decode('utf-8', errors='replace')
        mensaje = ' '.join(f'{error} {detalle or ""}'.split())
        return None, f'TC_ERROR_{type(error).__name__}: {mensaje}'
    if '/virtual/' in os.path.realpath('/sys/class/net/' + nombre):
        return None, 'INTERFAZ_VIRTUAL_SIN_CAPACIDAD_DECLARADA'
    return (velocidad / 1000.0, 'OPENFLOW_CURR_SPEED') if velocidad > 0 else (None, 'DESCONOCIDA')


@dataclass
class Host:
    ip: str
    mac: str
    switch: int
    puerto: int
    nombre: str


@dataclass
class Regla:
    switch: int
    cookie: int
    prioridad: int
    match: dict
    acciones: list


@dataclass
class Grupo:
    switch: int
    identificador: int
    principal: int
    respaldo: int
    etiqueta: int


@dataclass
class Comunicacion:
    identificador: str
    origen: Host
    destino: Host
    ruta: list
    cookie: int
    etiqueta: int
    grupos: list = field(default_factory=list)
    reglas: list = field(default_factory=list)
    ingresos: list = field(default_factory=list)
    respaldos: dict = field(default_factory=dict)
    etiquetas: set = field(default_factory=set)


if __name__ == '__main__' and '--resolver' in sys.argv:
    resolver_subproceso()
    sys.exit(0)


import importlib.util

if importlib.util.find_spec('os_ken') is not None:
    os.environ.setdefault('OSKEN_HUB_TYPE', 'eventlet')
    from os_ken import cfg
    from os_ken.base import app_manager
    from os_ken.controller import ofp_event
    from os_ken.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, DEAD_DISPATCHER, set_ev_cls
    from os_ken.lib import hub
    from os_ken.lib.packet import packet, ethernet, arp, ipv4, vlan
    from os_ken.ofproto import ofproto_v1_3, ofproto_protocol
    from os_ken.topology import event as topo_event
    from os_ken.topology.api import get_link
    from os_ken.topology import switches
    from eventlet import tpool

    class FORT(app_manager.OSKenApp):
        OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.dps = {}
            self.puertos = {}
            self.nombres = {}
            self.features = {}
            self.tablas = {}
            self.enlaces = set()
            self.conocidos = set()
            self.fallos = set()
            self.observados = {}
            self.hosts = {}
            self.capacidades = {}
            self.cap_fuentes = {}
            self.capacidad_cache = {}
            self.version_lista_datos = None
            self.pendientes = {}
            self.errores = deque(maxlen=32)
            self.numero_error = 0
            self.version = 0
            self.ciclo = 0
            self.ultimo_cambio = time.monotonic()
            self.latencias = deque([0.1], maxlen=32)
            self.intervalo = float(os.environ.get('FORT_INTERVALO', '2'))
            if not math.isfinite(self.intervalo) or self.intervalo <= 0:
                raise ValueError('FORT_INTERVALO debe ser positivo')
            self.vigentes = {}
            self.registro = {}
            self.etiquetas = set()
            self.etiquetas_externas = set()
            self.grupos_usados = defaultdict(set)
            self.cookies_usadas = set()
            self.secuencia = (uuid.uuid4().int & 0xFFFFFFFF) << 16
            self.legado = []
            self.legado_grupos = defaultdict(set)
            self.proceso = None
            self.activo = True
            self.lista = False
            self.reconstruir = True
            self.incidente = False
            self.referencia_inicial = {}
            self.analisis = None
            self.transaccion = None
            self.ultimo_mensaje = {}
            self.secuencia_hosts = 0
            self.capacidad_declarada = self.leer_capacidades()
            self.emitir('INICIO', 'OpenFlow 1.3 | descubrimiento dinamico | sin historial persistente')
            self.emitir('DESCUBRIMIENTO', 'Los hosts se reconocen mediante ARP/IPv4; pingall permite anunciarlos en Mininet.')
            self.threads.append(hub.spawn(self.supervisar))

        def leer_capacidades(self):
            ruta = os.environ.get('FORT_CAPACIDADES')
            if not ruta:
                return {}
            with open(ruta, encoding='utf-8') as archivo:
                datos = json.load(archivo)
            resultado = {}
            for nombre, valor in datos.items():
                numero = float(valor)
                if not math.isfinite(numero) or numero <= 0:
                    raise ValueError('CAPACIDAD_DECLARADA_NO_VALIDA: ' + nombre)
                resultado[str(nombre)] = numero
            return resultado

        def emitir(self, estado, mensaje):
            print(f'[{VERSION} v{self.version} c{self.ciclo}] {estado} | {mensaje}', flush=True)

        def avisar(self, clave, texto):
            firma = (self.version, texto)
            if self.ultimo_mensaje.get(clave) != firma:
                self.ultimo_mensaje[clave] = firma
                self.emitir(clave, texto)

        def nombre_sw(self, sw):
            return self.nombres.get(sw, f'DPID-{sw:x}')

        def texto_enlace(self, e):
            return f'{self.nombre_sw(e[0])}:{e[1]}->{self.nombre_sw(e[2])}:{e[3]}'

        def texto_ruta(self, comunicacion, ruta):
            if ruta is None:
                return 'SIN_CAMINO_OPERATIVO'
            partes = [comunicacion.origen.nombre, self.nombre_sw(comunicacion.origen.switch)]
            partes.extend(self.nombre_sw(e[2]) for e in ruta)
            partes.append(comunicacion.destino.nombre)
            return ' -> '.join(partes)

        def comprobar(self, version):
            if not self.activo or version != self.version:
                raise Cancelado()

        def esperar(self, segundos, version):
            fin = time.monotonic() + segundos
            while time.monotonic() < fin:
                self.comprobar(version)
                hub.sleep(min(0.1, max(0, fin - time.monotonic())))

        def cambiar(self, motivo, tipo='cambio', referencia=None):
            if self.lista or self.vigentes:
                self.referencia_inicial = referencia if referencia is not None else {
                    k: self.texto_ruta(c, self.ruta_efectiva(c)) for k, c in self.vigentes.items()}
            self.version += 1
            self.capacidad_cache.clear()
            self.cap_fuentes.clear()
            self.version_lista_datos = None
            self.ultimo_cambio = time.monotonic()
            self.analisis = None
            self.transaccion = None
            self.ultimo_mensaje.clear()
            if tipo == 'fallo' and self.vigentes:
                self.incidente = True
                self.reconstruir = False
            elif tipo in ('recuperacion', 'cambio'):
                self.reconstruir = True
            if self.proceso is not None and self.proceso.poll() is None:
                try:
                    self.proceso.terminate()
                except ProcessLookupError:
                    pass
            self.emitir('ESCENARIO_CAMBIADO', motivo + ' | analisis anterior descartado')

        def puerto_vivo(self, sw, puerto):
            p = self.puertos.get((sw, puerto))
            return sw in self.dps and p is not None and not (p.state & ofproto_v1_3.OFPPS_LINK_DOWN or p.config & ofproto_v1_3.OFPPC_PORT_DOWN)

        def enviar(self, dp, mensaje, version=None):
            if version is not None:
                self.comprobar(version)
            if self.dps.get(dp.id) is not dp:
                raise NoVerificable('CONEXION_OPENFLOW_REEMPLAZADA')
            dp.send_msg(mensaje)

        def iniciar_consulta(self, dp, mensaje, tipo, version=None):
            dp.set_xid(mensaje)
            clave = (id(dp), mensaje.xid)
            registro = dict(dp=dp, tipo=tipo, datos=[], inicio=time.monotonic(), fin=None, error=None)
            self.pendientes[clave] = registro
            try:
                self.enviar(dp, mensaje, version)
            except BaseException:
                self.pendientes.pop(clave, None)
                raise
            return clave, registro

        def terminar_consultas(self, consultas, version=None):
            limite = max(5.0, 8.0 * max(self.latencias))
            try:
                while any(r['fin'] is None and r['error'] is None for _, r in consultas):
                    if version is not None:
                        self.comprobar(version)
                    if any(time.monotonic() - r['inicio'] > limite for _, r in consultas if r['fin'] is None):
                        faltantes = ', '.join(
                            self.nombre_sw(r['dp'].id) + ':' + r['tipo']
                            for _, r in consultas if r['fin'] is None
                        )
                        raise NoVerificable(
                            'OPENFLOW_SIN_RESPUESTA_COMPLETA: ' + faltantes
                        )
                    if any(self.dps.get(r['dp'].id) is not r['dp'] for _, r in consultas):
                        raise NoVerificable('SWITCH_DESCONECTADO_DURANTE_CONSULTA')
                    hub.sleep(0.01)
                if any(r['error'] is not None for _, r in consultas):
                    raise NoVerificable('OPENFLOW_ERROR: ' + str([r['error'] for _, r in consultas if r['error']]))
                for _, r in consultas:
                    self.latencias.append(r['fin'] - r['inicio'])
                return [r for _, r in consultas]
            finally:
                for clave, _ in consultas:
                    self.pendientes.pop(clave, None)

        def consultar(self, dp, mensaje, tipo, version=None):
            return self.terminar_consultas([self.iniciar_consulta(dp, mensaje, tipo, version)], version)[0]

        @set_ev_cls([ofp_event.EventOFPPortDescStatsReply, ofp_event.EventOFPFlowStatsReply,
                     ofp_event.EventOFPGroupDescStatsReply, ofp_event.EventOFPGroupStatsReply,
                     ofp_event.EventOFPPortStatsReply, ofp_event.EventOFPGroupFeaturesStatsReply,
                     ofp_event.EventOFPTableFeaturesStatsReply,
                     ofp_event.EventOFPBarrierReply], [CONFIG_DISPATCHER, MAIN_DISPATCHER])
        def respuesta(self, ev):
            msg = ev.msg
            registro = self.pendientes.get((id(msg.datapath), msg.xid))
            if registro is None:
                return
            cuerpo = getattr(msg, 'body', [])
            registro['datos'].extend(cuerpo if isinstance(cuerpo, list) else [cuerpo])
            if not getattr(msg, 'flags', 0) & ofproto_v1_3.OFPMPF_REPLY_MORE:
                registro['fin'] = time.monotonic()

        @set_ev_cls(ofp_event.EventOFPErrorMsg, [CONFIG_DISPATCHER, MAIN_DISPATCHER])
        def error_openflow(self, ev):
            msg = ev.msg
            detalle = f'{self.nombre_sw(msg.datapath.id)} tipo={msg.type} codigo={msg.code} xid={msg.xid}'
            self.numero_error += 1
            self.errores.append(detalle)
            registro = self.pendientes.get((id(msg.datapath), msg.xid))
            if registro is not None:
                registro['error'] = detalle
            self.emitir('ERROR_OPENFLOW', detalle)

        @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
        def conectar(self, ev):
            dp = ev.msg.datapath
            anterior = self.dps.get(dp.id)
            self.dps[dp.id] = dp
            if anterior is not dp:
                self.features.pop(dp.id, None)
                self.tablas.pop(dp.id, None)
                self.puertos = {k: v for k, v in self.puertos.items() if k[0] != dp.id}
                self.grupos_usados[dp.id].clear()
                self.cambiar(f'DPID {dp.id:x} conectado')
                self.actualizar_enlaces()
            hub.spawn(self.preparar_switch, dp)

        @set_ev_cls(ofp_event.EventOFPStateChange, DEAD_DISPATCHER)
        def desconectar(self, ev):
            dp = ev.datapath
            if self.dps.get(dp.id) is not dp:
                return
            self.cambiar(self.nombre_sw(dp.id) + ' desconectado', 'fallo')
            self.dps.pop(dp.id, None)
            self.features.pop(dp.id, None)
            self.tablas.pop(dp.id, None)
            self.actualizar_enlaces()

        def preparar_switch(self, dp):
            try:
                p, o = dp.ofproto_parser, dp.ofproto
                consultas = [self.iniciar_consulta(dp, p.OFPPortDescStatsRequest(dp, 0), 'puertos'),
                             self.iniciar_consulta(dp, p.OFPGroupFeaturesStatsRequest(dp, 0), 'features'),
                             self.iniciar_consulta(dp, p.OFPTableFeaturesStatsRequest(dp, 0, []), 'tablas'),
                             self.iniciar_consulta(dp, p.OFPGroupDescStatsRequest(dp, 0), 'grupos'),
                             self.iniciar_consulta(dp, p.OFPFlowStatsRequest(dp, match=p.OFPMatch()), 'flujos')]
                respuestas = self.terminar_consultas(consultas)
                for r in respuestas:
                    if r['tipo'] == 'puertos':
                        for puerto in r['datos']:
                            self.puertos[dp.id, puerto.port_no] = puerto
                            if puerto.port_no == o.OFPP_LOCAL:
                                self.nombres[dp.id] = puerto.name.decode(errors='replace').rstrip('\x00')
                    elif r['tipo'] == 'features':
                        if not r['datos'] or not r['datos'][0].types & (1 << o.OFPGT_FF):
                            raise NoVerificable('SWITCH_SIN_FAST_FAILOVER')
                        self.features[dp.id] = r['datos'][0]
                    elif r['tipo'] == 'tablas':
                        tabla = next((t for t in r['datos'] if t.table_id == 0), None)
                        if tabla is None:
                            raise NoVerificable('CAPACIDAD_DE_TABLA_NO_DISPONIBLE')
                        self.tablas[dp.id] = int(tabla.max_entries)
                    elif r['tipo'] == 'grupos':
                        for grupo in r['datos']:
                            self.grupos_usados[dp.id].add(grupo.group_id)
                            if grupo.group_id & 0xFFFF0000 == GROUP_PREFIX:
                                self.legado_grupos[dp.id].add(grupo.group_id)
                    else:
                        for flujo in r['datos']:
                            campos = dict(flujo.match.items())
                            etiqueta = campos.get('vlan_vid', 0)
                            if isinstance(etiqueta, int) and etiqueta & 0x1000:
                                self.etiquetas.add(etiqueta & 0xFFF)
                                if flujo.cookie & COOKIE_MASK != COOKIE_PREFIX:
                                    self.etiquetas_externas.add(etiqueta & 0xFFF)
                            if flujo.cookie & COOKIE_MASK == COOKIE_PREFIX:
                                self.cookies_usadas.add(flujo.cookie)
                                self.legado.append((dp.id, flujo))
                                if campos.get('ipv4_src') and campos.get('eth_src') and campos.get('in_port'):
                                    self.aprender_host(campos['ipv4_src'], campos['eth_src'], dp.id, campos['in_port'])
                self.instalar_auxiliares(dp)
                self.emitir('SWITCH_RECONOCIDO', self.nombre_sw(dp.id) + ' | FF disponible')
            except Exception as exc:
                if self.dps.get(dp.id) is dp and self.activo:
                    self.features.pop(dp.id, None)
                    self.avisar('SWITCH_NO_PREPARADO_' + str(dp.id), f'{self.nombre_sw(dp.id)} | {exc}')
                    hub.spawn_after(self.intervalo, self.preparar_switch, dp)

        def instalar_auxiliares(self, dp):
            p, o = dp.ofproto_parser, dp.ofproto
            entradas = [(60000, dict(eth_type=0x88CC), [('controller',)]),
                        (100, dict(vlan_vid=(o.OFPVID_PRESENT, o.OFPVID_PRESENT)), []),
                        (10, dict(eth_type=0x0806), [('controller',)]),
                        (10, dict(eth_type=0x0800), [('controller',)])]
            for prioridad, campos, acciones in entradas:
                regla = Regla(dp.id, COOKIE_PREFIX, prioridad, campos, acciones)
                self.enviar_regla(regla, None)

        @set_ev_cls(ofp_event.EventOFPPortStatus, MAIN_DISPATCHER)
        def estado_puerto(self, ev):
            dp, puerto = ev.msg.datapath, ev.msg.desc
            anterior = self.puerto_vivo(dp.id, puerto.port_no)
            antes = set(self.enlaces)
            referencia = {k: self.texto_ruta(c, self.ruta_efectiva(c)) for k, c in self.vigentes.items()}
            if ev.msg.reason == dp.ofproto.OFPPR_DELETE:
                self.puertos.pop((dp.id, puerto.port_no), None)
            else:
                self.puertos[dp.id, puerto.port_no] = puerto
            actual = self.puerto_vivo(dp.id, puerto.port_no)
            if anterior == actual:
                return
            self.actualizar_enlaces()
            acceso = any((h.switch, h.puerto) == (dp.id, puerto.port_no) for h in self.hosts.values())
            if antes != self.enlaces or acceso:
                self.cambiar(f'{self.nombre_sw(dp.id)} puerto {puerto.port_no}: ' + ('ARRIBA' if actual else 'ABAJO'),
                             'recuperacion' if actual else 'fallo', referencia)

        @set_ev_cls(topo_event.EventLinkAdd)
        def nuevo_enlace(self, ev):
            l = ev.link
            e = (l.src.dpid, l.src.port_no, l.dst.dpid, l.dst.port_no)
            self.observados[e] = time.monotonic()
            if e not in self.conocidos:
                sustituidos = {x for x in self.conocidos if x != e and
                               ((x[0], x[1]) == (e[0], e[1]) or (x[2], x[3]) == (e[2], e[3]))}
                self.conocidos.difference_update(sustituidos | {inverso(x) for x in sustituidos})
                for x in sustituidos:
                    self.observados.pop(x, None)
                    self.observados.pop(inverso(x), None)
                self.conocidos.add(e)
                for ip, h in list(self.hosts.items()):
                    if (h.switch, h.puerto) in ((e[0], e[1]), (e[2], e[3])):
                        self.hosts.pop(ip, None)
                self.cambiar('Enlace descubierto: ' + self.texto_enlace(e))
            self.actualizar_enlaces()

        @set_ev_cls(topo_event.EventLinkDelete)
        def lldp_ausente(self, ev):
            self.actualizar_enlaces()

        def actualizar_enlaces(self):
            anteriores = set(self.enlaces)
            self.enlaces = {e for e in self.conocidos if inverso(e) in self.conocidos and
                            self.puerto_vivo(e[0], e[1]) and self.puerto_vivo(e[2], e[3])}
            self.fallos = {fisico(e) for e in self.conocidos if e not in self.enlaces}
            if anteriores != self.enlaces:
                self.ultimo_cambio = time.monotonic()

        def aprender_host(self, ip, mac, sw, puerto):
            try:
                direccion = ipaddress.IPv4Address(ip)
                if direccion.is_unspecified or direccion.is_multicast or int(direccion) == 0xFFFFFFFF:
                    return
            except ValueError:
                return
            if not self.puerto_vivo(sw, puerto):
                return
            if any((e[0], e[1]) == (sw, puerto) for e in self.conocidos):
                return
            actual = self.hosts.get(ip)
            if actual and (actual.mac, actual.switch, actual.puerto) == (mac, sw, puerto):
                return
            if actual:
                nombre = actual.nombre
            else:
                self.secuencia_hosts += 1
                nombre = f'H{self.secuencia_hosts}'
            self.hosts[ip] = Host(ip, mac, sw, puerto, nombre)
            self.cambiar(f'Host {ip} ({mac}) en {self.nombre_sw(sw)}:{puerto}')

        def arbol_puertos(self):
            grafo = grafo_de(self.enlaces)
            visitados = set()
            seleccion = set()
            for raiz in sorted(self.dps):
                if raiz in visitados:
                    continue
                visitados.add(raiz)
                cola = deque([raiz])
                while cola:
                    u = cola.popleft()
                    for e in sorted(grafo[u]):
                        if e[2] not in visitados:
                            visitados.add(e[2])
                            cola.append(e[2])
                            seleccion.add((e[0], e[1]))
                            seleccion.add((e[2], e[3]))
            return seleccion

        @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
        def paquete(self, ev):
            msg, dp = ev.msg, ev.msg.datapath
            if self.dps.get(dp.id) is not dp:
                return
            pkt = packet.Packet(msg.data)
            eth = pkt.get_protocol(ethernet.ethernet)
            if eth is None or eth.ethertype == 0x88CC or pkt.get_protocol(vlan.vlan) is not None:
                return
            ingreso = msg.match.get('in_port')
            a, v = pkt.get_protocol(arp.arp), pkt.get_protocol(ipv4.ipv4)
            if a is not None:
                origen, destino = a.src_ip, a.dst_ip
            elif v is not None:
                origen, destino = v.src, v.dst
            else:
                return
            self.aprender_host(origen, eth.src, dp.id, ingreso)
            objetivo = self.hosts.get(destino)
            salidas = []
            if objetivo and self.puerto_vivo(objetivo.switch, objetivo.puerto):
                ruta = camino(grafo_de(self.enlaces), dp.id, objetivo.switch)
                if ruta is not None:
                    salida = ruta[0][1] if ruta else objetivo.puerto
                    if salida != ingreso:
                        salidas = [salida]
            elif a is not None:
                arbol = self.arbol_puertos()
                troncales = {(e[0], e[1]) for e in self.conocidos}
                if (dp.id, ingreso) in troncales and (dp.id, ingreso) not in arbol:
                    return
                salidas = [puerto for sw, puerto in self.puertos if sw == dp.id and
                           0 < puerto < dp.ofproto.OFPP_MAX and puerto != ingreso and
                           self.puerto_vivo(sw, puerto) and ((sw, puerto) not in troncales or (sw, puerto) in arbol)]
            if salidas:
                p, o = dp.ofproto_parser, dp.ofproto
                acciones = [p.OFPActionOutput(n) for n in sorted(set(salidas))]
                self.enviar(dp, p.OFPPacketOut(dp, o.OFP_NO_BUFFER, ingreso, acciones, msg.data))

        def convertir_acciones(self, dp, acciones):
            p, o = dp.ofproto_parser, dp.ofproto
            resultado = []
            for a in acciones:
                if a[0] == 'output':
                    resultado.append(p.OFPActionOutput(a[1]))
                elif a[0] == 'group':
                    resultado.append(p.OFPActionGroup(a[1]))
                elif a[0] == 'push':
                    resultado.append(p.OFPActionPushVlan(0x8100))
                elif a[0] == 'set':
                    resultado.append(p.OFPActionSetField(vlan_vid=o.OFPVID_PRESENT | a[1]))
                elif a[0] == 'pop':
                    resultado.append(p.OFPActionPopVlan())
                elif a[0] == 'controller':
                    resultado.append(p.OFPActionOutput(o.OFPP_CONTROLLER, o.OFPCML_NO_BUFFER))
                else:
                    raise ValueError('ACCION_DESCONOCIDA')
            return resultado

        def enviar_regla(self, regla, version):
            dp = self.dps.get(regla.switch)
            if dp is None:
                raise NoVerificable('SWITCH_NO_DISPONIBLE')
            p, o = dp.ofproto_parser, dp.ofproto
            acciones = self.convertir_acciones(dp, regla.acciones)
            instrucciones = [p.OFPInstructionActions(o.OFPIT_APPLY_ACTIONS, acciones)]
            mensaje = p.OFPFlowMod(dp, cookie=regla.cookie, table_id=0, command=o.OFPFC_ADD,
                                  priority=regla.prioridad, match=p.OFPMatch(**regla.match),
                                  instructions=instrucciones, flags=o.OFPFF_RESET_COUNTS)
            self.enviar(dp, mensaje, version)

        def enviar_grupo(self, grupo, version):
            dp = self.dps.get(grupo.switch)
            if dp is None:
                raise NoVerificable('SWITCH_NO_DISPONIBLE')
            p, o = dp.ofproto_parser, dp.ofproto
            principal = p.OFPBucket(watch_port=grupo.principal, watch_group=o.OFPG_ANY,
                                    actions=self.convertir_acciones(dp, [('output', grupo.principal)]))
            respaldo = p.OFPBucket(watch_port=grupo.respaldo, watch_group=o.OFPG_ANY,
                                   actions=self.convertir_acciones(dp, [('set', grupo.etiqueta), ('output', grupo.respaldo)]))
            self.enviar(dp, p.OFPGroupMod(dp, o.OFPGC_ADD, o.OFPGT_FF, grupo.identificador,
                                         [principal, respaldo]), version)

        def barreras(self, switches, version):
            consultas = []
            for sw in sorted(set(switches)):
                dp = self.dps.get(sw)
                if dp is None:
                    raise NoVerificable('SWITCH_NO_DISPONIBLE_EN_BARRERA')
                consultas.append(self.iniciar_consulta(dp, dp.ofproto_parser.OFPBarrierRequest(dp), 'barrier', version))
            return self.terminar_consultas(consultas, version)

        def cookie_nueva(self):
            while True:
                self.secuencia = (self.secuencia + 1) & 0xFFFFFFFFFFFF
                cookie = COOKIE_PREFIX | self.secuencia
                if cookie not in self.cookies_usadas and cookie != COOKIE_PREFIX:
                    self.cookies_usadas.add(cookie)
                    return cookie

        def etiqueta_nueva(self):
            for etiqueta in range(1, 4095):
                if etiqueta not in self.etiquetas:
                    self.etiquetas.add(etiqueta)
                    return etiqueta
            raise NoVerificable('ESPACIO_DE_ETIQUETAS_AGOTADO')

        def grupo_nuevo(self, sw):
            for n in range(1, 65536):
                grupo = GROUP_PREFIX | n
                if grupo not in self.grupos_usados[sw]:
                    self.grupos_usados[sw].add(grupo)
                    return grupo
            raise NoVerificable('ESPACIO_DE_GRUPOS_AGOTADO')

        def campos(self, origen, destino, protocolo):
            if protocolo == 0x0800:
                return dict(eth_type=protocolo, ipv4_src=origen.ip, ipv4_dst=destino.ip)
            return dict(eth_type=protocolo, arp_spa=origen.ip, arp_tpa=destino.ip)

        def compilar(self, origen, destino, ruta):
            if not validar_ruta(ruta, origen.switch, destino.switch, self.enlaces):
                raise NoVerificable('RUTA_PROPUESTA_NO_VALIDA')
            identificador = origen.ip + '>' + destino.ip
            etiqueta = self.etiqueta_nueva()
            c = Comunicacion(identificador, copy.copy(origen), copy.copy(destino), list(ruta),
                             self.cookie_nueva(), etiqueta)
            c.etiquetas.add(etiqueta)
            self.registro[c.cookie] = c
            grafo = grafo_de(self.enlaces)
            acciones_principales = {}
            prefijo = set()
            for e in ruta:
                alternativa = camino(grafo, e[0], destino.switch,
                                     frozenset((e, inverso(e))), frozenset(prefijo))
                if alternativa:
                    tag = self.etiqueta_nueva()
                    c.etiquetas.add(tag)
                    grupo = Grupo(e[0], self.grupo_nuevo(e[0]), e[1], alternativa[0][1], tag)
                    c.grupos.append(grupo)
                    c.respaldos[e] = (alternativa, grupo)
                    acciones_principales[e[0]] = [('group', grupo.identificador)]
                    for protocolo in (0x0800, 0x0806):
                        for salto in alternativa[1:]:
                            campos = self.campos(origen, destino, protocolo)
                            campos['vlan_vid'] = 0x1000 | tag
                            c.reglas.append(Regla(salto[0], c.cookie, 300, campos, [('output', salto[1])]))
                        campos = self.campos(origen, destino, protocolo)
                        campos['vlan_vid'] = 0x1000 | tag
                        c.reglas.append(Regla(destino.switch, c.cookie, 300, campos,
                                               [('pop',), ('output', destino.puerto)]))
                else:
                    acciones_principales[e[0]] = [('output', e[1])]
                prefijo.add(e[0])
            for protocolo in (0x0800, 0x0806):
                for salto in ruta[1:]:
                    campos = self.campos(origen, destino, protocolo)
                    campos['vlan_vid'] = 0x1000 | etiqueta
                    c.reglas.append(Regla(salto[0], c.cookie, 300, campos, acciones_principales[salto[0]]))
                if ruta:
                    campos = self.campos(origen, destino, protocolo)
                    campos['vlan_vid'] = 0x1000 | etiqueta
                    c.reglas.append(Regla(destino.switch, c.cookie, 300, campos,
                                           [('pop',), ('output', destino.puerto)]))
                campos = self.campos(origen, destino, protocolo)
                campos.update(in_port=origen.puerto, eth_src=origen.mac, vlan_vid=0)
                acciones = [('push',), ('set', etiqueta)] + acciones_principales[origen.switch] if ruta else [('output', destino.puerto)]
                c.ingresos.append(Regla(origen.switch, c.cookie, 400, campos, acciones))
            return c

        def firma_acciones(self, acciones):
            resultado = []
            for a in acciones:
                nombre = type(a).__name__
                if nombre == 'OFPActionOutput':
                    resultado.append(('output', int(a.port)))
                elif nombre == 'OFPActionGroup':
                    resultado.append(('group', int(a.group_id)))
                elif nombre == 'OFPActionPushVlan':
                    resultado.append(('push', int(a.ethertype)))
                elif nombre == 'OFPActionPopVlan':
                    resultado.append(('pop',))
                elif nombre == 'OFPActionSetField' and a.key == 'vlan_vid':
                    resultado.append(('set', int(a.value)))
                else:
                    resultado.append(('unsupported', nombre))
            return tuple(resultado)

        def firma_esperada(self, sw, acciones):
            return self.firma_acciones(self.convertir_acciones(self.dps[sw], acciones))

        def firma_match(self, campos):
            return tuple(sorted((k, tuple(v) if isinstance(v, list) else v) for k, v in campos.items()))

        def estadisticas(self, version):
            self.comprobar(version)
            consultas = []
            for sw, dp in sorted(self.dps.items()):
                p, o = dp.ofproto_parser, dp.ofproto
                solicitudes = [
                    ('flows', p.OFPFlowStatsRequest(dp, table_id=0, out_port=o.OFPP_ANY,
                                                   out_group=o.OFPG_ANY, match=p.OFPMatch())),
                    ('ports', p.OFPPortStatsRequest(dp, 0, o.OFPP_ANY)),
                    ('groups', p.OFPGroupStatsRequest(dp, 0, o.OFPG_ALL)),
                    ('descs', p.OFPGroupDescStatsRequest(dp, 0))]
                for tipo, solicitud in solicitudes:
                    consultas.append(self.iniciar_consulta(dp, solicitud, tipo, version))
            respuestas = self.terminar_consultas(consultas, version)
            self.comprobar(version)
            datos = dict(version=version, time=time.monotonic(), flows={}, ports={}, groups={}, descs={}, ventanas={}, externas=[], ocupacion=defaultdict(int))
            for r in respuestas:
                sw, tipo = r['dp'].id, r['tipo']
                datos['ventanas'][sw, tipo] = ((r['inicio'] + r['fin']) / 2, r['fin'] - r['inicio'])
                for obj in r['datos']:
                    if tipo == 'flows':
                        datos['ocupacion'][sw] += 1
                        campos = dict(obj.match.items())
                        if obj.cookie & COOKIE_MASK != COOKIE_PREFIX:
                            datos['externas'].append((sw, obj.priority, campos))
                            continue
                        acciones = []
                        for instruccion in obj.instructions:
                            if instruccion.type != ofproto_v1_3.OFPIT_APPLY_ACTIONS:
                                raise NoVerificable('INSTRUCCION_AJENA_EN_REGLA_FORT')
                            acciones.extend(instruccion.actions)
                        clave = (sw, obj.priority, self.firma_match(campos))
                        datos[tipo][clave] = dict(cookie=obj.cookie, match=campos,
                                                 actions=self.firma_acciones(acciones),
                                                 bytes=int(obj.byte_count), paquetes=int(obj.packet_count),
                                                 duracion=obj.duration_sec + obj.duration_nsec / 1e9)
                    elif tipo == 'ports':
                        datos[tipo][sw, obj.port_no] = dict(tx=int(obj.tx_bytes), rx=int(obj.rx_bytes),
                                                          paquetes=int(obj.tx_packets),
                                                          drops=int(obj.tx_dropped), errores=int(obj.tx_errors),
                                                          duracion=obj.duration_sec + obj.duration_nsec / 1e9)
                    elif tipo == 'groups':
                        datos[tipo][sw, obj.group_id] = [(int(b.packet_count), int(b.byte_count)) for b in obj.bucket_stats]
                    else:
                        datos[tipo][sw, obj.group_id] = (obj.type, tuple(
                            (b.watch_port, b.watch_group, self.firma_acciones(b.actions)) for b in obj.buckets))
            return datos

        def verificar(self, comunicaciones, muestra, ingresos=False):
            for c in comunicaciones:
                for r in c.reglas + (c.ingresos if ingresos else []):
                    for sw, prioridad, campos in muestra.get('externas', []):
                        if sw != r.switch or prioridad < r.prioridad:
                            continue
                        separados = any(k in r.match and not isinstance(v, (tuple, list)) and
                                         not isinstance(r.match[k], (tuple, list)) and r.match[k] != v
                                         for k, v in campos.items())
                        if not separados:
                            raise NoVerificable('REGLA_EXTERNA_SUPERPUESTA: ' + self.nombre_sw(sw))
                    dato = muestra['flows'].get((r.switch, r.prioridad, self.firma_match(r.match)))
                    if dato is None or dato['cookie'] != c.cookie or dato['actions'] != self.firma_esperada(r.switch, r.acciones):
                        raise NoVerificable('REGLA_NO_VERIFICADA: ' + c.identificador)
                for g in c.grupos:
                    esperado = (ofproto_v1_3.OFPGT_FF, (
                        (g.principal, ofproto_v1_3.OFPG_ANY, self.firma_esperada(g.switch, [('output', g.principal)])),
                        (g.respaldo, ofproto_v1_3.OFPG_ANY, self.firma_esperada(g.switch, [('set', g.etiqueta), ('output', g.respaldo)]))))
                    if muestra['descs'].get((g.switch, g.identificador)) != esperado:
                        raise NoVerificable('GRUPO_FF_NO_VERIFICADO: ' + str(g.identificador))

        def ruta_efectiva(self, c):
            if not self.puerto_vivo(c.origen.switch, c.origen.puerto) or not self.puerto_vivo(c.destino.switch, c.destino.puerto):
                return None
            ruta = []
            for e in c.ruta:
                if self.puerto_vivo(e[0], e[1]):
                    if e not in self.enlaces:
                        return None
                    ruta.append(e)
                    continue
                alternativa = c.respaldos.get(e)
                if alternativa is None:
                    return None
                desvio, grupo = alternativa
                if not self.puerto_vivo(grupo.switch, grupo.respaldo) or any(x not in self.enlaces for x in desvio):
                    return None
                return ruta + list(desvio)
            return ruta

        def revisar_puertos(self, version):
            self.comprobar(version)
            anteriores = set(self.enlaces)
            accesos = {(h.switch, h.puerto) for h in self.hosts.values()}
            vivos_antes = {k for k in accesos if self.puerto_vivo(*k)}
            referencia = {
                k: self.texto_ruta(c, self.ruta_efectiva(c))
                for k, c in self.vigentes.items()
            }
            consultas = []
            try:
                for sw, dp in sorted(self.dps.items()):
                    solicitud = dp.ofproto_parser.OFPPortDescStatsRequest(dp, 0)
                    consultas.append(
                        self.iniciar_consulta(dp, solicitud, 'puertos', version)
                    )
                respuestas = self.terminar_consultas(consultas, version)
            finally:
                for clave, _ in consultas:
                    self.pendientes.pop(clave, None)

            self.comprobar(version)
            for respuesta in respuestas:
                sw = respuesta['dp'].id
                self.puertos = {
                    k: v for k, v in self.puertos.items() if k[0] != sw
                }
                for puerto in respuesta['datos']:
                    self.puertos[sw, puerto.port_no] = puerto

            self.actualizar_enlaces()
            vivos_despues = {k for k in accesos if self.puerto_vivo(*k)}
            if anteriores != self.enlaces or vivos_antes != vivos_despues:
                bajaron = bool(
                    anteriores - self.enlaces or vivos_antes - vivos_despues
                )
                self.cambiar(
                    'Cambio de puertos confirmado mediante OpenFlow',
                    'fallo' if bajaron else 'recuperacion',
                    referencia
                )
                raise Cancelado()

        def verificar_conectividad(self, version):
            self.revisar_puertos(version)
            observados = {
                (l.src.dpid, l.src.port_no, l.dst.dpid, l.dst.port_no)
                for l in get_link(self, None)
            }
            self.comprobar(version)
            pendientes = self.enlaces - observados
            if not pendientes:
                return

            self.avisar(
                'LLDP_REVALIDANDO',
                ', '.join(
                    self.texto_enlace(e) for e in sorted(pendientes)
                )
            )
            limite = max(5.0, 8.0 * max(self.latencias))
            ttl = max(1, min(65535, math.ceil(limite)))

            for e in sorted(pendientes):
                self.comprobar(version)
                dp = self.dps[e[0]]
                p, o = dp.ofproto_parser, dp.ofproto
                datos = switches.LLDPPacket.lldp_packet(
                    dp.id, e[1], self.puertos[e[0], e[1]].hw_addr, ttl
                )
                self.enviar(
                    dp,
                    p.OFPPacketOut(
                        dp,
                        o.OFP_NO_BUFFER,
                        o.OFPP_CONTROLLER,
                        [p.OFPActionOutput(e[1])],
                        datos
                    ),
                    version
                )

            fin = time.monotonic() + limite
            while True:
                self.comprobar(version)
                observados = {
                    (l.src.dpid, l.src.port_no, l.dst.dpid, l.dst.port_no)
                    for l in get_link(self, None)
                }
                self.comprobar(version)
                pendientes = self.enlaces - observados

                if not pendientes:
                    self.avisar(
                        'LLDP_REVALIDADO',
                        'Todas las direcciones operativas tienen observacion LLDP'
                    )
                    return

                if time.monotonic() >= fin:
                    detalle = ', '.join(
                        self.texto_enlace(e) for e in sorted(pendientes)
                    )
                    raise NoVerificable(
                        'CONECTIVIDAD_SIN_CONFIRMAR: ' + detalle
                    )
                hub.sleep(0.05)

        def preparar_medicion(self, version):
            if self.version_lista_datos == version:
                return

            self.avisar(
                'PREPARACION_DATOS',
                'Verificando conectividad, capacidades, reglas y contadores'
            )
            muestra = self.medir(version)
            self.comprobar(version)
            self.version_lista_datos = version
            self.ultimo_mensaje.pop('ESPERANDO_EVIDENCIA', None)

            self.emitir(
                'CAPACIDADES_VERIFICADAS',
                f"{len(muestra['RS'])} direcciones comprobadas"
            )
            for r in muestra['RS']:
                print(
                    f"  {self.texto_enlace(r['enlace'])}: "
                    f"{r['capacidad']:g} Mbps",
                    flush=True
                )
            self.emitir(
                'RED_LISTA',
                f"{len(self.dps)} switches | {len(self.hosts)} hosts | "
                f"{len(self.vigentes)} comunicaciones | captura inicial valida"
            )

        def refrescar_capacidades(self, version):
            extremos = {(e[0], e[1]) for e in self.enlaces}
            self.capacidad_cache = {
                k: v for k, v in self.capacidad_cache.items()
                if k in extremos
            }
            existentes, fuentes = {}, {}
            vigencia = max(self.intervalo, 4.0 * max(self.latencias))

            for sw, puerto in sorted(extremos):
                self.comprobar(version)
                descriptor = self.puertos[sw, puerto]
                nombre = descriptor.name.decode(errors='replace').rstrip('\x00')
                velocidad = int(descriptor.curr_speed)
                clave = (sw, puerto)
                firma = (nombre, velocidad)
                declarado = self.capacidad_declarada.get(
                    f'{sw}:{puerto}', self.capacidad_declarada.get(nombre)
                )
                cache = self.capacidad_cache.get(clave)

                if declarado is not None:
                    valor, fuente = declarado, 'DECLARADA_POR_INTERFAZ'
                elif (
                    cache and cache['firma'] == firma
                    and time.monotonic() - cache['instante'] <= vigencia
                ):
                    valor, fuente = cache['valor'], cache['fuente']
                else:
                    valor, fuente = tpool.execute(
                        capacidad_local, nombre, velocidad
                    )
                    self.comprobar(version)
                    if (
                        valor is not None
                        and math.isfinite(valor)
                        and valor > 0
                    ):
                        self.capacidad_cache[clave] = dict(
                            firma=firma,
                            valor=valor,
                            fuente=fuente,
                            instante=time.monotonic()
                        )
                    else:
                        self.capacidad_cache.pop(clave, None)

                self.comprobar(version)
                fuentes[clave] = fuente
                if valor is not None and math.isfinite(valor) and valor > 0:
                    existentes[clave] = valor

            self.capacidades = existentes
            self.cap_fuentes = fuentes
            faltantes = [
                self.texto_enlace(e) + ' ('
                + fuentes.get((e[0], e[1]), 'DESCONOCIDA') + ')'
                for e in sorted(self.enlaces)
                if (e[0], e[1]) not in existentes
            ]
            if faltantes:
                raise NoVerificable(
                    'CAPACIDADES_NO_VERIFICADAS: ' + ', '.join(faltantes)
                )

        def delta(self, anterior, actual, campo):
            a, b = anterior.get(campo), actual.get(campo)
            if a is None or b is None or min(a, b) < 0 or max(a, b) >= (1 << 64) - 1 or b < a:
                raise NoVerificable('CONTADOR_INCOMPLETO_O_REINICIADO')
            if actual.get('duracion', 0) + EPS < anterior.get('duracion', 0):
                raise NoVerificable('CONTADOR_REINICIADO')
            return b - a

        def intervalo_muestra(self, a, b, sw, tipo):
            ta, da = a['ventanas'][sw, tipo]
            tb, db = b['ventanas'][sw, tipo]
            dt = tb - ta
            if dt <= 0 or max(da, db) > dt / 2:
                raise NoVerificable('VENTANA_DE_MEDICION_INCOHERENTE')
            return dt

        def medir(self, version):
            self.comprobar(version)
            if set(self.dps) != set(self.features):
                raise NoVerificable('SWITCHES_PENDIENTES_DE_VERIFICACION')
            self.verificar_conectividad(version)
            self.refrescar_capacidades(version)
            rutas = {k: self.ruta_efectiva(c) for k, c in self.vigentes.items()}
            if any(r is None for r in rutas.values()):
                raise NoVerificable('COMUNICACION_SIN_RUTA_OPERATIVA')
            a = self.estadisticas(version)
            self.verificar(list(self.vigentes.values()), a, True)
            ventana = max(self.intervalo, 4.0 * max(self.latencias))
            self.esperar(ventana, version)
            b = self.estadisticas(version)
            self.verificar(list(self.vigentes.values()), b, True)
            if b['time'] - a['time'] > max(2 * ventana, ventana + 4 * max(self.latencias)):
                raise NoVerificable('PAUSA_DURANTE_LA_MEDICION')
            if rutas != {k: self.ruta_efectiva(c) for k, c in self.vigentes.items()}:
                raise NoVerificable('FORWARDING_CAMBIO_DURANTE_LA_MEDICION')
            enlaces = sorted(self.enlaces)
            indices = {e: i for i, e in enumerate(enlaces)}
            observadas, registros_rs = [], []
            for e in enlaces:
                clave = (e[0], e[1])
                if clave not in a['ports'] or clave not in b['ports']:
                    raise NoVerificable('CONTADOR_DE_PUERTO_AUSENTE')
                dt = self.intervalo_muestra(a, b, e[0], 'ports')
                mbps = 8 * self.delta(a['ports'][clave], b['ports'][clave], 'tx') / dt / 1e6
                capacidad = self.capacidades[clave]
                observadas.append(mbps)
                registros_rs.append(dict(enlace=e, capacidad=capacidad, mbps=mbps,
                                         utilizacion=100 * mbps / capacidad, intervalo=dt))
            flujos, fs = [], []
            for clave, c in sorted(self.vigentes.items()):
                ingreso = next(r for r in c.ingresos if r.match['eth_type'] == 0x0800)
                firma = (ingreso.switch, ingreso.prioridad, self.firma_match(ingreso.match))
                x, y = a['flows'].get(firma), b['flows'].get(firma)
                if x is None or y is None or x['cookie'] != y['cookie']:
                    raise NoVerificable('INGRESO_NO_MEDIBLE: ' + clave)
                dt = self.intervalo_muestra(a, b, ingreso.switch, 'flows')
                bytes_entrada = self.delta(x, y, 'bytes')
                paquetes = self.delta(x, y, 'paquetes')
                demanda = 8 * (bytes_entrada + (4 * paquetes if rutas[clave] else 0)) / dt / 1e6
                salida_mbps = 0.0
                if not rutas[clave]:
                    salida_mbps = 8 * bytes_entrada / dt / 1e6
                else:
                    for r in c.reglas:
                        if r.switch != c.destino.switch or r.match['eth_type'] != 0x0800 or ('output', c.destino.puerto) not in r.acciones:
                            continue
                        firma_rx = (r.switch, r.prioridad, self.firma_match(r.match))
                        rx1, rx2 = a['flows'].get(firma_rx), b['flows'].get(firma_rx)
                        if rx1 is None or rx2 is None:
                            raise NoVerificable('EGRESO_NO_MEDIBLE: ' + clave)
                        db = self.delta(rx1, rx2, 'bytes')
                        npk = self.delta(rx1, rx2, 'paquetes')
                        salida_mbps += 8 * max(0, db - 4 * npk) / self.intervalo_muestra(a, b, r.switch, 'flows') / 1e6
                respaldo_corroborado = False
                for e, (desvio, grupo) in c.respaldos.items():
                    if self.puerto_vivo(e[0], e[1]):
                        continue
                    antes = a['groups'].get((grupo.switch, grupo.identificador))
                    despues = b['groups'].get((grupo.switch, grupo.identificador))
                    if antes is None or despues is None or len(antes) != 2 or len(despues) != 2:
                        raise NoVerificable('CONTADORES_FF_NO_DISPONIBLES')
                    incremento = self.delta({'n': antes[1][0]}, {'n': despues[1][0]}, 'n')
                    respaldo_corroborado = incremento > 0
                    if paquetes > 0 and not respaldo_corroborado:
                        raise NoVerificable('ACTIVACION_FF_SIN_EVIDENCIA: ' + clave)
                    break
                fs.append(dict(id=clave, ruta=rutas[clave], demanda=demanda,
                               tx=8 * bytes_entrada / dt / 1e6, rx=salida_mbps,
                               paquetes=paquetes, respaldo_corroborado=respaldo_corroborado))
                flujos.append(dict(id=clave, origen=c.origen.switch, destino=c.destino.switch,
                                   demanda=demanda, ruta=[indices[e] for e in rutas[clave]]))
            conocidos = [0.0] * len(enlaces)
            for f in flujos:
                for i in f['ruta']:
                    conocidos[i] += f['demanda']
            fondo = [max(0.0, obs - conocido) for obs, conocido in zip(observadas, conocidos)]
            modelo = dict(nodos=sorted(self.dps), enlaces=[dict(u=e[0], v=e[2], puerto=e[1], remoto=e[3],
                            capacidad=self.capacidades[e[0], e[1]]) for e in enlaces],
                          flujos=flujos, fondo=fondo)
            modelo['recursos'] = dict(etiquetas=4094 - len(self.etiquetas),
                grupos={str(sw): max(0, self.features[sw].max_groups[ofproto_v1_3.OFPGT_FF] -
                        sum(1 for (s, _), d in b['descs'].items() if s == sw and d[0] == ofproto_v1_3.OFPGT_FF)) for sw in self.dps},
                reglas={str(sw): max(0, self.tablas.get(sw, 0) - b['ocupacion'][sw]) for sw in self.dps})
            mlu = max((r['utilizacion'] for r in registros_rs), default=0.0)
            return dict(version=version, instante=b['time'], ventana=b['time'] - a['time'],
                        modelo=modelo, arcos=enlaces, FS=fs, RS=registros_rs,
                        PS=dict(grupos=sum(len(c.grupos) for c in self.vigentes.values()),
                                reglas=sum(len(c.reglas) + len(c.ingresos) for c in self.vigentes.values()),
                                verificado=True), mlu=mlu,
                        texto_rutas={k: self.texto_ruta(self.vigentes[k], r) for k, r in rutas.items()})

        def preparar(self, comunicaciones, version):
            self.comprobar(version)
            error_inicial = self.numero_error
            por_switch = defaultdict(int)
            for c in comunicaciones:
                for g in c.grupos:
                    por_switch[g.switch] += 1
            for sw, cuantos in por_switch.items():
                feature = self.features.get(sw)
                if feature is None or len(self.grupos_usados[sw]) > feature.max_groups[ofproto_v1_3.OFPGT_FF]:
                    raise NoVerificable('CAPACIDAD_DE_GRUPOS_INSUFICIENTE: ' + self.nombre_sw(sw))
            switches = set()
            for c in comunicaciones:
                self.comprobar(version)
                for g in c.grupos:
                    self.enviar_grupo(g, version)
                    switches.add(g.switch)
                for r in c.reglas:
                    self.enviar_regla(r, version)
                    switches.add(r.switch)
                hub.sleep(0)
            self.barreras(switches, version)
            if error_inicial != self.numero_error:
                raise NoVerificable('ERROR_PREPARANDO_REGLAS_O_GRUPOS')
            muestra = self.estadisticas(version)
            self.verificar(comunicaciones, muestra, False)
            self.emitir('PREPARACION_VERIFICADA', f'{len(comunicaciones)} comunicaciones | reglas y respaldos nuevos disponibles')

        def activar(self, c, version):
            self.comprobar(version)
            errores = self.numero_error
            previa = self.estadisticas(version)
            self.verificar([c], previa, False)
            try:
                self.verificar([c], previa, True)
            except NoVerificable:
                pass
            else:
                self.vigentes[c.identificador] = c
                return
            for regla in c.ingresos:
                self.enviar_regla(regla, version)
            self.barreras([c.origen.switch], version)
            muestra = self.estadisticas(version)
            self.verificar([c], muestra, True)
            if errores != self.numero_error:
                raise NoVerificable('ERROR_ACTIVANDO_COMUNICACION')
            self.vigentes[c.identificador] = c

        def reconciliar(self, version):
            muestra = self.estadisticas(version)
            anteriores = set(self.vigentes)
            elegidos = {}
            for (sw, prioridad, firma), dato in muestra['flows'].items():
                if prioridad != 400 or dato['match'].get('eth_type') != 0x0800:
                    continue
                c = self.registro.get(dato['cookie'])
                if c is None:
                    continue
                esperado = next(r for r in c.ingresos if r.match['eth_type'] == 0x0800)
                if sw != esperado.switch or firma != self.firma_match(esperado.match) or dato['actions'] != self.firma_esperada(sw, esperado.acciones):
                    raise NoVerificable('INGRESO_INSTALADO_NO_COINCIDE_CON_INVENTARIO')
                if c.origen.ip in self.hosts and c.destino.ip in self.hosts:
                    elegidos[c.identificador] = c
            self.vigentes = elegidos
            if anteriores - set(elegidos):
                self.reconstruir = True
            for c in list(elegidos.values()):
                if self.ruta_efectiva(c) is None:
                    continue
                arp_regla = next(r for r in c.ingresos if r.match['eth_type'] == 0x0806)
                dato = muestra['flows'].get((arp_regla.switch, arp_regla.prioridad, self.firma_match(arp_regla.match)))
                if dato is None or dato['cookie'] != c.cookie or dato['actions'] != self.firma_esperada(arp_regla.switch, arp_regla.acciones):
                    self.enviar_regla(arp_regla, version)
                    self.barreras([arp_regla.switch], version)
                try:
                    self.verificar([c], muestra, False)
                except NoVerificable:
                    self.reconstruir = True
            return muestra

        def borrar_cookie(self, cookie, switches, version):
            for sw in sorted(set(switches)):
                dp = self.dps.get(sw)
                if dp is None:
                    raise NoVerificable('NO_SE_PUEDE_LIMPIAR_SWITCH_DESCONECTADO')
                p, o = dp.ofproto_parser, dp.ofproto
                self.enviar(dp, p.OFPFlowMod(dp, cookie=cookie, cookie_mask=0xFFFFFFFFFFFFFFFF,
                                            table_id=0, command=o.OFPFC_DELETE, out_port=o.OFPP_ANY,
                                            out_group=o.OFPG_ANY, match=p.OFPMatch()), version)

        def limpiar(self, version):
            self.comprobar(version)
            protegidas = {c.cookie for c in self.vigentes.values()} | {COOKIE_PREFIX}
            antiguas = {cookie for cookie in self.registro if cookie not in protegidas}
            antiguas.update(f.cookie for _, f in self.legado if f.cookie not in protegidas)
            if not antiguas:
                return
            a = self.estadisticas(version)
            for (_, prioridad, _), dato in a['flows'].items():
                if prioridad == 400 and dato['cookie'] in antiguas:
                    antiguas.discard(dato['cookie'])
            if not antiguas:
                return
            self.esperar(max(self.intervalo, 4 * max(self.latencias)), version)
            b = self.estadisticas(version)
            for clave, dato in b['flows'].items():
                if dato['cookie'] in antiguas:
                    previo = a['flows'].get(clave)
                    if previo is None or previo['cookie'] != dato['cookie'] or previo['paquetes'] != dato['paquetes']:
                        raise NoVerificable('DRENAJE_ANTERIOR_PENDIENTE')
            switches = set(self.dps)
            for cookie in antiguas:
                self.borrar_cookie(cookie, switches, version)
            self.barreras(switches, version)
            verificacion = self.estadisticas(version)
            if any(d['cookie'] in antiguas for d in verificacion['flows'].values()):
                raise NoVerificable('RETIRADA_DE_REGLAS_NO_VERIFICADA')
            activos = {(g.switch, g.identificador) for c in self.vigentes.values() for g in c.grupos}
            activos.update((clave[0], accion[1]) for clave, dato in verificacion['flows'].items()
                           for accion in dato['actions'] if accion[0] == 'group')
            eliminados = []
            for sw, identificador in verificacion['descs']:
                if identificador & 0xFFFF0000 != GROUP_PREFIX or (sw, identificador) in activos:
                    continue
                dp = self.dps.get(sw)
                if dp is None:
                    continue
                p, o = dp.ofproto_parser, dp.ofproto
                self.enviar(dp, p.OFPGroupMod(dp, o.OFPGC_DELETE, o.OFPGT_FF, identificador, []), version)
                eliminados.append((sw, identificador))
            self.barreras(switches, version)
            final = self.estadisticas(version)
            if any(k in final['descs'] for k in eliminados):
                raise NoVerificable('RETIRADA_DE_GRUPOS_NO_VERIFICADA')
            for sw, identificador in eliminados:
                self.grupos_usados[sw].discard(identificador)
            for cookie in antiguas:
                c = self.registro.pop(cookie, None)
                if c is not None:
                    self.etiquetas.difference_update(c.etiquetas - self.etiquetas_externas)
                    for g in c.grupos:
                        if (g.switch, g.identificador) not in final['descs']:
                            self.grupos_usados[g.switch].discard(g.identificador)
                self.cookies_usadas.discard(cookie)
            usadas_activas = {tag for c in self.vigentes.values() for tag in c.etiquetas}
            for sw, flujo in self.legado:
                if flujo.cookie not in antiguas:
                    continue
                tag = dict(flujo.match.items()).get('vlan_vid', 0)
                if isinstance(tag, int) and tag & 0x1000 and tag & 0xFFF not in usadas_activas | self.etiquetas_externas:
                    self.etiquetas.discard(tag & 0xFFF)
            self.legado = [(sw, flujo) for sw, flujo in self.legado if flujo.cookie not in antiguas]
            self.legado_grupos.clear()
            self.emitir('LIMPIEZA', f'{len(antiguas)} versiones de reglas retiradas | inactividad de contadores verificada')

        def mostrar_configuracion(self, titulo, comunicaciones=None):
            comunicaciones = self.vigentes if comunicaciones is None else comunicaciones
            print('\n' + titulo, flush=True)
            for h in sorted(self.hosts.values(), key=lambda h: int(ipaddress.IPv4Address(h.ip))):
                print(f'  {h.nombre} | {h.ip} | {h.mac} | {self.nombre_sw(h.switch)}:{h.puerto}', flush=True)
            sin_respaldo = 0
            for clave, c in sorted(comunicaciones.items()):
                print(f'  {c.origen.nombre} -> {c.destino.nombre} | PRINCIPAL: {self.texto_ruta(c, c.ruta)}', flush=True)
                for i, e in enumerate(c.ruta):
                    respaldo = c.respaldos.get(e)
                    if respaldo is None:
                        sin_respaldo += 1
                        print(f'    {self.texto_enlace(e)} | sin desvio simple que evite el prefijo recorrido', flush=True)
                        continue
                    alternativa, grupo = respaldo
                    print(f'    FF {grupo.identificador} en {self.nombre_sw(grupo.switch)} | '
                          f'principal={grupo.principal} respaldo={grupo.respaldo} | '
                          f'si cae {self.texto_enlace(e)}: {self.texto_ruta(c, c.ruta[:i] + alternativa)}', flush=True)
            print(f'  {len(comunicaciones)} comunicaciones | '
                  f'{sum(len(c.grupos) for c in comunicaciones.values())} grupos FF | '
                  f'{sin_respaldo} saltos sin desvio simple\n', flush=True)

        def mostrar_medicion(self, nombre, medicion):
            critico = max(
                medicion['RS'],
                key=lambda r: r['utilizacion'],
                default=None
            )
            enlace = (
                self.texto_enlace(critico['enlace'])
                if critico else 'SIN_TRONCALES'
            )
            self.emitir(
                nombre,
                f"FS: {sum(f['paquetes'] > 0 for f in medicion['FS'])}/"
                f"{len(medicion['FS'])} con trafico | "
                f"PS: {medicion['PS']['grupos']} grupos verificados | "
                f"MLU {medicion['mlu']:.6f}% en {enlace} | "
                f"ventana {medicion['ventana']:.3f} s"
            )
            for f in medicion['FS']:
                print(
                    f"  {medicion['texto_rutas'][f['id']]} | "
                    f"ingreso {f['tx']:.6f} Mbps | "
                    f"egreso {f['rx']:.6f} Mbps",
                    flush=True
                )
            for r in medicion['RS']:
                print(
                    f"  {self.texto_enlace(r['enlace'])}: "
                    f"{r['mbps']:.6f}/{r['capacidad']:.6f} Mbps | "
                    f"utilizacion {r['utilizacion']:.6f}%",
                    flush=True
                )

        def mostrar_comparacion(self, inicial, ff, final, instalado):
            print('\nCOMPARACION INICIAL / FF / FORT', flush=True)
            claves = sorted(set(inicial) | set(ff['texto_rutas']) | set(final['texto_rutas']))
            for clave in claves:
                print(f'  {clave}', flush=True)
                print('    INICIAL: ' + inicial.get(clave, 'NO_DISPONIBLE'), flush=True)
                print('    FF:      ' + ff['texto_rutas'].get(clave, 'SIN_RUTA'), flush=True)
                print('    ' + ('FORT:    ' if instalado else 'FF CONSERVADO: ') +
                      final['texto_rutas'].get(clave, 'SIN_RUTA'), flush=True)
            antes = {tuple(x['enlace']): x for x in ff['RS']}
            despues = {tuple(x['enlace']): x for x in final['RS']}
            print('  UTILIZACION OBSERVADA POR DIRECCION', flush=True)
            for e in sorted(set(antes) | set(despues)):
                x = f"{antes[e]['utilizacion']:.6f}%" if e in antes else 'NO_DISPONIBLE'
                y = f"{despues[e]['utilizacion']:.6f}%" if e in despues else 'NO_DISPONIBLE'
                print(f'    {self.texto_enlace(e)} | FF {x} | ' + ('FORT ' if instalado else 'FF CONSERVADO ') + y, flush=True)
            for etiqueta, estado in [('FF', ff), ('FORT' if instalado else 'FF CONSERVADO', final)]:
                critico = max(estado['RS'], key=lambda x: x['utilizacion'], default=None)
                texto = self.texto_enlace(critico['enlace']) if critico else 'SIN_ENLACES_TRONCALES'
                tx = sum(x['tx'] for x in estado['FS'])
                rx = sum(x['rx'] for x in estado['FS'])
                print(f"  {etiqueta}: MLU {estado['mlu']:.6f}% en {texto} | "
                      f"ingreso IPv4 {tx:.6f} Mbps | egreso hacia hosts {rx:.6f} Mbps", flush=True)
            print('  Las mediciones corresponden a ventanas distintas; el egreso OpenFlow no certifica recepcion de aplicacion.', flush=True)
            if not instalado:
                print('  No se atribuye una mejora a FORT: las rutas no fueron reoptimizadas.', flush=True)
            print('', flush=True)

        def construir_base(self, version):
            self.comprobar(version)
            grafo = grafo_de(self.enlaces)
            disponibles = [h for h in self.hosts.values() if self.puerto_vivo(h.switch, h.puerto)]
            deseadas = {}
            inaccesibles = []
            self.emitir('FF_CALCULANDO', 'Rutas principales y respaldos sobre la topologia reconocida')
            for origen in sorted(disponibles, key=lambda h: h.ip):
                for destino in sorted(disponibles, key=lambda h: h.ip):
                    if origen.ip == destino.ip:
                        continue
                    ruta = camino(grafo, origen.switch, destino.switch)
                    clave = origen.ip + '>' + destino.ip
                    if ruta is None:
                        inaccesibles.append(clave)
                        continue
                    deseadas[clave] = self.compilar(origen, destino, ruta)
                self.comprobar(version)
                hub.sleep(0)
            nuevas = [c for k, c in deseadas.items() if self.vigentes.get(k) is not c]
            orden = [c.identificador for c in nuevas]
            if self.vigentes and nuevas and not inaccesibles and all(self.ruta_efectiva(c) is not None for c in self.vigentes.values()):
                medicion = self.medir(version)
                indices = {e: i for i, e in enumerate(medicion['arcos'])}
                finales = {f['id']: [indices[e] for e in deseadas[f['id']].ruta]
                           for f in medicion['modelo']['flujos'] if f['id'] in deseadas}
                if len(finales) == len(medicion['modelo']['flujos']):
                    respuesta = self.ejecutar_solver(dict(_operacion='transition', modelo=medicion['modelo'], rutas=finales), version)
                    if respuesta.get('estado') != 'TRANSITION':
                        raise NoVerificable('RECONSTRUCCION_FF_CALCULO_NO_CERTIFICADO')
                    plan = respuesta['plan']
                    if plan is None:
                        raise NoVerificable('RECONSTRUCCION_FF_SIN_TRANSITION_ADMISIBLE')
                    orden = plan['orden'] + [k for k in orden if k not in plan['orden']]
            if nuevas:
                self.preparar(nuevas, version)
            for clave in orden:
                if clave not in deseadas or self.vigentes.get(clave) is deseadas[clave]:
                    continue
                self.activar(deseadas[clave], version)
            for clave in set(self.vigentes) - set(deseadas):
                c = self.vigentes[clave]
                if c.origen.switch in self.dps:
                    self.borrar_cookie(c.cookie, [c.origen.switch], version)
                    self.barreras([c.origen.switch], version)
                self.vigentes.pop(clave, None)
            self.comprobar(version)
            self.vigentes = deseadas
            muestra = self.estadisticas(version)
            self.verificar(list(deseadas.values()), muestra, True)
            self.lista = True
            self.reconstruir = False
            self.version_lista_datos = None
            self.emitir('FF_INSTALADO', f'{len(self.dps)} switches | {len({fisico(e) for e in self.enlaces})} enlaces | '
                        f'{len(disponibles)} hosts | {len(deseadas)} comunicaciones verificadas')
            self.mostrar_configuracion('RUTAS PRINCIPALES Y RESPALDOS FF INSTALADOS')
            if inaccesibles:
                self.emitir('PARTICION', 'Comunicaciones sin conectividad fisica: ' + ', '.join(inaccesibles))
            self.limpiar(version)

        def ejecutar_solver(self, modelo, version):
            entrada = json.dumps(modelo, allow_nan=False).encode()
            entorno = dict(os.environ)
            entorno['PYTHONUNBUFFERED'] = '1'
            proceso = subprocess.Popen([sys.executable, '-u', os.path.abspath(__file__), '--resolver'],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       env=entorno, close_fds=True)
            self.proceso = proceso
            salida, errores = bytearray(), bytearray()
            enviados = 0
            for flujo in (proceso.stdin, proceso.stdout, proceso.stderr):
                os.set_blocking(flujo.fileno(), False)
            comienzo = time.monotonic()
            try:
                while True:
                    self.comprobar(version)
                    if enviados < len(entrada):
                        try:
                            enviados += os.write(proceso.stdin.fileno(), entrada[enviados:enviados + 65536])
                        except BlockingIOError:
                            pass
                        except BrokenPipeError:
                            enviados = len(entrada)
                        if enviados == len(entrada):
                            proceso.stdin.close()
                    for flujo, destino in ((proceso.stdout, salida), (proceso.stderr, errores)):
                        while True:
                            try:
                                trozo = os.read(flujo.fileno(), 65536)
                            except BlockingIOError:
                                break
                            if not trozo:
                                break
                            destino.extend(trozo)
                            if destino is errores and len(errores) > 65536:
                                del errores[:-65536]
                    if proceso.poll() is not None:
                        break
                    hub.sleep(0.02)
                for flujo, destino in ((proceso.stdout, salida), (proceso.stderr, errores)):
                    while True:
                        try:
                            trozo = os.read(flujo.fileno(), 65536)
                        except BlockingIOError:
                            break
                        if not trozo:
                            break
                        destino.extend(trozo)
                self.comprobar(version)
                if proceso.returncode != 0:
                    raise NoVerificable('CALCULO_NO_CONCLUIDO: ' + errores.decode(errors='replace')[-2000:])
                resultado = json.loads(salida.decode())
                resultado['tiempo_calculo_s'] = time.monotonic() - comienzo
                return resultado
            finally:
                if proceso.poll() is None:
                    proceso.terminate()
                    fin = time.monotonic() + 1
                    while proceso.poll() is None and time.monotonic() < fin:
                        hub.sleep(0.02)
                    if proceso.poll() is None:
                        proceso.kill()
                    while proceso.poll() is None:
                        hub.sleep(0.02)
                for flujo in (proceso.stdin, proceso.stdout, proceso.stderr):
                    if not flujo.closed:
                        flujo.close()
                if self.proceso is proceso:
                    self.proceso = None

        def preflight(self, medicion, resultado, version):
            actual = self.medir(version)
            modelo_anterior = medicion['modelo']
            modelo = actual['modelo']
            if medicion['arcos'] != actual['arcos']:
                raise NoVerificable('PREFLIGHT_TOPOLOGIA_CAMBIADA')
            if [f['id'] for f in modelo_anterior['flujos']] != [f['id'] for f in modelo['flujos']]:
                raise NoVerificable('PREFLIGHT_COMUNICACIONES_CAMBIADAS')
            referencia = maximo_utilizacion(modelo, calcular_cargas(modelo, {f['id']: f['ruta'] for f in modelo['flujos']}))
            final = maximo_utilizacion(modelo, calcular_cargas(modelo, resultado['rutas']))
            if final >= referencia - EPS * max(1.0, referencia):
                raise NoVerificable('PREFLIGHT_DEMANDA_ACTUAL_ANULA_MEJORA')
            plan = resultado['transition']
            rutas = {f['id']: list(f['ruta']) for f in modelo['flujos']}
            inicial = calcular_cargas(modelo, rutas)
            cargas_finales = calcular_cargas(modelo, resultado['rutas'])
            techos = [max(e['capacidad'], a, b) for e, a, b in zip(modelo['enlaces'], inicial, cargas_finales)]
            for clave in plan['orden']:
                rutas[clave] = resultado['rutas'][clave]
                carga = calcular_cargas(modelo, rutas)
                if any(v > t + EPS * max(1.0, t) for v, t in zip(carga, techos)):
                    raise NoVerificable('PREFLIGHT_TRANSITION_NO_ADMISIBLE_CON_DEMANDA_ACTUAL')
            self.emitir('PREFLIGHT_VERIFICADO', f'MLU con demanda reciente: {referencia:.6f}% -> {final:.6f}%')
            return actual

        def mostrar_target(self, resultado, captura):
            self.emitir('TARGET_001', f"MLU optima del modelo: {resultado['mlu']:.6f}% | "
                        f"referencia FF con la misma demanda: {resultado['referencia']:.6f}% | "
                        f"calculo: {resultado['tiempo_calculo_s']:.3f} s")
            for clave, indices in sorted(resultado['rutas'].items()):
                print('  ' + self.texto_ruta(self.vigentes[clave], [captura['arcos'][i] for i in indices]), flush=True)
            print('  UTILIZACION ESTIMADA CON LA MISMA DEMANDA CAPTURADA', flush=True)
            for i, uso in enumerate(utilizaciones(captura['modelo'], resultado['cargas'])):
                print(f"    {self.texto_enlace(captura['arcos'][i])}: {uso:.6f}%", flush=True)
            plan = resultado['transition']
            print(f"  TRANSITION_001 | pico MLU de estados intermedios: {plan['pico']:.6f}% | "
                  f"{plan['estados']} estados evaluados | orden optimo certificado", flush=True)
            print('    PREPARAR Y VERIFICAR NUEVAS REGLAS Y GRUPOS FF', flush=True)
            for i, clave in enumerate(plan['orden'], 1):
                c = self.vigentes[clave]
                print(f'    {i}. Activar {c.origen.nombre} -> {c.destino.nombre}', flush=True)
            print('    VERIFICAR CONFIGURACION FINAL Y RETIRAR VERSIONES ANTERIORES', flush=True)
            print('    Actualizar tambien la proteccion de las comunicaciones cuya ruta no cambia', flush=True)

        def reoptimizar(self, version):
            self.comprobar(version)
            self.ciclo += 1
            inicial = dict(self.referencia_inicial)
            self.emitir('MEDICION_POST_FF', 'Capturando FS, PS y RS con demanda reciente')
            captura = self.medir(version)
            self.analisis = captura
            self.mostrar_medicion('ESTADO_POST_FF', captura)
            self.emitir('OPTIMIZACION', 'Minimizar MLU; busqueda hasta certificar optimo, sin cupos de caminos ni Targets')
            resultado = self.ejecutar_solver(captura['modelo'], version)
            self.comprobar(version)
            if resultado['estado'] == 'CONSERVAR_FF':
                self.emitir('CONSERVAR_FF', resultado['motivo'])
                self.mostrar_comparacion(inicial, captura, captura, False)
                self.analisis = None
                self.referencia_inicial.clear()
                self.incidente = False
                self.emitir('CICLO_FINALIZADO', 'Datos analiticos eliminados | supervision activa')
                return
            if resultado['estado'] != 'OPTIMO' or not resultado.get('certificado') or not resultado.get('certificado_desempate'):
                self.emitir('SIN_INSTALACION', resultado.get('motivo', resultado['estado']))
                self.analisis = None
                self.referencia_inicial.clear()
                self.incidente = False
                return
            self.mostrar_target(resultado, captura)
            nuevas = {}
            for clave in resultado['rutas']:
                self.comprobar(version)
                c = self.vigentes[clave]
                ruta = [captura['arcos'][i] for i in resultado['rutas'][clave]]
                nuevas[clave] = self.compilar(c.origen, c.destino, ruta)
                hub.sleep(0)
            self.preparar(list(nuevas.values()), version)
            self.preflight(captura, resultado, version)
            orden = resultado['transition']['orden'] + sorted(set(nuevas) - set(resultado['transition']['orden']))
            self.transaccion = dict(version=version, inicial=inicial, captura=captura,
                                    resultado=resultado, nuevas=nuevas, orden=orden, mostrado=False)
            self.completar_transaccion(version)

        def completar_transaccion(self, version):
            self.comprobar(version)
            t = self.transaccion
            if t is None or t['version'] != version:
                raise Cancelado()
            nuevas, captura = t['nuevas'], t['captura']
            for numero, clave in enumerate(t['orden'], 1):
                self.comprobar(version)
                c = nuevas[clave]
                if self.vigentes.get(clave) is c:
                    continue
                self.activar(c, version)
                self.emitir('TRANSITION', f"{numero}/{len(nuevas)} | {self.texto_ruta(c, c.ruta)} | ingreso verificado")
            self.avisar('INSTALACION_VERIFICADA', 'Midiendo la configuracion final y comprobando sus respaldos')
            final = self.medir(version)
            for f in final['FS']:
                if f['id'] in nuevas and f['paquetes'] > 0 and f['rx'] <= 0:
                    raise NoVerificable('EGRESO_POST_FORT_NO_CORROBORADO: ' + f['id'])
            if not t['mostrado']:
                self.mostrar_configuracion('CONFIGURACION FORT Y NUEVOS RESPALDOS FF VERIFICADOS')
                self.mostrar_comparacion(t['inicial'], captura, final, True)
                t['mostrado'] = True
            self.limpiar(version)
            self.analisis = None
            self.referencia_inicial.clear()
            self.incidente = False
            self.transaccion = None
            self.emitir('CICLO_FINALIZADO', 'Optimo del modelo instalado | datos analiticos eliminados | supervision activa')

        def supervisar(self):
            while self.activo:
                version = self.version
                try:
                    if not self.dps or set(self.dps) != set(self.features):
                        hub.sleep(0.2)
                        continue
                    if time.monotonic() - self.ultimo_cambio < max(self.intervalo, 4 * max(self.latencias)):
                        hub.sleep(0.1)
                        continue
                    self.actualizar_enlaces()
                    if len(self.hosts) < 2:
                        self.avisar('ESPERANDO_HOSTS', 'Genere ARP/IPv4; en Mininet puede ejecutar pingall.')
                        hub.sleep(self.intervalo)
                        continue
                    self.reconciliar(version)
                    if self.transaccion is not None:
                        self.completar_transaccion(version)
                        continue
                    self.limpiar(version)
                    rotas = [c.identificador for c in self.vigentes.values() if self.ruta_efectiva(c) is None]
                    if self.reconstruir or not self.lista or not self.vigentes or rotas:
                        era_incidente = self.incidente
                        if rotas:
                            self.emitir('RECUPERACION_CONTROLADOR', 'FF no mantiene todas las comunicaciones; reconstruyendo rutas disponibles')
                        self.construir_base(version)
                        if not self.fallos:
                            self.incidente = False
                            self.referencia_inicial.clear()
                        elif era_incidente:
                            self.incidente = True
                    if self.incidente:
                        self.reoptimizar(version)
                    else:
                        self.preparar_medicion(version)
                        self.limpiar(version)
                        self.avisar('SUPERVISION', 'Observando enlaces, conexiones OpenFlow y reglas vigentes')
                except Cancelado:
                    self.analisis = None
                    hub.sleep(0)
                except NoVerificable as exc:
                    self.analisis = None
                    self.avisar('ESPERANDO_EVIDENCIA', str(exc))
                    hub.sleep(self.intervalo)
                except Exception as exc:
                    self.analisis = None
                    self.avisar('ERROR', f'{type(exc).__name__}: {exc}')
                    hub.sleep(self.intervalo)

        def close(self):
            self.activo = False
            self.analisis = None
            self.referencia_inicial.clear()
            if self.proceso is not None and self.proceso.poll() is None:
                self.proceso.terminate()
            return super().close()


def main():
    if importlib.util.find_spec('os_ken') is None:
        raise SystemExit('Faltan dependencias: os-ken, scipy y numpy en este interprete Python')
    argumentos = argparse.ArgumentParser(prog='FORT-V1.0')
    argumentos.add_argument('--direccion', default=os.environ.get('FORT_DIRECCION', '127.0.0.1'))
    argumentos.add_argument('--puerto', type=int, default=int(os.environ.get('FORT_PUERTO', '6653')))
    opciones = argumentos.parse_args()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as prueba:
        prueba.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            prueba.bind((opciones.direccion, opciones.puerto))
        except OSError as exc:
            raise SystemExit(f'Puerto del controlador no disponible: {exc}')
    cfg.CONF(args=[], project='fort-v1')
    cfg.CONF.set_override('ofp_listen_host', opciones.direccion)
    cfg.CONF.set_override('ofp_tcp_listen_port', opciones.puerto)
    cfg.CONF.set_override('observe_links', True)
    ofproto_protocol.set_app_supported_versions([ofproto_v1_3.OFP_VERSION])
    print(f'{VERSION} | revision {REVISION} | OpenFlow 1.3 | {opciones.direccion}:{opciones.puerto}', flush=True)
    app_manager.AppManager.run_apps(['os_ken.controller.ofp_handler', 'os_ken.topology.switches', '__main__'])


if __name__ == '__main__':
    main()

