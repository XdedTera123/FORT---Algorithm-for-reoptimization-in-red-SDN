#!/usr/bin/env python3
"""Topologia V2 para FORT (Mininet + OVS/OpenFlow 1.3).

Diagrama de referencia: cinco carriles s1-s6, s2-s7, s3-s8,
s4-s9, s5-s10, con dos hosts en los extremos.

Para representar el abanico sin multihoming de hosts (no admitido por el
modelo de host de FORT-V1.0), se agregan dos switches de acceso:
 h1--s11--{s1,s2,s3,s4,s5}--{s6,s7,s8,s9,s10}--s12--h2

Por defecto se agregan ocho enlaces laterales entre carriles que permiten
alternativas de Fast Failover para la caida de un enlace intermedio.
Con --sin-refuerzos queda el diagrama de los cinco carriles puros (mas los
switches de acceso); no hay respaldo FF local para todos los fallos.

NO arranca FORT, no genera trafico y no altera archivos de otras topologias.
"""

import argparse
import math
import os
import re
import shutil
import signal
import subprocess
import sys
from collections import defaultdict, deque

IP_CONTROLADOR = '127.0.0.1'
PUERTO_CONTROLADOR = 6653
CAPACIDAD_MBPS = 100.0
QUANTUM_HTB_BYTES = 1514
HOSTS = (
    ('h1', '10.0.0.1/24', '00:00:00:00:00:01', 's11'),
    ('h2', '10.0.0.2/24', '00:00:00:00:00:02', 's12'),
)
SWITCHES = tuple('s%d' % i for i in range(1, 13))


def definir_enlaces(refuerzos=True):
    """(nodo A, puerto A, nodo B, puerto B), sin puertos duplicados."""
    enlaces = [
        ('h1', 0, 's11', 1),
        ('h2', 0, 's12', 1),
    ]
    for i in range(5):
        a, b = 's%d' % (i + 1), 's%d' % (i + 6)
        enlaces.append(('s11', i + 2, a, 1))
        enlaces.append((a, 2, b, 1))
        enlaces.append((b, 2, 's12', i + 2))
    if refuerzos:
        for inicio in (1, 6):
            for i in range(4):
                # En cada fila: s1--s2--s3--s4--s5 y s6--...--s10.
                # El puerto 3 se usa para el vecino de menor indice
                # (excepto en la primera pareja); el 4 para el mayor.
                izquierda = 's%d' % (inicio + i)
                derecha = 's%d' % (inicio + i + 1)
                puerto_izq = 3 if i == 0 else 4
                enlaces.append((izquierda, puerto_izq, derecha, 3))
    return tuple(enlaces)


def validar_esquema(enlaces):
    puertos = set()
    pares = set()
    grafo = defaultdict(set)
    for a, pa, b, pb in enlaces:
        if a == b or (a, pa) in puertos or (b, pb) in puertos:
            raise ValueError('Enlace invalido o puerto repetido: %s:%s %s:%s' % (a, pa, b, pb))
        puertos.add((a, pa))
        puertos.add((b, pb))
        llave = frozenset((a, b))
        if llave in pares:
            raise ValueError('Enlace fisico duplicado entre %s y %s' % (a, b))
        pares.add(llave)
        grafo[a].add(b)
        grafo[b].add(a)
    if set(grafo) != set(SWITCHES) | {'h1', 'h2'}:
        raise ValueError('No estan todos los switches y hosts en la red')
    visitados = {'h1'}
    pendientes = deque(['h1'])
    while pendientes:
        nodo = pendientes.popleft()
        for siguiente in grafo[nodo] - visitados:
            visitados.add(siguiente)
            pendientes.append(siguiente)
    if len(visitados) != len(grafo):
        raise ValueError('La topologia no es conexa')
    if sum('h1' in (a, b) for a, _, b, _ in enlaces) != 1 or sum(
            'h2' in (a, b) for a, _, b, _ in enlaces) != 1:
        raise ValueError('FORT necesita hosts de una sola interfaz de acceso')
    return True


def mostrar_esquema(refuerzos):
    enlaces = definir_enlaces(refuerzos)
    validar_esquema(enlaces)
    troncales = [e for e in enlaces if e[0] in SWITCHES and e[2] in SWITCHES]
    print('FORT | TOPOLOGIA V2 | %s' % ('CON RESPALDOS LATERALES' if refuerzos else 'CINCO CAMINOS PUROS'))
    print('  12 switches: s1-s10 del dibujo + s11/s12 de acceso')
    print('  2 hosts: h1=10.0.0.1, h2=10.0.0.2')
    print('  %d troncales bidireccionales | 2 enlaces de acceso' % len(troncales))
    print('  Capacidad por direccion y por enlace: 100 Mbps')
    print('  Controlador remoto %s:%d | OpenFlow 1.3' % (IP_CONTROLADOR, PUERTO_CONTROLADOR))
    print('  Cinco caminos:')
    for i in range(5):
        print('    h1 -> s11 -> s%d -> s%d -> s12 -> h2' % (i + 1, i + 6))
    if refuerzos:
        print('  Refuerzos: s1-s2-s3-s4-s5 y s6-s7-s8-s9-s10')
    print('  Puertos (switch:puerto <-> switch:puerto):')
    for a, pa, b, pb in enlaces:
        print('    %-4s:%-2s <-> %-4s:%s' % (a, pa, b, pb))


def comprobar_entorno():
    if os.geteuid() != 0:
        raise RuntimeError('Inicia con sudo /usr/bin/python3 Topologias/Topologia_V2.py')
    ejecutables = ('ovs-vsctl', 'ovs-ofctl', 'ip', 'tc', 'mnexec', 'ethtool', 'ifconfig')
    faltan = [x for x in ejecutables if shutil.which(x) is None]
    if faltan:
        raise RuntimeError('Dependencias ausentes: ' + ', '.join(faltan))
    r = subprocess.run(['ovs-vsctl', '--timeout=3', 'list-br'], text=True,
                       capture_output=True, timeout=5, check=False)
    if r.returncode:
        raise RuntimeError('Open vSwitch no responde: ' + r.stderr.strip())
    ocupados = set(r.stdout.split()).intersection(SWITCHES)
    if ocupados:
        raise RuntimeError('Hay switches antiguos: %s. Cierra la sesion anterior de Mininet. '
                           'Si quedaron restos despues, usa sudo mn -c.' % ', '.join(sorted(ocupados)))
    # El controlador debe estar activo, pero no lo arrancamos aqui.
    return True


def iniciar(refuerzos=True, capacidad=CAPACIDAD_MBPS):
    try:
        from mininet.cli import CLI
        from mininet.link import TCIntf, TCLink
        from mininet.log import info, setLogLevel
        from mininet.net import Mininet
        from mininet.node import OVSSwitch, RemoteController
        from mininet.topo import Topo
    except ImportError as exc:
        raise RuntimeError('Mininet no disponible en /usr/bin/python3: %s' % exc)

    if not (isinstance(capacidad, (int, float)) and not isinstance(capacidad, bool)
            and math.isfinite(capacidad) and 0 < capacidad <= TCIntf.bwParamMax):
        raise ValueError('Capacidad fuera del rango soportado por Mininet')

    class InterfazV2(TCIntf):
        def bwCmds(self, *args, **kwargs):
            comandos, padre = super().bwCmds(*args, **kwargs)
            ajustados = []
            for comando in comandos:
                if ('class' in comando.split() and 'add' in comando.split()
                        and 'htb' in comando.split() and 'quantum' not in comando.split()):
                    comando += ' quantum %d' % QUANTUM_HTB_BYTES
                ajustados.append(comando)
            return ajustados, padre

        def config(self, *args, **kwargs):
            resultado = super().config(*args, **kwargs)
            salidas = (resultado or {}).get('tcoutputs', [])
            if any(str(x).strip() for x in salidas):
                raise RuntimeError('No se confirmo limitacion TC en %s: %s' %
                                   (self.name, ' | '.join(str(x).strip() for x in salidas if str(x).strip())))
            return resultado

    class EnlaceV2(TCLink):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault('cls1', InterfazV2)
            kwargs.setdefault('cls2', InterfazV2)
            super().__init__(*args, **kwargs)

    class TopologiaV2(Topo):
        def build(self):
            for i in range(1, 13):
                self.addSwitch('s%d' % i, dpid='%016x' % i, protocols='OpenFlow13',
                               failMode='secure', datapath='kernel', inband=False, stp=False)
            for nombre, ip, mac, _sw in HOSTS:
                self.addHost(nombre, ip=ip, mac=mac)
            for a, pa, b, pb in definir_enlaces(refuerzos):
                self.addLink(a, b, port1=pa, port2=pb, cls=EnlaceV2,
                             bw=float(capacidad), max_queue_size=1000)

    comprobar_entorno()
    validar_esquema(definir_enlaces(refuerzos))
    setLogLevel('info')
    red = None
    anterior = None
    try:
        def apagar(_sig, _marco):
            raise KeyboardInterrupt()
        anterior = signal.signal(signal.SIGTERM, apagar)
        red = Mininet(topo=TopologiaV2(), controller=None, switch=OVSSwitch,
                      link=EnlaceV2, build=False, autoSetMacs=False,
                      autoStaticArp=False, waitConnected=False)
        red.addController('c0', controller=RemoteController,
                          ip=IP_CONTROLADOR, port=PUERTO_CONTROLADOR)
        red.build()
        red.start()
        info('\n========================================\n')
        info('FORT V2 | TOPOLOGIA ACTIVA\n')
        info('12 switches, 2 hosts, enlaces a %.0f Mbps/direccion\n' % capacidad)
        info('Modo: %s\n' % ('reforzado para FF' if refuerzos else 'cinco caminos sin cruces'))
        info('FORT debe descubrir dos hosts via ARP/IPv4 (pingall).\n')
        info('Comandos: nodes | net | links | pingall | link s1 s6 down | exit\n')
        info('No se genera trafico de prueba automaticamente.\n')
        info('========================================\n\n')
        CLI(red)
        return 0
    except KeyboardInterrupt:
        info('\nCerrando topologia V2...\n')
        return 130
    finally:
        if red is not None:
            red.stop()
        if anterior is not None:
            signal.signal(signal.SIGTERM, anterior)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Topologia V2 de cinco carriles para FORT')
    parser.add_argument('--sin-refuerzos', action='store_true',
                        help='cinco caminos puros, sin enlaces laterales para FF')
    parser.add_argument('--resumen', action='store_true',
                        help='muestra conexiones sin iniciar Mininet')
    args = parser.parse_args(argv)
    try:
        if args.resumen:
            mostrar_esquema(not args.sin_refuerzos)
            return 0
        return iniciar(refuerzos=not args.sin_refuerzos)
    except (RuntimeError, ValueError, OSError, subprocess.TimeoutExpired) as exc:
        print('[TOPOLOGIA V2] %s' % exc, file=sys.stderr, flush=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
