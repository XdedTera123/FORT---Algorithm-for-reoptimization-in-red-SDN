#!/usr/bin/env python3
import json
import math
import os
import re
import shutil
import signal
import subprocess
import sys
from pathlib import Path

try:
    from mininet.cli import CLI
    from mininet.link import TCIntf, TCLink
    from mininet.log import info, setLogLevel
    from mininet.net import Mininet
    from mininet.node import OVSSwitch, RemoteController
    from mininet.topo import Topo
except ImportError as error:
    raise SystemExit(
        "No se pudo importar Mininet. Ejecuta el archivo con "
        "sudo /usr/bin/python3 y comprueba la instalacion de Mininet.\n"
        f"Detalle: {error}"
    ) from error


CONTROLADOR_IP = "127.0.0.1"
CONTROLADOR_PUERTO = 6653
CAPACIDAD_PREDETERMINADA_MBPS = 50.0
QUANTUM_HTB_BYTES = 1514
BURST_HTB = "125k"

# nombre, IPv4, switch de acceso. Puerto 0 en host y puerto 1 en switch.
HOSTS = (
    ("h1", "10.0.0.1/24", "s1"),
    ("h2", "10.0.0.2/24", "s2"),
    ("h3", "10.0.0.3/24", "s5"),
    ("h4", "10.0.0.4/24", "s7"),
)

# Switch A, puerto A, switch B, puerto B. Son conexiones fisicas simuladas,
# no rutas prefijadas: por ejemplo, s1-s4 es solo uno de los doce enlaces.
ENLACES_SWITCHES = (
    ("s1", 2, "s2", 2),
    ("s1", 3, "s3", 1),
    ("s1", 4, "s4", 1),
    ("s2", 3, "s4", 2),
    ("s2", 4, "s5", 2),
    ("s3", 2, "s4", 3),
    ("s4", 4, "s5", 3),
    ("s3", 3, "s6", 1),
    ("s4", 5, "s7", 2),
    ("s5", 4, "s8", 1),
    ("s6", 2, "s7", 3),
    ("s7", 4, "s8", 2),
)


def validar_capacidad(valor):
    """Evitar que Mininet ignore una tasa fuera de su rango admitido."""
    if (isinstance(valor, bool) or not isinstance(valor, (int, float))
            or not math.isfinite(valor) or not 0 < valor <= TCIntf.bwParamMax):
        raise ValueError(
            "capacidad_enlace_mbps debe ser numerica, positiva y como maximo "
            f"{TCIntf.bwParamMax:g} Mbps para esta instalacion de Mininet."
        )
    return float(valor)


def leer_capacidad():
    """Misma resolucion de ruta y valor predeterminado que FORT_V03.py."""
    raiz = Path(os.environ.get(
        "FORT_PROYECTO", Path(__file__).resolve().parent.parent
    )).resolve()
    archivo = Path(os.environ.get("FORT_CONFIG", raiz / "fort_config.json"))
    valor = CAPACIDAD_PREDETERMINADA_MBPS
    if archivo.is_file():
        configuracion = json.loads(archivo.read_text(encoding="utf-8"))
        if not isinstance(configuracion, dict):
            raise ValueError("fort_config.json debe contener un objeto JSON.")
        valor = configuracion.get("capacidad_enlace_mbps", valor)
    return validar_capacidad(valor)


class InterfazFORT(TCIntf):
    """HTB de Mininet con quantum explicito en su unica clase de tasa."""

    def bwCmds(self, *args, **kwargs):
        comandos, padre = super().bwCmds(*args, **kwargs)
        ajustados = []
        for comando in comandos:
            palabras = comando.split()
            if ("class" in palabras and "add" in palabras
                    and "htb" in palabras and "quantum" not in palabras):
                comando += f" quantum {QUANTUM_HTB_BYTES}"
                comando = comando.replace("burst 15k", f"burst {BURST_HTB} cburst {BURST_HTB}")
            ajustados.append(comando)
        return ajustados, padre

    def config(self, *args, **kwargs):
        resultado = super().config(*args, **kwargs)
        # TCIntf informa algunos fallos de tc sin lanzar excepcion. No anunciar
        # una red con capacidad configurada si el comando de limitacion fallo.
        salidas = (resultado or {}).get("tcoutputs", [])
        errores = [salida.strip() for salida in salidas if salida.strip()]
        if errores:
            raise RuntimeError(
                f"Configuracion tc incompleta en {self.name}: " + " | ".join(errores)
            )
        return resultado


class EnlaceFORT(TCLink):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("cls1", InterfazFORT)
        kwargs.setdefault("cls2", InterfazFORT)
        super().__init__(*args, **kwargs)


class TopologiaSDN(Topo):
    def build(self, capacidad_mbps=CAPACIDAD_PREDETERMINADA_MBPS):
        capacidad_mbps = validar_capacidad(capacidad_mbps)
        for numero in range(1, 9):
            self.addSwitch(
                f"s{numero}",
                dpid=f"{numero:016x}",
                protocols="OpenFlow13",
                failMode="secure",
                datapath="kernel",
                inband=False,
                stp=False,
            )

        for numero, (host, ip, switch) in enumerate(HOSTS, 1):
            self.addHost(host, ip=ip, mac=f"00:00:00:00:00:{numero:02x}")
            self.addLink(host, switch, port1=0, port2=1, cls=EnlaceFORT)

        for origen, puerto_a, destino, puerto_b in ENLACES_SWITCHES:
            self.addLink(
                origen, destino, port1=puerto_a, port2=puerto_b,
                cls=EnlaceFORT, bw=capacidad_mbps,
            )


def comprobar_entorno():
    if os.geteuid() != 0:
        raise RuntimeError("Ejecuta esta topologia con sudo /usr/bin/python3.")
    requeridos = ("ovs-vsctl", "ovs-ofctl", "ip", "tc", "ethtool", "ifconfig", "mnexec")
    faltantes = [nombre for nombre in requeridos if shutil.which(nombre) is None]
    if faltantes:
        raise RuntimeError("Faltan dependencias del sistema: " + ", ".join(faltantes))

    respuesta = subprocess.run(
        ["ovs-vsctl", "--timeout=3", "list-br"],
        capture_output=True, text=True, timeout=5, check=False,
    )
    if respuesta.returncode:
        raise RuntimeError("Open vSwitch no responde: " + respuesta.stderr.strip())
    switches = {f"s{i}" for i in range(1, 9)}
    ocupados = switches.intersection(respuesta.stdout.split())
    ocupados.update(
        interfaz.name for interfaz in Path("/sys/class/net").iterdir()
        if re.fullmatch(r"s[1-8](?:-eth\d+)?", interfaz.name)
    )
    if ocupados:
        raise RuntimeError(
            "Ya existen interfaces o switches de una red anterior: "
            + ", ".join(sorted(ocupados))
            + ". Finaliza esa sesion de Mininet antes de iniciar otra."
        )


def mostrar_resumen(capacidad):
    info("\n========================================\n")
    info("FORT V03 - TOPOLOGIA INICIADA\n")
    info("8 switches | 4 hosts | 12 enlaces entre switches\n")
    info(f"Capacidad troncal: {capacidad:g} Mbps por direccion\n")
    info(f"OpenFlow 1.3 | Controlador: {CONTROLADOR_IP}:{CONTROLADOR_PUERTO}\n")
    for host, ip, switch in HOSTS:
        info(f"  {host} ({ip}) -> {switch}, puerto 1\n")
    info("========================================\n")
    info("Espera RED_LISTA y las rutas verificadas en la consola de FORT.\n")
    info("Luego ejecuta pingall en esta consola para comprobar conectividad.\n")
    info("Comandos: nodes | net | links | dump | pingall\n")
    info("Los escenarios usaran esta misma red mediante la variable net.\n")
    info("La red permanece activa hasta escribir exit.\n\n")


def main():
    setLogLevel("info")
    red = None
    manejador_anterior = None
    try:
        capacidad = leer_capacidad()
        comprobar_entorno()

        def terminar(_senal, _marco):
            raise KeyboardInterrupt

        manejador_anterior = signal.signal(signal.SIGTERM, terminar)
        # build=False permite cerrar lo ya creado si falla la construccion.
        red = Mininet(
            topo=TopologiaSDN(capacidad_mbps=capacidad),
            controller=None, switch=OVSSwitch, link=EnlaceFORT,
            build=False, autoSetMacs=False, autoStaticArp=False,
            waitConnected=False,
        )
        red.addController(
            "c0", controller=RemoteController,
            ip=CONTROLADOR_IP, port=CONTROLADOR_PUERTO,
        )
        red.build()
        red.start()
        mostrar_resumen(capacidad)
        CLI(red)
        return 0
    except KeyboardInterrupt:
        info("\nCerrando la topologia...\n")
        return 130
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
        print(f"[TOPOLOGIA] {error}", file=sys.stderr, flush=True)
        return 1
    finally:
        if red is not None:
            red.stop()
        if manejador_anterior is not None:
            signal.signal(signal.SIGTERM, manejador_anterior)


if __name__ == "__main__":
    sys.exit(main())
