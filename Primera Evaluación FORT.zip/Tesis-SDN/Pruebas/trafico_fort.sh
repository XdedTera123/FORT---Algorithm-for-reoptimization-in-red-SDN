#!/usr/bin/env bash
# Trafico UDP de tasa constante para las pruebas de FORT, desde una terminal independiente.
# Solo lanza y detiene trafico; los enlaces se bajan y suben desde Mininet (link s1 s2 down).
#
# Uso:
#   sudo ./trafico_fort.sh base       [factor] [segundos]   casos 1, 2, 5 y 6
#   sudo ./trafico_fort.sh saturacion [factor] [segundos]   caso 3
#   sudo ./trafico_fort.sh unica      [factor] [segundos]   caso 4
#   sudo ./trafico_fort.sh detener
#
# factor multiplica todas las tasas (1 por defecto); segundos es la duracion (900 por defecto).
# Los registros de cada receptor quedan en /tmp/trafico_fort/receptor_<origen>_<destino>.log

set -u
DIR=/tmp/trafico_fort
PUERTO_BASE=5301
TAMANO=1200

if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta con sudo: sudo $0 $*" >&2
    exit 1
fi

en_host() {
    local host=$1; shift
    local pid
    pid=$(pgrep -f "mininet:$host\$" | head -n 1)
    if [ -z "$pid" ]; then
        echo "No se encontro el host $host. Inicia antes la topologia." >&2
        exit 1
    fi
    mnexec -a "$pid" "$@"
}

detener_iperf() {
    pkill -x iperf3 2>/dev/null || return 1
    for _ in $(seq 1 20); do
        pgrep -x iperf3 >/dev/null || return 0
        sleep 0.25
    done
    pkill -9 -x iperf3 2>/dev/null
    sleep 0.5
    return 0
}

ip_host() {
    en_host "$1" ip -4 -o addr show dev "$1-eth0" | awk '{print $4}' | cut -d/ -f1
}

caso=${1:-}
case "$caso" in
    base)
        flujos="h1 h2 22
h1 h4 21
h2 h1 30
h3 h4 24
h4 h2 24"
        aviso="Casos 1, 2, 5 y 6: baja s1-s2, s1-s4, s2-s4 o s4-s7 (caso 6: s1-s2 y, unos 7 s despues, s4-s7)" ;;
    saturacion)
        flujos="h1 h2 50
h1 h4 20
h2 h1 30
h3 h4 24
h4 h2 55"
        aviso="Caso 3: baja s1-s2; s4->s2 recibira 105 Mbps sobre 100" ;;
    unica)
        flujos="h1 h2 30"
        aviso="Caso 4: baja s1-s2; FORT debe conservar FF" ;;
    detener)
        detener_iperf && echo "Trafico detenido" || echo "No habia trafico activo"
        exit 0 ;;
    *)
        sed -n '2,13p' "$0"
        exit 1 ;;
esac

factor=${2:-1}
duracion=${3:-900}
detener_iperf
rm -rf "$DIR"; mkdir -p "$DIR"
n=0; total=0
while read -r origen destino tasa; do
    puerto=$((PUERTO_BASE + n))
    mbps=$(awk -v t="$tasa" -v f="$factor" 'BEGIN{printf "%g", t*f}')
    en_host "$destino" iperf3 -s -p "$puerto" -1 -D --logfile "$DIR/receptor_${origen}_${destino}.log"
    sleep 0.3
    en_host "$origen" setsid nohup iperf3 -u -c "$(ip_host "$destino")" -p "$puerto" -b "${mbps}M" \
        -l "$TAMANO" -t "$duracion" --logfile "$DIR/emisor_${origen}_${destino}.log" \
        </dev/null >/dev/null 2>&1 &
    printf '%s -> %s | %s Mbps\n' "$origen" "$destino" "$mbps"
    total=$(awk -v a="$total" -v b="$mbps" 'BEGIN{printf "%g", a+b}')
    n=$((n + 1))
done <<< "$flujos"
echo "Trafico $caso | carga total $total Mbps | $duracion s"
echo "$aviso"
